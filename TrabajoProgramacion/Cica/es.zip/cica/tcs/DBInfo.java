package es.cica.tcs;

import java.io.*;

import iaik.asn1.structures.Name;
import iaik.x509.PublicKeyInfo;
import iaik.pkcs.pkcs8.EncryptedPrivateKeyInfo;

public class DBInfo implements Serializable
{
  public byte password[];
  public PublicKeyInfo publicKey;
  public EncryptedPrivateKeyInfo privateKey;

  public DBInfo ()
  {
    publicKey=null;
    privateKey=null;
    password=null;
  }

}
