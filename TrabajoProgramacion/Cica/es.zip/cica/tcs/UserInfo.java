package es.cica.tcs;

import java.io.*;
import iaik.asn1.structures.Name;
import iaik.security.rsa.RSAPublicKey;

public class UserInfo implements Serializable
{
  public int time[];
  public String url[];
  public RSAPublicKey publicKey;

  public UserInfo ()
  {
    time=null;
    url=null;
    publicKey=null;
  }
}
