package es.cica.tcs;

import java.io.*;
import java.util.*;
import java.security.cert.CertificateException;
import java.security.InvalidKeyException;

import iaik.asn1.*;
import iaik.asn1.structures.Name;
import iaik.security.rsa.RSAPublicKey;
import iaik.utils.*;

import es.cica.tcs.util.TCUtil;

public class TCInsert
{
  public DataBase userFile;

  public TCInsert (String file) throws IOException
  {
    userFile=new DataBase (file);
  }

  public void read (InputStream fin) throws IOException,CodingException,CertificateException,InvalidKeyException,ProtocolException
  {
    BufferedReader br=new BufferedReader (new InputStreamReader (fin));
    String line;
    StringTokenizer st;
    String var;
    UserInfo ui=new UserInfo ();
    boolean cond=false;
    Name subject=null;
    int i;
    while ((line=br.readLine ())!=null)
    {
      if (line.startsWith ("#")) continue;
      st=new StringTokenizer (line," \t\r");
      if (!st.hasMoreTokens ()) continue;
      var=st.nextToken ();
      if (var.equals ("END")) break;
      if (var.equals ("SUBJECT"))
      {
        if (cond) userFile.insert (subject.getEncoded (),DataBase.toByteArray (ui));
        subject=TCUtil.toName (line.substring ("SUBJECT".length ()));
        cond=true;
        ui.url = null;
      }
      else if (line.startsWith ("-----BEGIN PUBLICKEY-----"))
      {
        StringBuffer k=new StringBuffer ("");
        for (;;)
        {
          line=br.readLine ();
          if (line.startsWith ("-----END PUBLICKEY-----")) break;
          k.append (line+"\n");
        }
        ui.publicKey=new RSAPublicKey (Util.Base64Decode (k.toString ().getBytes ()));
      }
      else if (var.equals ("URL"))
      {
        if (ui.url==null)
        {
          ui.url=new String[1];
          ui.time=new int[1];
        }
        else
        {
          String url[]=new String[ui.url.length+1];
          int time[]=new int[ui.url.length+1];
          for (i=0;i<ui.url.length;i++)
          {
            url[i]=ui.url[i];
            time[i]=ui.time[i];
          }
          ui.url=url;
          ui.time=time;
        }
        ui.url[ui.url.length-1]=st.nextToken ();
        if (!st.nextToken ().equals ("TIME")) throw new ProtocolException ("Se esperaba TIME");
        ui.time[ui.url.length-1]=Integer.parseInt (st.nextToken ());
      }
    }
    if (cond) userFile.insert (subject.getEncoded (),DataBase.toByteArray (ui));
  }

  public static void main (String arg[])
  {
    TCInsert tci;
    try
    {
      if (arg.length == 0) tci=new TCInsert ("directorio.dat");
      else tci=new TCInsert (arg[0]);
      tci.read (System.in);
    }
    catch (Exception e)
    {
      System.out.println (e);
    }
  }
}
