package es.cica.tcs;

import java.io.*;

class CMem implements Serializable
{
  byte key[][];
  byte data[][];
  long secondKey[];

  public CMem ()
  {
    key=null;
    data=null;
    secondKey=null;
  }

  public CMem (byte b[])
  {
    toCMem (b);
  }

  public byte[] toByteArray ()
  {
    int i,j;
    try
    {
    ByteArrayOutputStream b=new ByteArrayOutputStream ();
    DataOutputStream f=new DataOutputStream (b);
    f.writeInt (key.length);
    for (i=0;i<key.length;i++)
    {
      f.writeInt (key[i].length);
      if (data[i]==null) f.writeInt (0); else f.writeInt (data[i].length);
      f.writeLong (secondKey[i]);
    }
    for (i=0;i<key.length;i++)
    {
      for (j=0;j<key[i].length;j++) f.writeByte (key[i][j]);
      if (data[i]!=null)
        for (j=0;j<data[i].length;j++) f.writeByte (data[i][j]);
    }
    f.flush ();
    byte r[]=b.toByteArray ();
    f.close ();
    b.close ();
    return r;
    }
    catch (IOException e)
    {
      return null;
    }
  }

  public void toCMem (byte r[])
  {
    int i,j;
    try
    {
    ByteArrayInputStream b=new ByteArrayInputStream (r);
    DataInputStream f=new DataInputStream (b);
    i=f.readInt ();
    key=new byte [i][];
    data=new byte [i][];
    secondKey=new long[i];
    for (i=0;i<key.length;i++)
    {
      key[i]=new byte[f.readInt ()];
      j=f.readInt ();
      if (j!=0) data[i]=new byte[j];
      secondKey[i]=f.readLong ();
    }
    for (i=0;i<key.length;i++)
    {
      for (j=0;j<key[i].length;j++) key[i][j]=f.readByte ();
      if (data[i]!=null)
        for (j=0;j<data[i].length;j++) data[i][j]=f.readByte ();
    }
    f.close ();
    b.close ();
    }
    catch (IOException e)
    {
      return;
    }
  }

  public static Object toObject (byte obj[])
  {
    try
    {
      Object r;
      ByteArrayInputStream b=new ByteArrayInputStream (obj);
      ObjectInputStream i=new ObjectInputStream (b);
      r=i.readObject ();
      i.close ();
      b.close ();
      return r;
   }
   catch (Exception e)
   {
     return null;
   }
  }

}

