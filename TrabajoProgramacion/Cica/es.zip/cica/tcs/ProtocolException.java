package es.cica.tcs;

public class ProtocolException extends Exception {
 public ProtocolException () { super ("TCS Protocol error"); }
 public ProtocolException (String msg) { super ("TCS Protocol error: "+msg); }
}
