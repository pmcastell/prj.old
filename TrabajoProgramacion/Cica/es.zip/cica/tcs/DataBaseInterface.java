package es.cica.tcs;

import java.io.*;

import es.cica.tcs.util.*;
import iaik.security.provider.IAIK;

import iaik.asn1.structures.*;



public interface DataBaseInterface
{
   public void open(String f) throws IOException;
   public RegDirectorio search(int ind) throws IOException;
   public RegDirectorio get() throws IOException;
   public void goTop();
   public RegDirectorio search(Name n) throws IOException;
   public RegDirectorio search(RegDirectorio ind) throws IOException;
   public void delete(Name n) throws IOException;
   public void delete(RegDirectorio usuario) throws IOException;
   public void insert(RegDirectorio usuario) throws IOException;
   public void modify(RegDirectorio usuario) throws IOException;
   public void compact () throws IOException;
}
