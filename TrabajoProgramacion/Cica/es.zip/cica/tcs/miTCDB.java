
//Title:       Your Product Name
//Version:     
//Copyright:   Copyright (c) 1998
//Author:      Your Name
//Company:     Your Company
//Description: Your description
package es.cica.tcs;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;

//import com.sun.java.swing.UIManager;
public class miTCDB extends JApplet {
 boolean isStandalone = false;
//Get a parameter value
 
 public String getParameter(String key, String def) {
  return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
 }

 //Construct the applet
 
 public miTCDB() {
 }
//Initialize the applet
 
 public void init() {
  try {
  jbInit();
  }
  catch (Exception e) {
  e.printStackTrace();
  }
 }
 //static { 
 //  try { 
 //    //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.metal.MetalLookAndFeel());
 //    //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.motif.MotifLookAndFeel());
 //    UIManager.setLookAndFeel(new com.sun.java.swing.plaf.windows.WindowsLookAndFeel());
 //  }
 //  catch (Exception e) {}
 //}
//Component initialization
 
 private void jbInit() throws Exception {
  this.setSize(400,300);
 }
//Start the applet
 
 public void start() {
 }
//Stop the applet
 
 public void stop() {
 }
//Destroy the applet
 
 public void destroy() {
 }
//Get Applet information
 
 public String getAppletInfo() {
  return "Applet Information";
 }
//Get parameter info
 
 public String[][] getParameterInfo() {
  return null;
 }
//Main method
 
 public static void main(String[] args) {
  miTCDB applet = new miTCDB();
  applet.isStandalone = true;
  JFrame frame = new JFrame();
  frame.setTitle("Applet Frame");
  frame.getContentPane().add(applet, BorderLayout.CENTER);
  applet.init();
  applet.start();
  frame.setSize(400,320);
  Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
  frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
  frame.setVisible(true);
 }
}

 