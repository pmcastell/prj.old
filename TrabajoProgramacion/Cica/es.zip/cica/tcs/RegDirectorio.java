package es.cica.tcs;

import java.io.Serializable;
import iaik.asn1.structures.Name;
import iaik.x509.PublicKeyInfo;
import iaik.pkcs.pkcs8.EncryptedPrivateKeyInfo;
import iaik.security.rsa.RSAPublicKey;
import iaik.asn1.CodingException;
import java.io.*;

public class RegDirectorio implements Serializable
{
  private transient Name name; //S
  private byte password[]; //O
  private PublicKeyInfo publicKey; //SX
  private EncryptedPrivateKeyInfo privateKey;
  private int time[]; //S
  private String url[]; //S
  private String otherData; //O
  private RSAPublicKey publicRSAKey; //SX

  public Name getName() {
     return this.name;
  }
  public void setName(Name n) {
     this.name=n;
  }
  public byte[] getPassword() {
     return this.password;
  }
  public void setPassword(byte [] p) {
     this.password=p;
  }   
  public PublicKeyInfo getPublicKey() {
     return this.publicKey;
  }
  public void setPublicKey(PublicKeyInfo k) {
     this.publicKey=k;
  }
  public EncryptedPrivateKeyInfo getPrivateKey() {
     return this.privateKey;
  }
  public void setPrivateKey(EncryptedPrivateKeyInfo k) {
     this.privateKey=k;
  }   
  public  int[] getTime() {
     return this.time;
  }
  public void setTime(int [] t) {
     this.time=t;
  }
  public String[] getUrl() {
     return this.url;
  }
  public void setUrl(String [] u) {
     this.url=u;
  }
  public String getOtherData() {
     return this.otherData;
  }
  public void setOtherData(String o) {
     this.otherData=o;
  }
  public RSAPublicKey getPublicRSAKey() {
     return this.publicRSAKey;
  }
  public void setPublicRSAKey(RSAPublicKey r) {
     this.publicRSAKey=r;
  }   




  public RegDirectorio()
  {
  }
  /**
  * Constructor que recibe un array para ser utilizado por la clase
  * DataBase que s�lo sabe leer y escribir bytes...
  */
  public RegDirectorio(byte ba[]) {
     Object obj=null;
     try {
        byte r[];
        ByteArrayInputStream b=new ByteArrayInputStream (ba);
        ObjectInputStream o=new ObjectInputStream (b);
        try {
          obj=o.readObject();
        } catch (ClassNotFoundException ex) {
        }
        o.close ();
        b.close ();
     } catch (Exception e) {
        return;
     }
     if (obj!=null) {
        RegDirectorio rdo=(RegDirectorio) obj;
        this.name=rdo.name;
        this.password=rdo.password;
        this.publicKey=rdo.publicKey;
        this.privateKey=rdo.privateKey;
        this.time=rdo.time;
        this.url=rdo.url;
        this.publicRSAKey=rdo.publicRSAKey;
     }
  }
  /**
  * Complementa al constructor anterior que recibe un array para ser utilizado
  * por la clase DataBase que s�lo sabe leer y escribir bytes...
  */
  public byte[] toByteArray ()
  {
     try {
        byte r[];
        ByteArrayOutputStream b=new ByteArrayOutputStream ();
        ObjectOutputStream o=new ObjectOutputStream (b);
        o.writeObject (this);
        o.flush ();
        r=b.toByteArray ();
        o.close ();
        b.close ();
        return r;
     } catch (IOException e) {
        return null;
     }
  }
 /**
 *  Estos dos m�todos son para la serializaci�n de la clase
 *  ya que Name no es serializable se opta por escribirlo
 *  como un array de bytes que devuelve el m�todo getEncoded()
 */
  private void writeObject(ObjectOutputStream s) throws IOException {
     try {
        s.defaultWriteObject();
        s.writeObject(name.getEncoded());
     } catch (Exception ex) {
        System.out.println(ex);
     }
  }
  private void readObject(ObjectInputStream s) throws IOException,
                                                       ClassNotFoundException {
     try {
        s.defaultReadObject();
        try {
           name=new Name((byte [])s.readObject());
        } catch (CodingException ex) {
        }
     } catch (Exception ex) {
        System.out.println(ex);
     }
  }


  String toLineas(String s, int maxLen)
  {
     String res="";
     int lenS=s.length(), i=0;
     try {
     if (lenS>maxLen) {
        for(i=0; i<lenS; i+=maxLen) {
           if (i+maxLen<lenS) {
              res+=s.substring(i,maxLen)+'\n';
           } else {
              res+=s.substring(i)+'\n';
           }
        }
     } else {
        return s;
     }
     return res;
     } catch (Exception ex) {
        System.out.println("mierda una excepci�n"+i);
        return res+s.substring(i);
     }
  }


  public String toString()
  {
     String res="";
     res="Nombre: "+name+"\n";
     res+="PassWord: "+password+"\n";
     if (publicKey!=null) {
        res+="PublicKey: "+toLineas(publicKey.toString(),80)+"\n";
     } else {
        res+="PublicKey: null\n";
     }
     if (privateKey!=null) {
        res+="PrivateKey: "+toLineas(privateKey.toString(),80)+"\n";
     } else {
        res+="PrivateKey: null\n";
     }
     if (time!=null) {
        res+="Time: "+time.toString()+"\n";
     } else {
        res+="Time: null\n";
     }
     if (url!=null) {
        res+="Urls: "+url.toString()+"\n";
     } else {
        res+="Urls: null\n";
     }
     if (publicRSAKey!=null) {
        res+="PublicRSAKey: "+publicRSAKey.toString()+"\n";
//        toLineas(publicRSAKey.toString(),80)+"\n";
     } else {
        res+="PublicRSAKey: null\n";
     }
     res+="OtherData: "+otherData+"\n";
     return res;
  }
  public void print()
  {
     System.out.print("Nombre: "+name+"\n");
     System.out.print("PassWord: "+password+"\n");
     if (publicKey!=null) {
        System.out.println("PublicKey: "+publicKey+"\n");
     } else {
        System.out.print("PublicKey: null\n");
     }
     if (privateKey!=null) {
        System.out.print("PrivateKey: "+privateKey+"\n");
     } else {
        System.out.print("PrivateKey: null\n");
     }
     if (time!=null) {
        System.out.print("Time: ");
        for(int i=0;i<time.length;i++) {
           System.out.print(Integer.toString(time[i]));
           if (i<time.length-1) {
              System.out.print(",");
           }
        }
        System.out.println(".");
     } else {
        System.out.print("Time: null\n");
     }
     if (url!=null) {
        System.out.print("Urls: ");
        for(int i=0; i<url.length; i++) {
           System.out.print(url[i]);
           if (i<url.length-1) {
              System.out.print(",");
           }   
        }
        System.out.println(".");
     } else {
        System.out.print("Urls: null\n");
     }
     if (publicRSAKey!=null) {
        System.out.print("PublicRSAKey: "+publicRSAKey.toString()+"\n");
     } else {
        System.out.print("PublicRSAKey: null\n");
     }
     System.out.print("\nOtherData: "+otherData+"\n");

  }

}
