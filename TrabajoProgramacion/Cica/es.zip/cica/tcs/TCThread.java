package es.cica.tcs;

import java.io.*;
import java.net.*;
import java.security.*;
import java.security.cert.*;
import java.util.StringTokenizer;

import iaik.asn1.*;
import iaik.asn1.structures.*;
import iaik.security.ssl.*;
import iaik.security.rsa.*;
import iaik.x509.*;
import iaik.utils.*;

import es.cica.tcs.util.*;
import es.cica.tcs.DataBaseInterface;

class TCThread extends Thread
{
  public static final int
    TC=0,
    IR=1,
    CONTROL=2,
    TC_CONNECTION=3,
    IR_CONNECTION=4,
    CONTROL_CONNECTION=5;
  private int service,soTimeOut;
  private ServerSocket serverSocket;
  private SSLServerSocket sslServerSocket;
  private TCServer tcs;
  private Socket socket;
  private SSLSocket sslSocket;
  private TCLog log;

  public TCThread (TCLog l,Socket s,int se,TCServer t)
  {
    socket=s;
    service=se;
    log=l;
    tcs=t;
  }

  public TCThread (TCLog l,ServerSocket s,int se,TCServer t,int so)
  {
    serverSocket=s;
    service=se;
    log=l;
    tcs=t;
    soTimeOut=so;
  }

  public TCThread (TCLog l,SSLSocket s,TCServer t)
  {
    sslSocket=s;
    service=CONTROL_CONNECTION;
    log=l;
    tcs=t;
  }

  public TCThread (TCLog l,SSLServerSocket s,TCServer t,int so)
  {
    sslServerSocket=s;
    service=CONTROL;
    log=l;
    tcs=t;
    soTimeOut=so;
  }

  public synchronized void run ()
  {
    if (service==CONTROL)
      controlServer ();
    else if (service==TC)
      tcServer ();
    else if (service==IR)
      irServer ();
    else if (service==TC_CONNECTION)
      tc ();
    else if (service==IR_CONNECTION)
      ir ();
    else if (service==CONTROL_CONNECTION)
      control ();
  }

  private synchronized void controlServer ()
  {
    for (;;)
    {
      try
      {
        SSLSocket ssl=(SSLSocket)sslServerSocket.accept();
        ssl.setSoTimeout (soTimeOut);
        Thread tc=new TCThread (log,ssl,tcs);
        tc.start ();
yield ();
      }
      catch (SocketException e)
      {
        break;
      }
      catch (IOException e)
      {
        log.println ("Error de E/S en control. #Excepcion-->"+e.getMessage ());
        break;
      }
    }
  }

  private synchronized void tcServer ()
  {
    for (;;)
    {
      try
      {
        Socket s=serverSocket.accept();
        s.setSoTimeout (soTimeOut);
        Thread tc=new TCThread (log,s,TCThread.TC_CONNECTION,tcs);
        tc.start ();
yield ();
      }
      catch (SocketException e)
      {
        break;
      }
      catch (IOException e)
      {
        log.println ("Error de E/S en la acreditacion. #Excepcion-->"+e.getMessage ());
        break;
      }
    }
  }

  private synchronized void irServer ()
  {
    for (;;)
    {
      try
      {
        Socket s=serverSocket.accept();
        s.setSoTimeout (soTimeOut);
        Thread tc=new TCThread (log,s,TCThread.IR_CONNECTION,tcs);
        tc.start ();
yield ();
      }
      catch (SocketException e)
      {
        break;
      }
      catch (IOException e)
      {
        log.println ("Error de E/S en la certificacion. #Excepcion-->"+e.getMessage ());
        break;
      }
    }
  }

  private synchronized void control ()
  {
    try
    {
      BufferedReader reader=new BufferedReader (new InputStreamReader (sslSocket.getInputStream ()));
      PrintWriter writer=new PrintWriter (sslSocket.getOutputStream ());
      log.println ("#CONTROL# Comienzo de Sesion de control.");
      String line=reader.readLine();
      if (line.equalsIgnoreCase (TCServer.CONFIG))
      {
        try
        {
          tcs.config (reader);
        }
        catch (NullPointerException e)
        {
          writer.println ("-ERR Error de formato en la configuracion.");
          log.println ("#CONTROL# Error cargando la configuracion.");
        }
        catch (Exception e)
        {
          writer.println ("-ERR "+e.getMessage ());
          log.println ("#CONTROL# Error cargando la configuracion."+e.getMessage ());
        }
        writer.println ("+OK");
        log.println ("#CONTROL# Reconfiguracion en proceso.");
        log.println ("#CONTROL# Fin de Sesion de control.");
        reader.close ();
        writer.close ();
        tcs.tcServer.close ();
        tcs.irServer.close ();
        tcs.cServer.close ();
        try {Thread.sleep (1000);} catch (Exception e){}
        tcs.up ();
      }
      else if (line.equalsIgnoreCase ("INSERT"))
      {
        log.println ("#CONTROL# Insertando nuevo usuario.");
        RegDirectorio us=new RegDirectorio();
        Name name=null;
        StringTokenizer st;
        String var;
        while ((line=reader.readLine ())!=null)
        {
          st=new StringTokenizer (line," \t\r");
          if (!st.hasMoreTokens ()) continue;
          var=st.nextToken ();
          if (var.equals ("END")) break;
          else if (var.equals ("USER"))
          {
            name=TCUtil.toName (line.substring ("USER".length ()));
            log.println ("#CONTROL# Nombre Distinguido. #Usuario-->"+name.toString ());
          }
          else if (var.equals ("URL"))
          {
            if (us.getUrl()==null)
            {
              us.setUrl(new String[1]);
              us.setTime(new int[1]);
              us.getUrl()[0]=st.nextToken ();
              us.getTime()[0]=Integer.parseInt (st.nextToken ());
            }
            else
            {
              String auxUrl[]=new String[us.getUrl().length+1];
              int auxTime[]=new int[us.getUrl().length+1];
              int i;
              for (i=0;i<us.getUrl().length;i++)
              {
                auxUrl[i]=us.getUrl()[i];
                auxTime[i]=us.getTime()[i];
              }
              auxUrl[i]=st.nextToken ();
              auxTime[i]=Integer.parseInt (st.nextToken ());
              us.setUrl(auxUrl);
              us.setTime(auxTime);
            }
          }
          else if (line.startsWith ("-----BEGIN PUBLIC KEY-----"))
          {
            StringBuffer k=new StringBuffer ("");
            for (;;)
            {
              line=reader.readLine ();
              if (line.startsWith ("-----END PUBLIC KEY-----")) break;
              k.append (line+"\n");
            }
            us.setPublicRSAKey(new RSAPublicKey (Util.Base64Decode (k.toString ().getBytes ())));
          }
        }
        if (us.getPublicRSAKey()==null || name==null)
        {
          log.println ("#CONTROL# Control erroneo, faltan parametros.");
          writer.println ("-ERR");
        }
        else
        {
          DataBaseInterface tcDb=tcs.getDataBase();
          tcDb.insert(us);
//          tcDb.insert (name.getEncoded (), tcDb.toByteArray (us));
          log.println ("#CONTROL# Fin de Sesion de control.");
          writer.println ("+OK");
        }
      }
      else if (line.equalsIgnoreCase ("CONSULT"))
      {
        line=reader.readLine ();
        Name name=TCUtil.toName (line.substring ("USER".length ()));
        DataBaseInterface tcDb=tcs.getDataBase();
        RegDirectorio ui=tcDb.search (name);
        if (ui==null)
        {
          writer.println ("-ERR Usuario no encontrado.");
        }
        else
        {
          log.println ("#CONTROL# Reportando datos solicitados. #Usuario-->"+name.toString ());
          if (ui.getUrl()!=null)
            for (int i=0;i<ui.getUrl().length;i++)
              writer.println ("URL "+ui.getUrl()[i]+" "+ui.getTime()[i]);
          writer.println ("+OK");
        }
        log.println ("#CONTROL# Fin de Sesion de control.");
      }
      else if (line.equalsIgnoreCase ("DELETE"))
      {
        line=reader.readLine ();
        Name name=TCUtil.toName (line.substring ("USER".length ()));
        log.println ("#CONTROL# Borrando usuario del sistema. #Usuario-->"+name);
        tcs.getDataBase ().delete (name);
        writer.println ("+OK");
        log.println ("#CONTROL# Fin de Sesion de control.");
      }
      else if (line.equalsIgnoreCase (TCServer.STOP))
      {
        writer.println ("+OK");
        log.println ("#CONTROL# Procesando STOP, tirando el sistema");
        log.println ("#CONTROL# Fin de Sesion de control.");
        System.exit (0);
      }
      else
      {
        writer.println ("-ERR");
        log.println ("#CONTROL# Control erroneo. #Linea-->"+line);
        log.println ("#CONTROL# Fin de Sesion de control.");
      }
      reader.close ();
      writer.close ();
    }
    catch (CodingException e)
    {
      log.println ("#CONTROL# Error de codificacion en Nombre Distinguido. #Excepcion-->"+e.getMessage ());
    }
    catch (InvalidKeyException e)
    {
      log.println ("#CONTROL# Error en clave publica. #Excepcion-->"+e.getMessage ());
    }
    catch (IOException e)
    {
      log.println ("#CONTROL# Error de E/S en control. #Excepcion-->"+e.getMessage ());
    }
  }

  private synchronized void tc ()
  {
    try
    {
      tcs.readPetition (socket);
      socket.close ();
    }
    catch (IOException e)
    {
      log.println ("Error de entrada/salida en la acreditacion.#Excepcion-->"+e);
    }
  }

  private synchronized void ir ()
  {
    try
    {
      BufferedReader reader=new BufferedReader (new InputStreamReader (socket.getInputStream ()));
      String line=reader.readLine();
      if
      (
        line!=null &&
        !line.equals ("") &&
        (
          line.regionMatches(true,0,"post ",0,5) ||
          line.regionMatches(true,0,"POST ",0,5)
        )
      )
      {
        do line=reader.readLine();
        while (!line.startsWith ("Content-length:"));
        StringTokenizer st=new StringTokenizer (line," ");
        st.nextToken ();
        reader.readLine();
        String values[][];
        byte secret[],key[];
        values=TCUtil.readValues (reader,0,Integer.parseInt (st.nextToken ()));
        secret=Util.Base64Decode (TCUtil.value (values,"secret").getBytes ()); 
        int subjectPetition=Integer.parseInt (TCUtil.value (values,"petition"));
        key=TCUtil.value (values,"key").getBytes ();
        tcs.verify (subjectPetition,secret,socket.getInetAddress (),key,socket.getOutputStream ());
      }
      else
      {
        log.println ("Error en la peticion de Certificado Temporal.#Linea-->"+line);
      }
      reader.close ();
      socket.close ();
    }
    catch (IOException e)
    {
      log.println ("Error de entrada/salida en la certificacion.#Excepcion-->"+e);
    }
  }
}
