package es.cica.tcs;

import java.math.BigInteger;
import java.util.*;
import java.net.*;

import iaik.asn1.structures.*;

class TCList
{
  Name user;
  Date valid;
  byte secret[];
  InetAddress address;
  String url;
  int time,petition;
  TCList next;
}
