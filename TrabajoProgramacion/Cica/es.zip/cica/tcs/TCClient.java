package es.cica.tcs;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

import java.util.StringTokenizer;
import java.util.Properties;
import java.math.BigInteger;
import java.security.Provider;
import java.security.Security;
import java.security.NoSuchAlgorithmException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;


import iaik.security.provider.IAIK;
import iaik.asn1.*;
import iaik.asn1.structures.*;
import iaik.pkcs.*;
import iaik.pkcs.pkcs8.*;
import iaik.security.*;
import iaik.security.rsa.*;
import iaik.utils.*;

import es.cica.tcs.util.*;
import es.cica.tcs.gui.*;

public class TCClient
{
  private static final String TITLE="Clave de acceso";
  private static final String LOCALCFSTART="[localConfig]";
  private static final String [][] defPTable = {
    {"protex.petition", "Expecting PETITION"},
    {"protex.secret", "Expecting SECRET"},
    {"irpage.title", "Temporary Certificate Services"},
    {"irpage.alert.aload", "The certificate has been already loaded"},
    {"irpage.alert.bload", "You must load the certificate before proceeding"},
    {"irpage.header", "<h1>Temporary Certificate Service</h1>"},
    {"irpage.submit", "Load Certificate"},
    {"irpage.text", "<p><p>Once the certificate is loaded you can access:" },
    {"main.button.connect", "Connect"},
    {"main.button.cancel", "Cancel"},
    {"main.label.pass", "Passphrase"},
    {"main.label.server", "Server"},
    {"main.label.site", "Site"},
    {"main.label.validity", "Validity (minutes)"},
    {"main.title", "CICA Temporary Certificate Client"},
    {"config.err.general", "Unknown general configuration variable:"},
    {"config.err.local", "Unknown local configuration variable:"},
    {"err.button", "OK"},
    {"err.title", "TCC Error"},
    {"err.msg.numex", "Invalid number"},
    {"err.msg.hostex", "Unknown host..."},
    {"err.msg.filex", "Error writing IR page..."},
    {"err.msg.ioex", "Error connecting to TC Server"},
    {"err.msg.gsex", "Passphrase is incorrect. Please try again"},
    {"err.msg.nocfex", "Configuration not found..."},
    {"err.msg.rdcfex", "Error reading configuration..."},
    {"err.msg.codex", "Invalid DN in configuration..."},
    {"err.msg.invkex", "Invalid key in configuration..."},
    {"err.msg.pkcsex", "Invalid PKCS12 format in configuration..."},
    {"err.msg.gscfex", "Invalid key in configuration..."},
    {"err.msg.noalex", "Invalid key in configuration..."}
  };
  private int secretLength=16,tcsPort,atcsPort[],time=15,petition,irPort,airPort[];
  private String tcsName,atcsName[],atcsAlias[],url,aurl[],aurlAlias[],localFile,localURL, nsPath="netscape", propPath="TCClient.properties";
  private Name userName;
  private EncryptedPrivateKeyInfo encryptedPrivateKey;
  private PrivateKeyInfo userPrivateKey;
  private byte secret[];
  private static Properties defProp = null, curProp = null;
  private ApplicationFrame frame;
  private TextField passwordField,tcsField,tcsPortField,irPortField,urlField,timeField;
  private Choice tcsChoice,urlChoice;
  private Button buttonConnect,buttonCancel;

  private static void setDefProperties () {
    defProp = new Properties ();
    for (int i = 0; i < defPTable.length; i++)
      defProp.put (defPTable[i][0], defPTable[i][1]);
    curProp = defProp;
  }

  public void connect () throws UnknownHostException,IOException,ProtocolException
  {
    PrintWriter writer;
    BufferedReader reader;
    Socket socket;

    socket=new Socket (tcsName,tcsPort);
    reader=new BufferedReader (new InputStreamReader (socket.getInputStream()));
    writer=new PrintWriter (socket.getOutputStream ());
    writer.println ("SUBJECT "+userName);
    writer.println ("TIME "+time);
    writer.println ("URL "+url);
    writer.println ("SECRETLENGTH "+secretLength);
    writer.flush ();
    String line,var;
    StringTokenizer st;
    line=reader.readLine ();
    st=new StringTokenizer (line," \t\r");
    var=st.nextToken ();
    if (var.equals ("PETITION")) petition=Integer.parseInt (st.nextToken ());
    else throw new ProtocolException (curProp.getProperty ("protex.petition"));
    line=reader.readLine ();
    if (!line.startsWith ("-----BEGIN SECRET-----"))
      throw new ProtocolException (curProp.getProperty ("protex.secret"));
    StringBuffer k=new StringBuffer ("");
    for (;;)
    {
     line=reader.readLine ();
     if (line.startsWith ("-----END SECRET-----")) break;
     k.append (line+"\n");
    }
    byte sec[]=Util.Base64Decode (k.toString ().getBytes ());
    secret=new byte[2*sec.length];
    CryptoUtils.copyBlock (sec,0,secret,0,sec.length);
    CryptoUtils.randomBlock (secret,sec.length,sec.length);
    secret=Util.Base64Encode (((RSAPrivateKey)userPrivateKey).crypt (new BigInteger (secret)).toByteArray ());
    StringBuffer sb=new StringBuffer ("");
    for (int i=0;i<secret.length;i++) if (secret[i]!=10) sb.append ((char)secret[i]);
    localFile=System.getProperty ("user.dir");
    localFile.replace (':','|');
    localFile=new String (localFile+File.separator+"cert.htm");
    PrintWriter fc=new PrintWriter (new FileOutputStream (localFile));
    fc.println ("<html>");
    fc.println ("<head><title>");
    fc.println (curProp.getProperty ("irpage.title"));
    fc.println ("</title><script language=\"JavaScript\">");
    fc.println ("var ca = 0;");
    fc.println ("function load ()");
    fc.println ("{");
    fc.println ("if (ca == 0) {");
    fc.println ("ca = 1;");
    fc.println ("return true;");
    fc.println ("}");
    fc.println ("else {");
    fc.println ("alert (\""+curProp.getProperty ("irpage.alert.aload")+"\");");
    fc.println ("return false;");
    fc.println ("}");
    fc.println ("}");
    fc.println ("function go ()");
    fc.println ("{");
    fc.println ("if (ca == 0) {");
    fc.println ("alert (\""+curProp.getProperty ("irpage.alert.bload")+"\");");
    fc.println ("return false;");
    fc.println ("}");
    fc.println ("else {");
    fc.println ("return true;");
    fc.println ("}");
    fc.println ("}");
    fc.println ("</script></head>");
    fc.println ("<body><center>");
    fc.println (curProp.getProperty ("irpage.header"));
    fc.println ("<form method=post action=http://"+tcsName+":"+irPort+"/ onSubmit=\"return load()\">");
    fc.println ("<input name=petition value="+petition+" type=hidden>");
    fc.println ("<input name=secret value="+sb+" type=hidden>");
    fc.println ("<keygen name=key>");
    fc.println ("<input type=submit value=\""+
                curProp.getProperty ("irpage.submit")+"\">");
    fc.println (curProp.getProperty ("irpage.text"));
    fc.println ("<br><a href=\""+url+"\" onClick=\"return go()\">"+url+"</a>");
    fc.println ("</form></center></body>");
    fc.println ("</html>");
    fc.close ();
    Runtime r=Runtime.getRuntime ();
    r.exec (nsPath+" "+localURL+localFile);
  }

  public void windowInit ()
  {
    int i;
    passwordField=new TextField (40);
    passwordField.setEchoChar ('*');
    tcsChoice=new Choice ();
    for (i=0;i<atcsAlias.length;i++) tcsChoice.add (atcsAlias[i]);
    tcsField=new TextField (atcsName[0],20);
    tcsPortField=new TextField (""+atcsPort[0],6);
    irPortField=new TextField (""+airPort[0],6);
    urlChoice=new Choice ();
    for (i=0;i<aurlAlias.length;i++) urlChoice.add (aurlAlias[i]);
    urlField=new TextField (aurl[0],20);
    timeField=new TextField (""+time,4);
    buttonConnect=new Button (curProp.getProperty("main.button.connect"));
    buttonCancel=new Button (curProp.getProperty("main.button.cancel"));

    Group c=new Group (Group.VERTICAL);
    Group c0=new Group (Group.HORIZONTAL);
    Group c1=new Group (Group.HORIZONTAL);
    Group c2=new Group (Group.VERTICAL);
    Group c3=new Group (Group.HORIZONTAL);
    Group c4=new Group (Group.HORIZONTAL);
    Group c5=new Group (Group.VERTICAL);
    Group c6=new Group (Group.VERTICAL);
    Group c7=new Group (Group.VERTICAL);
    Group c8=new Group (Group.HORIZONTAL);
    Group c9=new Group (Group.HORIZONTAL);

    c3.add (new Label (curProp.getProperty ("main.label.pass")),Group.W);
    c3.add (passwordField,Group.H);
    c2.add (new Label (curProp.getProperty ("main.label.server")),Group.W);
    c5.add (tcsChoice,Group.E);
    c6.add (tcsField,Group.H);
    c8.add (tcsPortField,Group.H);
    c8.add (irPortField,Group.H);
    c2.add (new Label (curProp.getProperty ("main.label.site")),Group.W);
    c5.add (urlChoice,Group.E);
    c6.add (urlField,Group.H);
    c9.add (new Label (curProp.getProperty ("main.label.validity")),Group.H);
    c9.add (timeField,Group.H);
    c1.add (buttonConnect,Group.C);
    c1.add (buttonCancel,Group.C);

    c.add (c3);
    c.add (c0);
    c.add (c1);
    c4.add (c2);
    c0.add (c4);
    c4.add (c5);
    c4.add (c6);
    c4.add (c7);
    c7.add (c8);
    c7.add (c9);
    frame=new ApplicationFrame (curProp.getProperty ("main.title"),c);
    frame.center ();
  }

  public void windowGet () throws NoSuchAlgorithmException,GeneralSecurityException,NumberFormatException
  {
    frame.setVisible (true);
    AWTEvent event;
    Object o;
    for (;;)
    {
      event=frame.eventWait ();
      if (event.getID ()==WindowEvent.WINDOW_CLOSING) System.exit (0);
      o=event.getSource ();
      if (o.equals (buttonCancel)) System.exit (0);
      if (o.equals (passwordField) || o.equals (tcsField) || o.equals (urlField) || o.equals (buttonConnect) || o.equals (tcsPortField) || o.equals (irPortField)) break;
      if (o.equals (urlChoice))
      {
        urlField.setText (aurl[urlChoice.getSelectedIndex ()]);
      }
      if (o.equals (tcsChoice))
      {
        tcsField.setText (atcsName[tcsChoice.getSelectedIndex ()]);
        tcsPortField.setText (""+atcsPort[tcsChoice.getSelectedIndex ()]);
        irPortField.setText (""+airPort[tcsChoice.getSelectedIndex ()]);
      }
    }
    frame.setVisible (false);
    userPrivateKey=encryptedPrivateKey.decrypt (passwordField.getText ());
    tcsName=tcsField.getText ();
    tcsPort=Integer.parseInt (tcsPortField.getText ());
    irPort=Integer.parseInt (irPortField.getText ());
    url=urlField.getText ();
    time=Integer.parseInt (timeField.getText ());
  }

  public void urlAppend (String name,String alias)
  {
    if (alias==null) alias=name;
    if (aurl==null)
    {
      aurl=new String[1];
      aurlAlias=new String[1];
      aurl[0]=new String (name);
      aurlAlias[0]=new String (alias);
    }
    else
    {
      String auxUrl[]=new String[aurl.length+1];
      String auxAlias[]=new String[aurl.length+1];
      int i;
      for (i=0;i<aurl.length;i++)
      {
        auxUrl[i]=aurl[i];
        auxAlias[i]=aurlAlias[i];
      }
      auxUrl[i]=new String (name);
      auxAlias[i]=new String (alias);
      aurl=auxUrl;
      aurlAlias=auxAlias;
    }
  }

  public void tcsAppend (String name,int tcsp,int irp,String alias)
  {
    if (alias==null) alias=name;
    if (atcsName==null)
    {
      atcsName=new String[1];
      atcsPort=new int[1];
      airPort=new int[1];
      atcsAlias=new String[1];
      atcsName[0]=new String (name);
      atcsPort[0]=tcsp;
      airPort[0]=irp;
      atcsAlias[0]=new String (alias);
    }
    else
    {
      String auxName[]=new String[atcsName.length+1];
      int auxT[]=new int[atcsName.length+1];
      int auxI[]=new int[atcsName.length+1];
      String auxAlias[]=new String[atcsName.length+1];
      int i;
      for (i=0;i<atcsName.length;i++)
      {
        auxName[i]=atcsName[i];
        auxT[i]=atcsPort[i];
        auxI[i]=airPort[i];
        auxAlias[i]=atcsAlias[i];
      }
      auxName[i]=new String (name);
      auxT[i]=tcsp;
      auxI[i]=irp;
      auxAlias[i]=new String (alias);
      atcsName=auxName;
      atcsPort=auxT;
      airPort=auxI;
      atcsAlias=auxAlias;
    }
  }

  public void config (InputStream fin) throws IOException,CodingException,InvalidKeyException,GeneralSecurityException,NoSuchAlgorithmException,PKCSException
  {
    BufferedReader br=new BufferedReader (new InputStreamReader (fin));
    String line,var,alias;
    StringTokenizer st,sta;

    if (defProp == null) setDefProperties ();
//
// Configuracion general (producida al generar el token del usuario)
//
    while ((line=br.readLine ())!=null)
    {
      if (line.length () == 0) continue;
      if (line.startsWith ("#")) continue;
      if (line.startsWith (LOCALCFSTART)) break;
      if (line.startsWith (CicaP12.startLine))
      {
        StringBuffer k=new StringBuffer ();
        for (;;)
        {
          line=br.readLine ();
          if (line.startsWith (CicaP12.endLine)) break;
          k.append (line+"\n");
        }
        encryptedPrivateKey=new CicaP12 (k.toString ().getBytes ()).getEncryptedPrivateKey ();
        continue;
      }
      st=new StringTokenizer (line," \t");
      if (!st.hasMoreTokens ()) continue;
      var=st.nextToken ();
      if (var.equals ("END")) break;
      if (var.equals ("TCSERVER"))
      {
        var=st.nextToken ();
        sta=new StringTokenizer (var,":");
        if (st.hasMoreTokens ())
          alias=st.nextToken ();
        else
          alias=null;
        tcsAppend (sta.nextToken (),Integer.parseInt (sta.nextToken ()),Integer.parseInt (sta.nextToken ()),alias);
      }
      else if (var.equals ("LOCALURL")) localURL=st.nextToken ();
      else if (var.equals ("URL"))
      {
        var=st.nextToken ();
        if (st.hasMoreTokens ())
          alias=st.nextToken ();
        else
          alias=null;
        urlAppend (var,alias);
      }
      else if (var.equals ("SECRETLENGTH")) secretLength=Integer.parseInt (st.nextToken ());
      else if (var.equals ("TIME")) time=Integer.parseInt (st.nextToken ());
      else if (var.equals ("USER")) userName=TCUtil.toName (line.substring ("USER".length ()));
      else System.err.println (curProp.getProperty ("config.err.general")+
                               " "+var);
    }
//
// Configuracion local (producida al instalar el software)
//
    while ((line=br.readLine ())!=null)
    {
      if (line.length () == 0) continue;
      if (line.startsWith ("#")) continue;
      if (line.startsWith (LOCALCFSTART)) continue;
      st=new StringTokenizer (line,"=");
      var=st.nextToken ();
      if (var.equals ("netscape")) nsPath = st.nextToken ();
      else if (var.equals ("properties")) propPath = st.nextToken ();
      else System.err.println (curProp.getProperty ("config.err.local")+
                               " "+var);
    }
    br.close ();
    if (curProp == defProp && propPath != null) {
      curProp = new Properties (defProp);
      try { curProp.load (new FileInputStream(propPath)); }
      catch (IOException e) {}
    }
  }

  public String getTCSName ()
  {
    return tcsName;
  }

  public static void main (String arg[])
  {
    Group c=new Group (Group.VERTICAL);
    Label l=new Label ();
    l.setAlignment (Label.CENTER);
    c.add (l);
    TCClient.setDefProperties ();
    Button b=new Button (defProp.getProperty ("err.button"));
    c.add (b,Group.C);
    ApplicationFrame af=new ApplicationFrame (defProp.getProperty ("err.title"),
                                              c);
    af.center ();
    String file;
    if (arg==null || arg.length==0)
      file="client.cfg";
    else
      file=arg[0];

    try
    {
      Provider providerIAIK=new IAIK ();
      Security.addProvider (providerIAIK);
      TCClient tcc=new TCClient ();
      FileInputStream f;
      f=new FileInputStream (file);
      tcc.config (f);
      tcc.windowInit ();
      for (;;)
        try
        {
          tcc.windowGet ();
          tcc.connect ();
          System.exit (0);
        }
        catch (NumberFormatException e)
        {
          l.setText (curProp.getProperty ("err.msg.numex"));
          l.invalidate ();
          af.pack ();
          af.setVisible (true);
          for (;;) if (b.equals (af.eventWait ().getSource ())) break;
          af.setVisible (false);
        }
        catch (UnknownHostException e)
        {
          l.setText (curProp.getProperty ("err.msg.hostex")+" "+
                     tcc.getTCSName ());
          l.invalidate ();
          af.pack ();
          af.setVisible (true);
          for (;;) if (b.equals (af.eventWait ().getSource ())) break;
          af.setVisible (false);
        }
        catch (FileNotFoundException e)
        {
          l.setText (curProp.getProperty ("err.msg.filex")+" "+e.getMessage());
          l.invalidate ();
          af.pack ();
          af.setVisible (true);
          for (;;) if (b.equals (af.eventWait ().getSource ())) break;
          af.setVisible (false);
        }
        catch (IOException e)
        {
          l.setText (curProp.getProperty ("err.msg.ioex")+" "+tcc.getTCSName ()+
                     "... "+e.getMessage());
          l.invalidate ();
          af.pack ();
          af.setVisible (true);
          for (;;) if (b.equals (af.eventWait ().getSource ())) break;
          af.setVisible (false);
        }
        catch (GeneralSecurityException e)
        {
          l.setText (curProp.getProperty ("err.msg.gsex"));
          l.invalidate ();
          af.pack ();
          af.setVisible (true);
          for (;;) if (b.equals (af.eventWait ().getSource ())) break;
          af.setVisible (false);
        }
        catch (ProtocolException e)
        {
          l.setText (e.getMessage ());
          l.invalidate ();
          af.pack ();
          af.setVisible (true);
          for (;;) if (b.equals (af.eventWait ().getSource ())) break;
          af.setVisible (false);
        }
    }
    catch (FileNotFoundException e)
    {
      l.setText (curProp.getProperty ("err.msg.nocfex")+" "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (IOException e)
    {
      l.setText (curProp.getProperty ("err.msg.rdcfex")+" "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (CodingException e)
    {
      l.setText (curProp.getProperty ("err.msg.codex")+" "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (InvalidKeyException e)
    {
      l.setText (curProp.getProperty ("err.msg.invkex")+" "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (PKCSException e)
    {
      l.setText (curProp.getProperty ("err.msg.pkcsex")+" "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (NoSuchAlgorithmException e)
    {
      l.setText (curProp.getProperty ("err.msg.noalex")+" "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }    
    catch (GeneralSecurityException e)
    {
      l.setText (curProp.getProperty ("err.msg.gscfex")+" "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    System.exit (-1);
  }
}
