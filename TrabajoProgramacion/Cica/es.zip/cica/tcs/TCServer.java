package es.cica.tcs;

import java.util.StringTokenizer;
import java.util.Date;
import java.util.TimeZone;
import java.text.*;
import java.math.BigInteger;
import java.io.*;
import java.net.*;
import java.security.Security;
import java.security.Provider;
import java.security.InvalidKeyException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;

import java.security.cert.*;

import iaik.security.ssl.*;
import iaik.security.provider.IAIK;
import iaik.security.*;
import iaik.security.cipher.*;
import iaik.security.rsa.*;
import iaik.security.dsa.*;
import iaik.security.dh.*;
import iaik.asn1.*;
import iaik.asn1.structures.*;
import iaik.pkcs.*;
import iaik.pkcs.pkcs8.*;
import iaik.x509.*;
import iaik.x509.X509Certificate;
import iaik.utils.*;

import es.cica.tcs.util.*;

public class TCServer
{
  public static final String
    CONFIG="config",
    STOP="stop",
    DEFCFFILE="tcserver.cfg";
  private int
    tccPort=4433,
    irPort=4434,
    controlPort=4435,
    timeOut=5*60*1000,
    soTimeOut=20*1000,
    secretLength=32,
    logLevel=0;
  private DataBaseInterface userFile=new RegDirDataBase();
  private Name caName[];
  private String caURL[],htmlError="";
  private PrivateKeyInfo caPrivateKey[];
  private CicaP12 tcsPKCS12;
  private TCList userSecret=null;
  private int petition=(new Date ()).hashCode ();
  private static final int
    TIMELOG=2,
    OVERWRITELOG=0,
    VERIFYLOG=1,
    WRITELOG=3,
    RELEASE=1,
    PATCH=0;
  private String passwordP=null,passwordTcs=null;
  private String passwFile=null,configFile=null;
  private TCLog log=new TCLog ();
  public ServerSocket tcServer,irServer;
  public SSLServerSocket cServer;
  public static final String tagError="<!--ERROR//-->",tagRelease="<!--RELEASE-->";

  public TCServer ()
  {
  }

  public DataBaseInterface getDataBase ()
  {
    return userFile;
  }

  public void up ()
  {
    log.println ("Levantando IRServer.");
    certificate ();
    log.println ("Levantando TCServer.");
    accept ();
    log.println ("Levantando Control.");
    control ();
    log.println ("Servidor Levantado.");
  }

  public void readPetition (Socket sk)
  {
    try
    {
      OutputStream fout=sk.getOutputStream ();
      InputStream fin=sk.getInputStream ();
      InetAddress address=sk.getInetAddress ();
      Name subject;
      String url;
      int time,sl;
      BufferedReader br=new BufferedReader (new InputStreamReader (fin));
      PrintWriter pw=new PrintWriter (fout);
      String line,var;
      StringTokenizer st;
      line=br.readLine ();
      st=new StringTokenizer (line," \t\r");
      var=st.nextToken ();
      if (var.equals ("SUBJECT")) subject=TCUtil.toName (line.substring ("SUBJECT".length ()));
      else
      {
        log.println ("Error en la peticion de Certificado Temporal. Se esperaba SUBJECT.#Linea-->"+line);
        return;
      }
      line=br.readLine ();
      st=new StringTokenizer (line," \t\r");
      var=st.nextToken ();
      if (var.equals ("TIME"))
      {
        try
        {
          time=Integer.parseInt (st.nextToken ());
        }
        catch (NumberFormatException e)
        {
          log.println ("Error en la peticion de Certificado Temporal. Procesando TIME.#Linea-->"+line);
          return;
        }
      }
      else
      {
        log.println ("Error en la peticion de Certificado Temporal. Se esperaba SUBJECT.#Linea-->"+line);
        return;
      }
      line=br.readLine ();
      st=new StringTokenizer (line," \t\r");
      var=st.nextToken ();
      if (var.equals ("URL")) url=new String (st.nextToken ());
      else
      {
        log.println ("Error en la peticion de Certificado Temporal. Se esperaba URL.#Linea-->"+line);
        return;
      }
      line=br.readLine ();
      st=new StringTokenizer (line," \t\r");
      var=st.nextToken ();
      if (var.equals ("SECRETLENGTH"))
      {
        try
        {
          sl=Integer.parseInt (st.nextToken ());
        }
        catch (NumberFormatException e)
        {
          log.println ("Error en la peticion de Certificado Temporal. Procesando SECRETLENGTH.#Linea-->"+line);
          return;
        }
      }
      else
      {
        log.println ("Error en la peticion de Certificado Temporal. Se esperaba SECRETLENGTH.#Linea-->"+line);
        return;
      }
      byte r[];
      if (sl<secretLength) sl=secretLength;
      r=new byte[sl];
      CryptoUtils.randomBlock (r);
      r[0]=(byte)((r[0]&0x7f)|0x40);
      appendKey (subject,url,time,r,address);
      r=Util.Base64Encode (r);
      pw.println ("PETITION "+petition);
      petition++;
      pw.println ("-----BEGIN SECRET-----");
      pw.println (new String (r));
      pw.println ("-----END SECRET-----");
      pw.close ();
      br.close ();
      return;
    }
    catch (IOException e)
    {
      log.println ("Error de Entrada/Salida en la peticion de Certificado Temporal.#Excepcion-->"+e);
      return;
    }
    catch (CodingException e)
    {
      log.println ("Error de formato en el SUBJECT.#Excepcion-->"+e);
      return;
    }
  }

  public void control ()
  {
    if (tcsPKCS12==null) return;
    try
    {
      SSLSocket ssl;
      SSLServerContext tcsContext=new SSLServerContext ();
      PrivateKeyInfo pki=tcsPKCS12.getPrivateKey ();
      X509Certificate cert[]=tcsPKCS12.getCertificateChain ();
      TCSTrustDecider tcsDecider=new TCSTrustDecider (pki,tcsPKCS12.getCertificateChain (),tcsPKCS12.getCertificateIssuer ());
      tcsContext.setTrustDecider (tcsDecider);
      byte type[]={ClientTrustDecider.rsa_sign,ClientTrustDecider.dss_sign};
      if (pki instanceof RSAPrivateKey)
      {
        tcsContext.setRSACertificate (cert,(RSAPrivateKey)pki);
      }
      else if (pki instanceof DSAPrivateKey)
      {
        tcsContext.setDSACertificate (cert,(DSAPrivateKey)pki);
      }
      else if (pki instanceof DHPrivateKey)
      {
        tcsContext.setDHCertificate (cert,(DHPrivateKey)pki);
      }
      tcsContext.updateCipherSuites ();
      tcsContext.setRequireClientCertificate (type,tcsPKCS12.getIssuers ());
      cServer=new SSLServerSocket (controlPort,tcsContext);
      Thread c=new TCThread (log,cServer,this,soTimeOut);
      c.start ();
    }
    catch (Exception e)
    {
      log.println ("Error Grave, no se puede levantar el CS en el puerto"+controlPort+".#Excepcion-->"+e);
      System.out.println ("-ERR Error Grave, no se puede levantar el CS en el puerto"+controlPort+".#Excepcion-->"+e);
      System.exit (-1);
    }
  }

  public void config (BufferedReader br)
    throws IOException,PKCSException,CodingException,InvalidKeyException,NumberFormatException,GeneralSecurityException,NoSuchAlgorithmException,NullPointerException
  {
    caName=null;
    caURL=null;
    caPrivateKey=null;
    tcsPKCS12=null;
    String line;
    StringTokenizer st;
    String var;
    while ((line=br.readLine ())!=null)
    {
      if (line.startsWith ("#")) continue;
      st=new StringTokenizer (line," \t\r");
      if (!st.hasMoreTokens ()) continue;
      var=st.nextToken ();
      if (var.equals ("END")) break;
      if (var.equals ("TCCPORT")) tccPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("IRPORT")) irPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("CONTROLPORT")) controlPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("LOG")) logLevel=Integer.parseInt (st.nextToken ());
      else if (var.equals ("LOGFILE"))
        log=new TCLog (st.nextToken ());
      else if (var.equals ("USERFILE")) userFile.open(st.nextToken());
      else if (var.equals ("HTMLERROR"))
        htmlError=new String (Util.readFile (st.nextToken ()));
      else if (var.equals ("TIMEOUT")) timeOut=Integer.parseInt (st.nextToken ());
      else if (var.equals ("SOTIMEOUT")) soTimeOut=Integer.parseInt (st.nextToken ());
      else if (var.equals ("SECRETLENGTH")) secretLength=Integer.parseInt (st.nextToken ());
      else if (var.equals ("ISSUER"))
        readIssuer (br,line.substring ("ISSUER".length ()));
      else if (var.equals ("TCSC"))
        readTcsc (br);
      else
        log.println ("Error de formato. Linea ignorada #Linea-->"+line);
    }
    passwordP=null;
    passwordTcs=null;
  }

  public void config ()
    throws IOException,PKCSException,CodingException,InvalidKeyException,NumberFormatException,GeneralSecurityException,NoSuchAlgorithmException,NullPointerException
  {
    caName=null;
    caURL=null;
    caPrivateKey=null;
    tcsPKCS12=null;
    String line;
    StringTokenizer st;
    String var;
    BufferedReader br = new BufferedReader (new FileReader (configFile));
    while ((line=br.readLine ())!=null)
    {
      if (line.startsWith ("#")) continue;
      st=new StringTokenizer (line," \t\r");
      if (!st.hasMoreTokens ()) continue;
      var=st.nextToken ();
      if (var.equals ("END")) break;
      if (var.equals ("TCCPORT")) tccPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("IRPORT")) irPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("CONTROLPORT")) controlPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("LOG")) logLevel=Integer.parseInt (st.nextToken ());
      else if (var.equals ("LOGFILE"))
        log=new TCLog (st.nextToken ());
      else if (var.equals ("USERFILE")) userFile.open(st.nextToken());
      else if (var.equals ("HTMLERROR"))
        htmlError=new String (Util.readFile (st.nextToken ()));
      else if (var.equals ("TIMEOUT")) timeOut=Integer.parseInt (st.nextToken ());
      else if (var.equals ("SOTIMEOUT")) soTimeOut=Integer.parseInt (st.nextToken ());
      else if (var.equals ("SECRETLENGTH")) secretLength=Integer.parseInt (st.nextToken ());
      else if (var.equals ("ISSUER"))
        readIssuer (br,line.substring ("ISSUER".length ()));
      else if (var.equals ("TCSC"))
        readTcsc (br);
      else
        log.println ("Error de formato. Linea ignorada #Linea-->"+line);
    }
    passwordP=null;
    passwordTcs=null;
  }

  public void readIssuer (BufferedReader f,String s)
    throws PKCSException,CodingException,InvalidKeyException,IOException,NoSuchAlgorithmException,GeneralSecurityException,ArrayIndexOutOfBoundsException
  {
    StringBuffer k=new StringBuffer ("");
    String line;
    for (;;)
    {
     line=f.readLine ();
     k.append (line+"\n");
     if (line.startsWith (CicaP12.endLine)) break;
    }
    Name auxName[];
    String auxURL[];
    PrivateKeyInfo auxPrivateKey[];
    int i=0;
    if (caName==null)
    {
      auxName=new Name[1];
      auxURL=new String[1];
      auxPrivateKey=new PrivateKeyInfo[1];
    }
    else
    {
      auxName=new Name[caName.length+1];
      auxURL=new String[caName.length+1];
      auxPrivateKey=new PrivateKeyInfo[caName.length+1];
      for (;i<caName.length;i++)
      {
        auxName[i]=caName[i];
        auxURL[i]=caURL[i];
        auxPrivateKey[i]=caPrivateKey[i];
      }
    }
    caName=auxName;
    caURL=auxURL;
    caPrivateKey=auxPrivateKey;
    StringTokenizer st;
    st=new StringTokenizer (s," \t\r");
    caURL[i]=st.nextToken ();
    caName[i]=TCUtil.toName (s.substring (s.indexOf (caURL[i])+caURL[i].length ()));
    if (passwordP!=null)
    {
      EncryptedPrivateKeyInfo epki=new CicaP12 (k.toString ().getBytes ()).getEncryptedPrivateKey ();
      caPrivateKey[i]=epki.decrypt (passwordP);
    }
    else
      caPrivateKey[i]=new CicaP12 (k.toString ().getBytes ()).getPrivateKey ();
  }

  public void readTcsc (BufferedReader f)
    throws PKCSException,CodingException,InvalidKeyException,IOException,NoSuchAlgorithmException,GeneralSecurityException,ArrayIndexOutOfBoundsException
  {
    StringBuffer k=new StringBuffer ("");
    String line;
    for (;;)
    {
     line=f.readLine ();
     k.append (line+"\n");
     if (line.startsWith (CicaP12.endLine)) break;
    }
    tcsPKCS12=new CicaP12 (k.toString ().getBytes ());
    if (passwordTcs!=null)
    {
      tcsPKCS12.decrypt (passwordTcs);
    }
  }

  public void periodicTimeOutDelete ()
  {
    for (;;)
    {
      try {Thread.sleep (timeOut/2);}
      catch (Exception e) {}
      timeOutDelete ();
    }
  }

  public synchronized void timeOutDelete ()
  {
    Date d=new Date ();
    while (userSecret!=null)
    {
      if (d.getTime ()-userSecret.valid.getTime ()>timeOut)
      {
        if (logLevel>TIMELOG) log.println ("Tiempo expirado.#Usuario-->"+userSecret.user+"#Nodo-->"+userSecret.address+"#Peticion-->"+userSecret.petition+"#Servicio-->"+userSecret.url+"#Minutos solicitados-->"+userSecret.time);
        userSecret=userSecret.next;
      }
      else break;
    }
    if (userSecret==null) return;
    for (TCList aux=userSecret;aux.next!=null;)
    {
      if (d.getTime ()-aux.next.valid.getTime ()>timeOut)
      {
        if (logLevel>TIMELOG) log.println ("Tiempo expirado.#Usuario-->"+aux.next.user+"#Nodo-->"+aux.next.address+"#Peticion-->"+aux.next.petition+"#Servicio-->"+aux.next.url+"#Minutos solicitados-->"+aux.next.time);
        aux.next=aux.next.next;
      }
      else aux=aux.next;
    }
  }

  public synchronized void appendKey (Name subject,String url,int time,byte sec[],InetAddress address)
  {
    TCList aux=userSecret;
    while (aux!=null)
    {
      if (aux.user.equals (subject))
      {
        if (logLevel>OVERWRITELOG) log.println ("Peticion sobre-escrita.#Ususario-->"+aux.user+"#Nodo-->"+aux.address+"#Peticion-->"+aux.petition+"#Servicio-->"+aux.url+"#Minutos solicitados-->"+aux.time);
        aux.secret=sec;
        aux.valid=new Date ();
        aux.address=address;
        aux.url=url;
        aux.time=time;
        aux.petition=petition;
        return;
      }
      aux=aux.next;
    }
    if (logLevel>WRITELOG) log.println ("Peticion cursada.#Usuario-->"+subject+"#Nodo-->"+address+"#Peticion-->"+petition+"#Servicio-->"+url+"#Minutos solicitados-->"+time);
    aux=new TCList ();
    aux.user=subject;
    aux.secret=sec;
    aux.valid=new Date ();
    aux.address=address;
    aux.url=url;
    aux.time=time;
    aux.petition=petition;
    aux.next=userSecret;
    userSecret=aux;
  }

  private void htmlLog (String s,OutputStream o) throws IOException
  {
    int t;
    DateFormat df=DateFormat.getDateInstance();
    df.setTimeZone (TimeZone.getTimeZone("GMT"));
    Date dmime=new Date ();
    String reply=new String (htmlError);
    t=reply.indexOf (tagError);
    if (t!=-1)
      reply=new String (reply.substring (0,t)+s+reply.substring (t+tagError.length ()));
    t=reply.indexOf (tagRelease);
    if (t!=-1)
      reply=new String (reply.substring (0,t)+RELEASE+"."+PATCH+reply.substring (t+tagError.length ()));
    String mime=new String ("HTTP/1.0 200 OK\r\nDate: "+df.format (dmime)+"\r\nServer: TCServer/1.0\r\nContent-type: text/html\r\nContent-length: "+reply.length ()+"\r\n\r\n");
    o.write (mime.getBytes ());
    o.write (reply.getBytes ());
  }

  public synchronized void verify (int pet,byte secret[],InetAddress address,byte key[],OutputStream o)
  {
    TCList l1=null,l2=userSecret;
    while (l2!=null)
    {
      try
      {
        if (l2.petition==pet) 
        {
//          UserInfo ui=(UserInfo)CMem.toObject (userFile.search (l2.user.getEncoded ()));
          Name n=new Name(l2.user.getEncoded());
          RegDirectorio rd=userFile.search(n);
          if (rd==null || rd.getPublicKey()==null || rd.getTime()==null || rd.getUrl()==null)
          {
            if (l1==null) userSecret=userSecret.next;
            else l1.next=l1.next.next;
            if (logLevel>VERIFYLOG) log.println ("Datos del usuario no encontrado en la base de datos.#Usuario-->"+l2.user+"#Nodo-->"+address+"#Peticion-->"+petition);
            htmlLog ("Usuario no encontrado en la base de datos.<li>Usuario-->"+l2.user+"<li>Nodo-->"+address+"<li>Peticion-->"+pet,o);
            return;
          }
          BigInteger csec=rd.getPublicRSAKey().crypt (new BigInteger (secret));
          byte auxs[]=new byte[l2.secret.length];
          CryptoUtils.copyBlock (csec.toByteArray (),0,auxs,0,l2.secret.length);
          csec=new BigInteger (auxs);
          if (!csec.equals (new BigInteger (l2.secret)))
          {
            if (l1==null) userSecret=userSecret.next;
            else l1.next=l1.next.next;
            if (logLevel>VERIFYLOG) log.println ("El secreto no coincide.#Usuario-->"+l2.user+"#Nodo-->"+l2.address+"#Peticion-->"+pet+"#Servicio-->"+l2.url+"#Minutos solicitados-->"+l2.time);
            htmlLog ("El secreto no coincide.<li>Usuario-->"+l2.user+"<li>Nodo-->"+l2.address+"<li>Peticion-->"+pet+"<li>Servicio-->"+l2.url+"<li>Minutos solicitados-->"+l2.time,o);
            return;
          }
          if (!address.equals (l2.address))
          {
            if (l1==null) userSecret=userSecret.next;
            else l1.next=l1.next.next;
            if (logLevel>VERIFYLOG) log.println ("Nodo de acreditacion y de certificacion desde maquinas diferentes.#Usuario-->"+l2.user+"#Nodo certificacion-->"+address+"#Nodo acreditacion-->"+l2.address+"#Peticion-->"+pet+"#Servicio-->"+l2.url+"#Minutos solicitados-->"+l2.time);
            htmlLog ("Nodo de acreditacion y de certificacion desde maquinas diferentes.<li>Usuario-->"+l2.user+"<li>Nodo certificacion-->"+address+"<li>Nodo acreditacion-->"+l2.address+"<li>Peticion-->"+pet+"<li>Servicio-->"+l2.url+"<li>Minutos solicitados-->"+l2.time,o);
            return;
          }
          int i;
          for (i=0;i<rd.getUrl().length;i++)
            if (rd.getUrl()[i]!=null && rd.getUrl()[i].equals (l2.url)) break;
          if (i==rd.getUrl().length)
          {
            if (l1==null) userSecret=userSecret.next;
            else l1.next=l1.next.next;
            if (logLevel>VERIFYLOG) log.println ("El usuario no dispone de acceso a ese servicio.#Usuario-->"+l2.user+"#Nodo-->"+l2.address+"#Peticion-->"+pet+"#Servicio-->"+l2.url+"#Minutos solicitados-->"+l2.time);
            htmlLog ("El usuario no dispone de acceso a ese servicio.<li>Usuario-->"+l2.user+"<li>Nodo-->"+l2.address+"<li>Peticion-->"+pet+"<li>Servicio-->"+l2.url+"<li>Minutos solicitados-->"+l2.time,o);
            return;
          }
          if (rd.getTime()[i]<l2.time)
          {
            if (l1==null) userSecret=userSecret.next;
            else l1.next=l1.next.next;
            if (logLevel>VERIFYLOG) log.println ("El tiempo solicitado de servicio es excesivo.#Usuario-->"+l2.user+"#Nodo-->"+l2.address+"#Peticion-->"+pet+"#Servicio-->"+l2.url+"#Minutos solicitados-->"+l2.time+"#Minutos permitidos-->"+rd.getTime()[i]);
            htmlLog ("El tiempo solicitado de servicio es excesivo.<li>Usuario-->"+l2.user+"<li>Nodo-->"+l2.address+"<li>Peticion-->"+pet+"<li>Servicio-->"+l2.url+"<li>Minutos solicitados-->"+l2.time+"<li>Minutos permitidos-->"+rd.getTime()[i],o);
            return;
          }
          if (caURL!=null)
          for (int j=0;j<caURL.length;j++)
          {
            if (caURL[j].equals (l2.url))
            {
              NetscapeCertRequest ncr=new NetscapeCertRequest (key);
              PublicKeyInfo npk=(PublicKeyInfo)ncr.getPublicKey ();
              DateFormat df=DateFormat.getDateInstance();
              df.setTimeZone (TimeZone.getTimeZone("GMT"));
              Date dmime=new Date ();
              X509Certificate cert=TCUtil.createCertificate (l2.user,npk,caName[i],caPrivateKey[i],AlgorithmID.md5WithRSAEncryption,l2.time,l2.petition);
              String mime=new String ("HTTP/1.0 200 OK\r\nDate: "+df.format (dmime)+"\r\nServer: TCServer/1.0\r\nContent-type: application/x-x509-user-cert\r\nContent-length: "+cert.getEncoded().length+"\r\n\r\n");
              o.write (mime.getBytes ());
              cert.writeTo (o);
              if (logLevel>VERIFYLOG) log.println ("Certificado cursado.#Usuario-->"+l2.user+"#Nodo-->"+l2.address+"#Peticion-->"+pet+"#Servicio-->"+l2.url+"#Minutos solicitados-->"+l2.time);
              if (l1==null) userSecret=userSecret.next;
              else l1.next=l1.next.next;
              return;
            }
          }
          log.println ("El servidor no dispone de ese servicio.#Usuario-->"+l2.user+"#Nodo-->"+l2.address+"#Peticion-->"+pet+"#Servicio-->"+l2.url+"#Minutos solicitados-->"+l2.time);
          htmlLog ("El servidor no dispone de ese servicio.<li>Usuario-->"+l2.user+"<li>Nodo-->"+l2.address+"<li>Peticion-->"+pet+"<li>Servicio-->"+l2.url+"<li>Minutos solicitados-->"+l2.time,o);
          return;
        }
      }
      catch (IOException e)
      {
        log.println ("Error accediendo a la base de datos de usuarios."+"#Nodo-->"+address+"#Peticion-->"+pet+"#Excepcion-->"+e);
      }
      catch (CodingException e)
      {
        log.println ("Error en la peticion de certificado de Netscape."+"#Nodo-->"+address+"#Peticion-->"+pet+"#Excepcion-->"+e);
        try
        {
          htmlLog ("Error en la peticion de certificado de Netscape."+"<li>Nodo-->"+address+"#Peticion-->"+pet+"#Excepcion-->"+e,o);
        } catch (Exception ee) {}
      }
      catch (InvalidKeyException e)
      {
        log.println ("Error en la clave publica de Netscape."+"#Nodo-->"+address+"#Peticion-->"+petition+"#Excepcion-->"+e);
        try
        {
          htmlLog ("Error en la clave publica de Netscape."+"<li>Nodo-->"+address+"<li>Peticion-->"+pet+"<li>Excepcion-->"+e,o);
        } catch (Exception ee) {}
      }
      catch (GeneralSecurityException e)
      {
        log.println ("Error interno generando el certificado."+"#Nodo-->"+address+"#Peticion-->"+pet+"#Excepcion-->"+e);
        try
        {
          htmlLog ("Error interno generando el certificado."+"<li>Nodo-->"+address+"<li>Peticion-->"+pet+"<li>Excepcion-->"+e,o);
        } catch (Exception ee) {}
      }
      l1=l2;
      l2=l2.next;
    }
    if (logLevel>VERIFYLOG) log.println ("Peticion no encontrada.#Peticion-->"+pet+"#Nodo-->"+address);
    try
    {
      htmlLog ("Peticion no encontrada.<li>Peticion-->"+pet+"<li>Nodo-->"+address,o);
    } catch (Exception ee) {}
    return;
  }

  public void accept ()
  {
    try
    {
      tcServer=new ServerSocket (tccPort);
      Thread c=new TCThread (log,tcServer,TCThread.TC,this,soTimeOut);
      c.start ();
    }
    catch (Exception e)
    {
      log.println ("Error Grave, no se puede levantar el TCS en el puerto "+tccPort+".#Excepcion-->"+e);
      System.out.println ("-ERR Error Grave, no se puede levantar el TCS en el puerto "+tccPort+".#Excepcion-->"+e);
      System.exit (-1);
    }
  }

  public void certificate ()
  {
    try
    {
      irServer=new ServerSocket (irPort);
      Thread c=new TCThread (log,irServer,TCThread.IR,this,soTimeOut);
      c.start ();
    }
    catch (Exception e)
    {
      log.println ("Error Grave, no se puede levantar el IRS en el puerto "+irPort+".#Excepcion-->"+e);
      System.out.println ("-ERR Error Grave, no se puede levantar el IRS en el puerto "+irPort+".#Excepcion-->"+e);
      System.exit (-1);
    }
  }

  public void getpass () throws IOException
  {
    if (passwFile != null) {
      String tl;
      BufferedReader br = new BufferedReader (new FileReader (passwFile));
      passwordP = br.readLine ();
      if ((tl = br.readLine ()) != null)
         passwordTcs = tl;
      else
         passwordTcs = passwordP;
    }
  }
    
  private void exparg (String [] a)
  {
    for (int i = 0; i < a.length; i++) {
      switch (a[i].charAt (0)) {
      case '-':
        if (a[i].charAt (1) == 'P') {
          passwFile=new String (a[++i]);
        }
        else if (a[i].charAt (1) == 'p') {
          passwordP=new String (a[++i]);
          passwordTcs=new String (a[++i]);
        }
        else if (a[i].charAt (1) == 'C') {
          configFile=new String (a[++i]);
        }
        else {
          System.out.println ("Opcion erronea: " + a[i]);
          System.exit (-1);
        }
        break;
      default:
        System.out.println ("Argumento erroneo: " + a[i]);
        System.exit (-1);
      }
    }
    if (configFile == null) configFile = DEFCFFILE;
    if (passwFile == null && passwordP == null) {
      System.out.println ("AVISO: No se ha especificado password alguna");
    }
  }

  public static void main (String arg[])
  {
    TCServer tcs=new TCServer ();
    tcs.exparg (arg);
    try
    {
      Provider providerIAIK=new IAIK ();
      Security.addProvider (providerIAIK);
      tcs.getpass ();
      tcs.config ();
      tcs.up ();
      System.out.println ("+OK");
      System.out.flush ();
      tcs.periodicTimeOutDelete ();
    }
    catch (NoSuchAlgorithmException e)
    {
      tcs.log.println ("Error en la carga de claves.#Excepcion-->"+e);
    }
    catch (InvalidKeyException e)
    {
      tcs.log.println ("Error en la carga de claves.#Excepcion-->"+e);
    }
    catch (GeneralSecurityException e)
    {
      tcs.log.println ("Error en la carga de claves.#Excepcion-->"+e);
    }
    catch (CodingException e)
    {
      tcs.log.println ("Error en la carga de claves.#Excepcion-->"+e);
    }
    catch (IOException e)
    {    
      tcs.log.println ("Error de entrada/salida cargando la configuracion.#Excepcion-->"+e);
    }
    catch (NullPointerException e)
    {
      tcs.log.println ("Error en la configuracion, falta un parametro.#Excepcion-->"+e);
    }
    catch (Exception e)
    {
      tcs.log.println ("Error en el arranque.#Excepcion-->"+e);
    }
  }
}
