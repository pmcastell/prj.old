package es.cica.tcs.util;

public interface IOThreadListener {
  public void thrEnd (IOThread thread);
}
