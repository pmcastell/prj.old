package es.cica.tcs.util;

import java.io.*;
import java.net.*;

import java.security.Provider;
import java.security.Security;
import java.security.cert.X509Certificate;

import iaik.security.ssl.*;
import iaik.security.provider.IAIK;
import iaik.security.rsa.*;
import iaik.pkcs.*;
import iaik.asn1.*;


public class SSLClient implements IOThreadListener {

  private boolean dflag = false;
  private String server = null;
  private int port = 443;
  private SSLSocket s = null;
  private SSLClientContext context = null;
  private IOThread theReader;
  private IOThread theWriter;

  public static void main(String arg[]) throws IOException {

    String serverName = null;
    int serverPort = 443;
    boolean dflag = false;
    boolean nflag = false;
    String certFile = "";
    String passPhrase = "";
    SSLClient theClient;

    if (arg.length < 1) {
      System.out.println("Usage: SSLClient [-d] [-p passphrase] [-c certfile | -N] host port");
      System.exit(-1);
    }
    for (int i = 0; i < arg.length; i++) {
      if (arg[i].equals ("-d")) dflag = true;
      else if (arg[i].equals ("-N")) nflag = true;
      else if (arg[i].equals ("-c") && ++i < arg.length) {
         certFile = arg[i];
         nflag = false;
      }
      else if (arg[i].equals ("-p") && ++i < arg.length) passPhrase = arg[i];
      else if (serverName == null) serverName = arg[i];
      else serverPort = Integer.decode(arg[i]).intValue();
    }
    if (serverName == null) {
      System.out.println("Usage: SSLClient [-d] [-p passphrase] [-c certfile | -N] host port");
      System.exit(-1);
    }

    theClient = new SSLClient (serverName, serverPort, certFile, passPhrase,
                               nflag, dflag);
    theClient.connect ();
  }

  public SSLClient (String server, int port, String cert, String pw,
                    boolean nflag, boolean dflag) {
    CicaP12 p12 = null;

    this.dflag = dflag;
    this.server = server;
    this.port = port;

    try {
      Class provider = Class.forName("iaik.security.provider.IAIK");
      Provider iaik = (Provider)provider.newInstance();
      debug ("add Provider "+iaik.getInfo()+"...");
      Security.addProvider(iaik);
    }
    catch (ClassNotFoundException ex) {
      System.out.println("Provider IAIK not found");
      System.exit(-2);
    }
    catch (Exception ex) {
      System.out.println("Internal IAIK Error");
      System.exit(-2);
    }

    context = new SSLClientContext();
    if (nflag) {
      context.setTrustDecider(new NullClientTrustDecider(dflag));
    }
    else {
      try {
        if (pw.length() > 0)
          p12 = new CicaP12 (new FileInputStream (cert), pw);
        else
          p12 = new CicaP12 (new FileInputStream (cert));
      }
      catch (IOException ex) {
        System.out.println("Error reading certificate file: " +
                           ex.getMessage());
        System.exit (-3);
      }
      catch (PKCSException ex) {
        System.out.println("Error decrypting certificate file: " +
                           ex.getMessage());
        System.exit (-3);
      }
      catch (CodingException ex) {
        System.out.println("Error decoding certificate file: " +
                           ex.getMessage());
        System.exit (-3);
      }

      context.setTrustDecider(new TCCTrustDecider(p12.getPrivateKey(),
                                                  p12.getCertificateChain(),
                                                  p12.getCertificateIssuer()));
    }
  }

  public void connect () {
    debug ("Connecting to "+server+":"+port);
    try {
      s = new SSLSocket(server, port, context);
      if (dflag) s.setDebugStream(System.out);
      s.startHandshake();

      debug("\nConnection established...\n");
      debug("Active cipher suite: "+s.getActiveCipherSuite().getName());
      debug("Active compression method: "+
            s.getActiveCompressionMethod().getName());
      debug("\nServer certificate chain:");
      X509Certificate[] chain = s.getPeerCertificateChain();
      for (int i=0; i<chain.length; i++)
        debug("Certificate "+i+": "+chain[i].getSubjectDN());

      debug("Starting reader and writer...");
      theReader = new IOThread (this, IOThread.FROMSERVER,
                                s.getInputStream(), System.out);
      theWriter = new IOThread (this, IOThread.TOSERVER,
                                System.in, s.getOutputStream ());
      theWriter.start ();
      theReader.start ();
    }
    catch (UnknownHostException ex) {
      System.out.println("Unknown Host: "+ex.getMessage());
      System.exit (-3);
    }
    catch (IOException ex) {
      System.out.println(ex.getMessage());
      System.exit (-3);
    }
    System.out.println ("Connected to "+ server + ":" + port);
  }

  public void thrEnd (IOThread iw) {
    if (iw == theReader) theWriter.stop ();
    if (iw == theWriter) theReader.stop ();
    try { s.close(); }
    catch (IOException ex) { System.out.println(ex.getMessage()); }
    System.exit (0);
  }

  private void debug (String msg) {
    if (dflag) System.out.println(msg);
  }
}
