package es.cica.tcs.util;

import java.io.*;
import java.math.BigInteger;
import java.util.*;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.util.StringTokenizer;
//import java.util.Random;
import java.security.*;

import iaik.asn1.*;
import iaik.asn1.structures.*;
import iaik.x509.*;
import iaik.pkcs.pkcs8.*;

public class TCUtil
{
  public static X509Certificate createCertificate (Name subject,PublicKeyInfo pk,Name issuer,PrivateKeyInfo sk,AlgorithmID algorithm,int time,int p)
  throws GeneralSecurityException
  {
    X509Certificate cert=new X509Certificate ();
    GregorianCalendar date;

    try
    {
      cert.setSerialNumber (new BigInteger(20,new Random ()));
      cert.setSubjectDN (subject);
      cert.setPublicKey (pk);
      cert.setIssuerDN (issuer);

      date=new GregorianCalendar ();
      date.add (Calendar.HOUR,-1);
      cert.setValidNotBefore (date.getTime ());
      date=new GregorianCalendar ();
      date.add (Calendar.MINUTE,time);
      cert.setValidNotAfter (date.getTime());
      cert.sign (algorithm,sk);
    }
    catch (Exception e)
    {
      throw new GeneralSecurityException ("Error interno generando certificado.");
    }
    return cert;
  }

  public static boolean similar (Name name,Name model)
  {
    if
    (
      model.getRDN (ObjectID.country)!=null &&
      !model.getRDN (ObjectID.country).equals
        (name.getRDN (ObjectID.country))
    ) return false;
    if 
    (
      model.getRDN (ObjectID.stateOrProvince)!=null && 
      !model.getRDN (ObjectID.stateOrProvince).equals
        (name.getRDN (ObjectID.stateOrProvince))
    ) return false;
    if 
    (
      model.getRDN (ObjectID.locality)!=null && 
      !model.getRDN (ObjectID.locality).equals 
        (name.getRDN (ObjectID.locality))
    ) return false;
    if
    (
      model.getRDN (ObjectID.organization)!=null &&  
      !model.getRDN (ObjectID.organization).equals
        (name.getRDN (ObjectID.organization))
    ) return false;
    if
    (
      model.getRDN (ObjectID.organizationalUnit)!=null &&  
      !model.getRDN (ObjectID.organizationalUnit).equals
        (name.getRDN (ObjectID.organizationalUnit))
    ) return false;
    if
    (
      model.getRDN (ObjectID.emailAddress)!=null &&  
      !model.getRDN (ObjectID.emailAddress).equals
        (name.getRDN (ObjectID.emailAddress))
    ) return false;
    if
    (
      model.getRDN (ObjectID.commonName)!=null &&
      !model.getRDN (ObjectID.commonName).equals
        (name.getRDN (ObjectID.commonName))
    ) return false;
    if
    (
      model.getRDN (ObjectID.title)!=null &&
      !model.getRDN (ObjectID.title).equals
        (name.getRDN (ObjectID.title))
    ) return false;
    return true;
  }

  public static Name toName (String sn) throws CodingException
  {
    Name name=new Name ();
    int i;
    char c;
    for (i=0;i<sn.length ();i++)
    {
      c=sn.charAt (i);
      if (c!=' ' && c!='\t' && c!='\n' && c!='\r') break;
    }
    String s=sn.substring (i);
    StringTokenizer st=new StringTokenizer (s,","),ast1,ast2;
    String var,val;
    int count=st.countTokens ();
    for (i=0;i<count;i++)
    {
      ast1=new StringTokenizer (st.nextToken (),"=");
      ast2=new StringTokenizer (ast1.nextToken ()," \t\r\n");
      var=ast2.nextToken ();
      val=ast1.nextToken ().trim ();
      if (var.equals ("C"))
        name.addRDN (ObjectID.country,val);
      else if (var.equals ("SP"))
        name.addRDN (ObjectID.stateOrProvince,val);
      else if (var.equals ("L"))
        name.addRDN (ObjectID.locality,val);
      else if (var.equals ("O"))
        name.addRDN (ObjectID.organization,val);
      else if (var.equals ("OU"))
        name.addRDN (ObjectID.organizationalUnit,val);
      else if (var.equals ("EMail"))
        name.addRDN (ObjectID.emailAddress,val);
      else if (var.equals ("CN"))
        name.addRDN (ObjectID.commonName,val);
      else if (var.equals ("T"))
        name.addRDN (ObjectID.title,val);
      else throw new CodingException ("Atributo -->"+var+"<-- desconocido."); 
    }
    return name;
  }

  public static String[][] readValues (BufferedReader br,int contentRead,int contentLength) throws IOException
  {
    StringBuffer sb=new StringBuffer ("");
    int c,caux,i=0;
    String r[][]=null,raux[][],aux;


    for (;;)
    {
      sb=new StringBuffer ("");
      for (;;)
      {
        c=br.read ();
        contentRead++;
        if (c=='=') break;
        sb.append ((char)c);
      }
      aux=sb.toString ();
      sb=new StringBuffer ("");
      for (;contentRead<=contentLength;)
      {
        c=br.read ();
        contentRead++;
        if (c=='&') break;
        if (c=='%')
        {
          c=br.read ();
          contentRead++;
          caux=(('0'<=c && c<='9') ? c-'0':c-'A'+10);
          c=br.read ();
          contentRead++;
          caux=caux*0x10+(('0'<=c && c<='9') ? c-'0':c-'A'+10);
          c=caux;
          if (c=='\n') continue;
        }
        sb.append ((char)c);
      }
      if (i==0)
      {
        r=new String[2][1];
        r[0][0]=aux;
        r[1][0]=sb.toString ();
        i++;
      }
      else
      {
        raux=new String[2][i+1];
        for (int j=0;j<i;j++)
        {
          raux[0][j]=r[0][j];
          raux[1][j]=r[1][j];
        }
        raux[0][i]=aux;
        raux[1][i]=sb.toString ();
        i++;
        r=raux;
      }
      if (contentRead>contentLength) return r;
    }
  }

  public static String value (String values[][],String var)
  {
    for (int i=0;i<values[0].length;i++)
      if (values[0][i].equals (var)) return values[1][i];
    return null;
  }
}
