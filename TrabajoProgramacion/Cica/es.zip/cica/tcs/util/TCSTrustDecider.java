package es.cica.tcs.util;

import java.security.*;
import java.security.cert.X509Certificate;

import iaik.x509.*;
import iaik.security.*;
import iaik.security.rsa.*;
import iaik.security.ssl.*;
import iaik.pkcs.pkcs8.PrivateKeyInfo;

public class TCSTrustDecider implements ServerTrustDecider
{
  X509Certificate certificate[],issuer[];
  PrivateKeyInfo privateKey;

  public TCSTrustDecider (PrivateKeyInfo pki,X509Certificate cert[],X509Certificate iss[])
  {
    certificate=cert;
    issuer=iss;
    privateKey=pki;
  }

  public boolean isTrustedPeer (SSLCertificate cert)
  {
    if (issuer==null) return true;
    if (cert==null) return false;
    X509Certificate chain[]=(X509Certificate[])cert.getCertificateChain ();
    try
    {
      chain[chain.length-1].checkValidity ();
      chain[chain.length-1].verify (chain[chain.length-1].getPublicKey ());
      int i,j;
      for (i=issuer.length-1;i>=0;i--) if (chain[chain.length-1].getSubjectDN ().equals (issuer[i].getSubjectDN ())) break;
      if (i<0) return false;
      X509Certificate aux[]=new X509Certificate[chain.length+1];
      aux[chain.length]=issuer[i];
      for (j=chain.length-1;j>=0;j--) aux[j]=chain[j];
      aux[aux.length-1].checkValidity ();
      for (j=1;j<aux.length;j++)
      {
        aux[j-1].verify (aux[j].getPublicKey ());
        aux[j-1].checkValidity ();
      }
      return true;
    }
    catch (Exception e)
    {
      return false;
    }
  }
}
