package es.cica.tcs.util;

public interface terminador {
   public void finaliza();
} 