package es.cica.tcs.util;

import java.security.*;
import java.security.cert.X509Certificate;

import iaik.asn1.structures.*;
import iaik.x509.*;
import iaik.security.*;
import iaik.security.ssl.*;
import iaik.pkcs.pkcs8.PrivateKeyInfo;
import iaik.security.rsa.*;

public class TCCTrustDecider implements ClientTrustDecider
{
  X509Certificate certificate[],issuer[];
  PrivateKeyInfo privateKey;

  public TCCTrustDecider (PrivateKeyInfo pki, X509Certificate cert[],
                          X509Certificate iss[])
  {
    certificate=cert;
    issuer=iss;
    privateKey=pki;
  }

  public SSLCertificate getCertificate (byte t[],Principal a[],String s)
  {
    return new SSLCertificate (certificate);
  }

  public PrivateKey getPrivateKey ()
  {
    return privateKey;
  }

  public boolean isTrustedPeer (SSLCertificate cert)
  {
    if (issuer==null) return true;
    if (cert==null) return false;
    try
    {
      X509Certificate chain[]=(X509Certificate[])cert.getCertificateChain ();
      chain[chain.length-1].checkValidity ();
      chain[chain.length-1].verify (chain[chain.length-1].getPublicKey ());
      int i,j;
      for (i=1;i<chain.length;i++)
      {
        chain[i-1].verify (chain[i].getPublicKey ());
        chain[i-1].checkValidity ();
      }
      for (i=0;i<issuer.length;i++)
        for (j=0;j<chain.length;j++)
        {
          if (chain[j].getSubjectDN ().equals (issuer[i].getIssuerDN ()))
          {
            issuer[i].verify (chain[j].getPublicKey ());
            return true;
          }
        }
      return false;
    }
    catch (Exception e)
    {
      return false;
    }
  }
}
