package es.cica.tcs.util;
import java.io.*;

public class IOThread extends Thread {
  static final int TOSERVER = 0;
  static final int FROMSERVER = 1;

  private PrintWriter writer = null;
  private BufferedReader reader = null;
  private InputStream ins = null;
  private IOThreadListener listener = null;
  private int type = -1;

  public IOThread (IOThreadListener lst, int tp,
                   InputStream in, OutputStream out) {
    type = tp;
    listener = lst;
   
    writer = new PrintWriter (out);
    reader = new BufferedReader (new InputStreamReader (in));
    if (type == TOSERVER) ins = in;
  }

  public void run () {
    String line;
    try {
      do {
// El thread que escribe hacia el servidor debe ponerse en espera porque
// de lo contrario bloquea la escritura del thread que lee desde el servidor
        if (type == TOSERVER) {
          while (ins.available () == 0) {
            try { sleep (100); }
            catch (InterruptedException e) {}
          }
        }
        line = reader.readLine ();
        if (type == TOSERVER) {
          if (line.equals ("\\h")) {
            System.out.println (listener.getClass().getName() +
                                ". Special commands:");
            System.out.println ("\\h. This help");
            System.out.println ("\\q. Quit");
          }
          if (line.equals ("\\q")) break;
        }
        writer.println (line); writer.flush ();
      } while (line != null);
    }
    catch (IOException e) {
      System.err.println (e.getMessage ());
    }
    listener.thrEnd (this);
  }
}
