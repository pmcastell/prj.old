package es.cica.tcs.util;

import java.security.*;
import java.io.*;
import java.security.cert.X509Certificate;

import iaik.security.ssl.*;
import iaik.asn1.*;
import iaik.asn1.structures.Name;
import iaik.security.rsa.*;
import iaik.security.dsa.*;
import iaik.security.dh.*;
import iaik.pkcs.*;
import iaik.utils.KeyAndCertificate;
import iaik.pkcs.pkcs8.EncryptedPrivateKeyInfo;


public class NullClientTrustDecider implements ClientTrustDecider {

  private boolean debug = false;

  private PrivateKey private_key;
  
  public NullClientTrustDecider(boolean debug) {
    this.debug = debug;
  }    

  public boolean verifyCertificateChain(X509Certificate[] chain) {

    int len = chain.length;

    try {
      chain[len-1].verify(chain[len-1].getPublicKey());

      for (int i = len-1; i>0; i--)
        chain[i-1].verify(chain[i].getPublicKey());
    } catch (Exception ex) {
      return false;
    }

    return true;
  }
  
  public boolean isTrustedPeer(SSLCertificate certificate) {
    if (certificate != null && debug) {
      X509Certificate[] certChain = certificate.getCertificateChain();
      debug("Server certificate chain");
      for (int i=0; i<certChain.length; i++)
        debug(certChain[i].getSubjectDN().toString());
    }

    return true;
  }

  public SSLCertificate getCertificate(byte[] certificateTypes, 
                Principal[] certificateAuthorities, String keyExchangeAlgorithm)
  {
    
    debug("Key exchange algorithm: "+keyExchangeAlgorithm);
    debug("Server accepts the following CAs:");
    for (int i=0; i<certificateAuthorities.length; i++)
     debug(certificateAuthorities[i].toString());
      
    debug("Server requests the following certificate types:");
    for (int i=0; i<certificateTypes.length; i++) {
      switch (certificateTypes[i]) {
        case ClientTrustDecider.rsa_sign:
          debug("rsa_sign");
          break;
        case ClientTrustDecider.dss_sign:
          debug("dss_sign");
          break;
        case ClientTrustDecider.rsa_fixed_dh:
          debug("rsa_fixed_dh");
          break;
        case ClientTrustDecider.dss_fixed_dh:
          debug("dss_fixed_dh");
          break;
        case ClientTrustDecider.rsa_ephemeral_dh:
          debug("rsa_ephemeral_dh");
          break;
        case ClientTrustDecider.dss_ephemeral_dh:
          debug("dss_ephemeral_dh");
          break;
        case ClientTrustDecider.fortezza_dms:
          debug("fortezza_dms");
          break;
      }
    }

    return null;
  }

  public PrivateKey getPrivateKey() {
    return private_key;
  }
  
  private void debug(String s) {
    if (debug)
      System.out.println(s);
  }
}

