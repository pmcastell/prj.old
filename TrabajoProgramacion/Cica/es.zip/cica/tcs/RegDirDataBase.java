package es.cica.tcs;
import iaik.asn1.structures.Name;
import java.io.IOException;


public class RegDirDataBase extends DataBase implements DataBaseInterface {
   private int regActual=0;
   private boolean eof=false;

   public RegDirDataBase() {
   }
   public void open(String db) throws IOException {
      super.open(db);
      regActual=0;
   }   


   public RegDirectorio search(int ind) throws IOException
   {
      byte [][]busqueda;
      busqueda=super._search(ind);
      if (busqueda==null) {
         this.eof=true;
         return null;
      }      
      regActual=ind+1;
      return new RegDirectorio(busqueda[1]);
   }
   public RegDirectorio get() throws IOException {
      RegDirectorio r=search(this.regActual);
      if (r!=null) {
         this.regActual++;
      }
      return r;
   }

//   public boolean eof();
   public void goTop() {
      regActual=0;
   }
   public RegDirectorio search(Name n) throws IOException {
      byte [] r=super._search(n.getEncoded());
      if (r==null) {
         this.eof=true;
         return null;
      }
      this.regActual++;
      return new RegDirectorio(r);
   }
   public RegDirectorio search(RegDirectorio ind) throws IOException {
      return this.search(ind.getName());
   }
//   public void delete (byte k[]) throws IOException;
   public void delete(Name n) throws IOException {
      super.delete(n.getEncoded());
   }
   public void delete(RegDirectorio usuario) throws IOException {
      this.delete(usuario.getName());
   }
//   public byte[] toByteArray (Object obj);
//   public long insert (byte k[],byte d[]) throws IOException;
   public void insert(RegDirectorio usuario) throws IOException {
      super.insert(usuario.getName().getEncoded(),usuario.toByteArray());
   }
//   public Object toObject (byte obj[]);
//   public void modify (byte k[],byte d[]) throws IOException;
   public void modify(RegDirectorio usuario) throws IOException {
      super.modify(usuario.getName().getEncoded(), usuario.toByteArray());
   }
   public void compact () throws IOException {
      super.compact();
   }
}