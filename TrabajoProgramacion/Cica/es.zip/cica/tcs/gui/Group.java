package es.cica.tcs.gui;

import java.awt.*;

public class Group
{
  public static final int
    VERTICAL=1,HORIZONTAL=2,MENU=3;
  public static final Point
    N=new Point (0,1),
    S=new Point (0,-1),
    E=new Point (1,0),
    W=new Point (-1,0),
    NE=new Point (1,1),
    NW=new Point (-1,1),
    SE=new Point (1,-1),
    SW=new Point (-1,-1),
    C=new Point (0,0),
    H=new Point (2,0),
    V=new Point (0,2),
    VW=new Point (-1,2),
    VE=new Point (1,2),
    ALL=new Point (2,2);
  private Object object[];
  private Point location[];
  private int type;
  private String name;
  private Container container;

  public Group (int t)
  {
    object=null;
    location=null;
    type=t;
    name=null;
    container=null;
  }

  public Group (int t,Container c)
  {
    object=null;
    location=null;
    type=t;
    name=null;
    container=c;
  }

  public Group (String n,int t)
  {
    object=null;
    location=null;
    type=t;
    name=n;
    container=null;
  }

  public Group (String n,int t,Container c)
  {
    object=null;
    location=null;
    type=t;
    name=n;
    container=c;
  }

  public Container getContainer ()
  {
    return container;
  }

  public int getType ()
  {
    return type;
  }

  public String getName ()
  {
    return name;
  }

  public void setName (String n)
  {
    name=n;
  }

  public int length ()
  {
    if (object==null) return 0;
    return object.length;
  }

  public Object getElementAt (int i)
  {
    return object[i];
  }

  public Point getLocationAt (int i)
  {
    return location[i];
  }

  public void add (Object obj)
  {
    add (obj,ALL);
  }

  public void add (Object obj,Point loc)
  {
    if (object==null)
    {
      object=new Object[1];
      location=new Point[1];
      object[0]=obj;
      location[0]=loc;
    }
    else
    {
      Object o[]=new Object[object.length+1];
      Point l[]=new Point[object.length+1];
      int i;
      for (i=0;i<object.length;i++)
      {
        o[i]=object[i];
        l[i]=location[i];
      }
      o[i]=obj;
      l[i]=loc;
      object=o;
      location=l;
    }
  }
}
