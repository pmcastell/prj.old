package es.cica.tcs.gui;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;
import es.cica.tcs.gui.*;
import javax.swing.*;




public class ApplicationFrame
  implements
    ComponentListener,
    ActionListener,
    WindowListener,
    ItemListener
{
  private JFrame frame;
  private Dimension frameDimension;
  private Point frameLocation;
  private boolean frameCenter=false,framePack=false;
  private MenuBar menuBar;
  private AWTEvent event=null;
  private Thread threadSleep=null;
  private Group group;


  public ApplicationFrame (JFrame f,Group c,Group m)
  {
    group=c;
    frame=f;
    frame.addComponentListener(this);
    frame.addWindowListener (this);
    createFrame (frame,c);
    menuBar=new MenuBar ();
    addMenu (menuBar,m);
  }

  public ApplicationFrame (JFrame f,Group c)
  {
    group=c;
    frame=f;
    frame.addComponentListener (this);
    frame.addWindowListener (this);
    createFrame (frame,c);
    menuBar=null;
  }

  public ApplicationFrame (String title,Group c,Group m)
  {
    group=c;
    frame=new JFrame (title);
    frame.addComponentListener (this);
    frame.addWindowListener (this);
    createFrame (frame,c);
    menuBar=new MenuBar ();
    addMenu (menuBar,m);
  }

  public ApplicationFrame (String title,Group c)
  {
    group=c;
    frame=new JFrame (title);
    frame.addComponentListener (this);
    frame.addWindowListener (this);
    createFrame (frame,c);
    menuBar=null;
  }

  public void addAction (Object obj)
  {
    try
    {
      Class pt[]={Class.forName ("java.awt.event.ActionListener")};
      Object param[]={this};
      obj.getClass ().getDeclaredMethod
        ("addActionListener",pt).invoke (obj,param);
    }
    catch (Exception e) {}
  }

  private void addMenu (Object object,Group group)
  {
    int i;
    Object g;
    Menu menu;
    if (object instanceof MenuBar)
    {
      for (i=0;i<group.length ();i++)
      {
        g=group.getElementAt (i);
        menu=new Menu (((Group)g).getName ());
        addMenu (menu,((Group)g));
        ((MenuBar)object).add (menu);
      }
    }
    else if (object instanceof Menu)
    {
      for (i=0;i<group.length ();i++)
      {
        g=group.getElementAt (i);
        if (g==null)
          ((Menu)object).addSeparator ();
        else if (g instanceof String)
        {
          MenuItem mi=new MenuItem ((String)g);
          try
          {
            Class pt[]={Class.forName ("java.awt.event.ActionListener")};
            Object param[]={this};
            mi.getClass ().getDeclaredMethod
              ("addActionListener",pt).invoke (mi,param);
          }
          catch (Exception e) {}
          ((Menu)object).add (mi);
        }
        else if (g instanceof Group)
        {
          menu=new Menu (((Group)g).getName ());
          addMenu (menu,(Group)g);
          ((Menu)object).add (menu);
        }
        else
        {
          try
          {
            Class pt[]={Class.forName ("java.awt.event.ActionListener")};
            Object param[]={this};
            g.getClass ().getDeclaredMethod
              ("addActionListener",pt).invoke (g,param);
          }
          catch (Exception e) {}
          try
          {
            Class pt[]={Class.forName ("java.awt.event.ItemListener")};
            Object param[]={this};
            g.getClass ().getDeclaredMethod
              ("addItemListener",pt).invoke (g,param);
          }
          catch (Exception e) {}
          ((Menu)object).add ((MenuItem)g);
        }
      }
    }
  }
  
  public void setEnabled (boolean b)
  {
    frame.setEnabled (b);
    setEnabledAll (b,group);
  }

  public void setEnabledAll (boolean b,Group g)
  {
    int length=g.length ();
    Object element;
    for (int i=0;i<length;i++)
    {
      element=g.getElementAt (i);
      if (element instanceof Group)
        setEnabledAll (b,(Group)element);
      else if (element instanceof Component)
        ((Component)element).setEnabled (b);
    }
  }

  private void createFrame (Container p,Group group)
  {
    if (p instanceof JFrame) {
       ((JFrame)p).getContentPane().setLayout(new ApplicationLayout (group.getType ()));
    } else {
       p.setLayout (new ApplicationLayout (group.getType ()));
    }   
    int length=group.length ();
    Object element;
    for (int i=0;i<length;i++)
    {
      element=group.getElementAt (i);
      if (element instanceof Group)
      {
        Container ap;
        ap=((Group)element).getContainer ();
        if (ap==null)
          ap=new Panel ();
        createFrame (ap,(Group)element);
        if (p instanceof JFrame) {
           ((JFrame) p).getContentPane().add(ap,group.getLocationAt (i));
        } else {
           p.add(ap,group.getLocationAt (i));
        }   
      }
      else
      {
        try
        {
          Class pt[]={Class.forName ("java.awt.event.ActionListener")};
          Object param[]={this};
          element.getClass ().getDeclaredMethod
            ("addActionListener",pt).invoke (element,param);
        }
        catch (Exception e) {}
        try
        {
          Class pt[]={Class.forName ("java.awt.event.ItemListener")};
          Object param[]={this};
          element.getClass ().getDeclaredMethod
            ("addItemListener",pt).invoke (element,param);
        }
        catch (Exception e) {}
        if (p instanceof JFrame) {
           ((JFrame)p).getContentPane().add((Component)element,group.getLocationAt (i));
        } else {
           p.add ((Component)element,group.getLocationAt (i));
        }   
      }
    }
  }

  public void pack ()
  {
    framePack=true;
  }

  public void setVisible (boolean visible)
  {
    if (visible)
    {
      if (framePack || frameDimension==null)
      {
        if (frameCenter) 
        {
          Dimension ds=frame.getToolkit().getScreenSize ();
          frame.setLocation (ds.width/2,ds.height/2);
        }
        frame.pack ();
        frameDimension=frame.getPreferredSize ();
        frame.setSize (frameDimension);
        framePack=false;
      }
      if (frameCenter)
      {
        Dimension ds=frame.getToolkit().getScreenSize ();
        frameLocation=new Point ((ds.width-frameDimension.width)/2,(ds.height-frameDimension.height)/2);
        frame.setLocation (frameLocation.x,frameLocation.y);
        frameCenter=false;
      }
      else if (frameLocation==null)
        frameLocation=frame.getLocation ();
    }
if (menuBar!=null) frame.setMenuBar (menuBar);
    frame.setVisible (visible);
//    if (menuBar!=null) frame.setMenuBar (menuBar);
  }

  public void center ()
  {
    frameCenter=true;
  }

  public void componentHidden (ComponentEvent evt)
  {
  }

  public void componentShown (ComponentEvent evt)
  {
  }

  public void componentResized (ComponentEvent evt)
  {
    frameDimension=frame.getSize ();
  }

  public void componentMoved (ComponentEvent evt)
  {
    frameLocation=frame.getLocation ();
  }

  public void itemStateChanged (ItemEvent evt)
  {
    resume (evt);
  }

  public void windowActivated (WindowEvent evt)
  {
    resume (evt);
  }

  public void windowDeactivated (WindowEvent evt)
  {
    resume (evt);
  }
  
  public void windowClosed (WindowEvent evt)
  {
    resume (evt);
  }
  
  public void windowClosing (WindowEvent evt)
  {
    resume (evt);
  }
  
  public void windowIconified (WindowEvent evt)
  {
    resume (evt);
  }
  
  public void windowDeiconified (WindowEvent evt)
  {
    resume (evt);
  }
  
  public void windowOpened (WindowEvent evt)
  {
    resume (evt);
  }
  
  public void actionPerformed (ActionEvent evt)
  {
    resume (evt);
  }
  
  private synchronized void resume (AWTEvent evt)
  {
    if (threadSleep!=null)
    {
      event=evt;
      threadSleep.resume ();
    }
    else
      event=null;
  }
  
  private synchronized AWTEvent getEvent ()
  {
    AWTEvent evt=event;
    event=null;
    threadSleep=null;
    return evt;
  }
  
  public AWTEvent eventWait ()
  {
    AWTEvent evt;
    for (;;)
    {
      threadSleep=Thread.currentThread ();
      threadSleep.suspend ();
      evt=getEvent ();
      if (evt!=null) return evt;
    }
  }

  public static void main (String arg[])
  {
    Group m1=new Group ("Guardar",Group.MENU);
    m1.add (new MenuItem ("Guardar"));
    m1.add (new CheckboxMenuItem ("Marcado",true));
    m1.add ("Guardar como...");
    Group m2=new Group ("Archivo",Group.MENU);
    m2.add ("Abrir");
    m2.add (m1);
    m2.add (null);
    m2.add ("Salir");
    Group m3=new Group ("Ayuda",Group.MENU);
    m3.add ("Sobre ApplicationFrame");
    m3.add ("Indice");
    Group m4=new Group (Group.MENU);
    m4.add (m2);
    m4.add (m3);

    Group c1=new Group (Group.VERTICAL);
    c1.add (new JButton ("Salir"),Group.C);
    c1.add (new JTextField ("Hola    "),Group.C);
    JComboBox ch=new JComboBox ();
    ch.addItem("JavaSoft");
    ch.addItem ("Earth");
    ch.addItem("Sol");
    ch.addItem("Luna");
    ch.addItem("Marte");
    c1.add (ch,Group.C);
    miJList lst=new miJList();

    lst.addItem("Mercury");
    lst.addItem("Venus");
    lst.addItem("Earth");
    lst.addItem("JavaSoft");
    lst.addItem("Mars");
    lst.addItem("Jupiter");
    lst.addItem("Saturn");
    lst.addItem("Uranus");
    lst.addItem("Neptune");
    lst.addItem("Pluto");
    c1.add (lst,Group.ALL);
    Group c2=new Group (Group.HORIZONTAL);
    c2.add (new TextArea (),Group.ALL);
    c2.add (c1,Group.ALL);

    ApplicationFrame af=new ApplicationFrame
      (new JFrame ("Ejemplo de ApplicationFrame"),c2,m4);

    af.center ();
    af.setVisible (true);
    for (;;)
      System.out.println (af.eventWait ());
  }
}
