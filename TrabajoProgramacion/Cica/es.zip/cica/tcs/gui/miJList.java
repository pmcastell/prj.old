package es.cica.tcs.gui;
import java.util.Vector;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class miJList extends JScrollPane {
   Vector actListeners=new Vector();
   Vector lista=new Vector();
   JList jlista=new JList();
   public miJList() {
      super();
      getViewport().add(jlista, null);
      createHorizontalScrollBar();
      createVerticalScrollBar();
      setAutoscrolls(true);
      setDoubleBuffered(true);
      jlista.setListData(lista);
//      lista.addElement("   ");
      jlista.addMouseListener(new MouseAdapter() {
         public void mousePressed(MouseEvent e) {
            if (e.getClickCount()>=2) {
               for(int i=0; i<actListeners.size(); i++) {
                  ((ActionListener) actListeners.elementAt(i)).actionPerformed(
                    new ActionEvent(miJList.this, ActionEvent.ACTION_PERFORMED, null));
               }
            }
         }
      });

   }
   public void addActionListener(ActionListener a) {
      actListeners.addElement(a);
   }
   public void removeActionListener(ActionListener a) {
      actListeners.removeElement(a);
   }

   public void addItem(String s) {
      lista.addElement(s);
      jlista.setListData(lista);
      jlista.ensureIndexIsVisible(jlista.getModel().getSize());
      repaint();
   }
   public String getSelectedItem() {
      return jlista.getSelectedValue().toString();
   }
   public int getItemCount() {
      return jlista.getModel().getSize();
   }
   public String getItem(int i) {
      return (String) lista.elementAt(i);
   }
   public void select(int i) {
      if (jlista!=null) {
         jlista.setSelectedIndex(i);
         repaint();
      }
   }
   public void removeElement(int i) {
      lista.removeElementAt(i);
      jlista.setListData(lista);
      repaint();
   }
   public void setFont(Font f) {
      if (jlista!=null) {
         jlista.setFont(f);
         repaint();
      }
   }
   public void setBounds(Rectangle r) {
      if (jlista!=null) {
         jlista.setBounds(r);
         repaint();
      }
   }
   public int getSelectedIndex() {
      if (jlista!=null) {
         return jlista.getSelectedIndex();
      }
      return -1;
   }
}


