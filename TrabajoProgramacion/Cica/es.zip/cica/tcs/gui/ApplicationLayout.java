package es.cica.tcs.gui;

import java.awt.*;
import java.util.*;

public class ApplicationLayout implements LayoutManager2
{
  private int type;
  private Component component[];
  private Point location[];
  private static final int MINIMUM=0,PREFERRED=1,MAXIMUM=2;

  public ApplicationLayout ()
  {
    type=Group.HORIZONTAL;
  }

  public ApplicationLayout (int t)
  {
    type=t;
  }

  public void invalidateLayout (Container parent)
  {
  }

  public float getLayoutAlignmentX (Container parent)
  {
    return (float)0.5;
  }

  public float getLayoutAlignmentY (Container parent)
  {
    return (float)0.5;
  }
  
  public void layoutContainer (Container parent)
  {
    if (component==null) return;
    int i,w0,h0,w1,h1,pw,ph,sw,sh;
    Dimension aux,size;
    Insets in=parent.getInsets ();
    size=parent.getSize ();
    sw=size.width;
    sh=size.height;
    pw=0;
    ph=0;
    boolean ch=false,cw=false;
    for (i=0;i<component.length;i++)
    {
      aux=component[i].getPreferredSize ();
      if (location[i].equals (Group.ALL))
      {
        ch=true;
        cw=true;
        continue;
      }
      if (location[i].equals (Group.V))
      {
        ch=true;
        if (type==Group.HORIZONTAL)
          pw+=aux.width;
        else
          if (aux.width>pw) pw=aux.width;
      }
      else if (location[i].equals (Group.H))
      {
        cw=true;
        if (type==Group.HORIZONTAL)
        {
          if (aux.height>ph) ph=aux.height;
        }
        else
          ph+=aux.height;
      }
      else
      {
        if (type==Group.HORIZONTAL)
        {
          pw+=aux.width;
          if (aux.height>ph) ph=aux.height;
        }
        else
        {
          ph+=aux.height;
          if (aux.width>pw) pw=aux.width;
        }
      }
    }
    size=parent.getPreferredSize ();
    w0=in.left;
    h0=in.top;
    int d0w,d0h,d1w,d1h,d2w,d2h,d3w,d3h;
    d0w=((sw>pw) ? sw-pw:1);
    d0h=((sh>ph) ? sh-ph:1);
    d1w=(cw ? size.width-pw:1);
    d1h=(ch ? size.height-ph:1);
    d2w=(cw ? 1:sw);
    d2h=(ch ? 1:sh);
    d3w=(cw ? 1:pw);
    d3h=(ch ? 1:ph);
    for (i=0;i<component.length;i++)
    {
      aux=component[i].getPreferredSize ();
      if (location[i].equals (Group.ALL))
      {
        if (type==Group.HORIZONTAL)
        {
          w1=w0+(aux.width*d0w)
            /
            d1w;
          h1=sh-in.bottom;
        }
        else
        {
          w1=sw-in.right;
          h1=h0+(aux.height*d0h)
            /
            d1h;
        }
        component[i].setSize (w1-w0,h1-h0);
        component[i].setLocation (w0,h0);
      }
      else if (location[i].equals (Group.V))
      {
        if (type==Group.HORIZONTAL)
        {
          w1=w0+(aux.width*d2w)
            /
            d3w;
          h1=sh-in.bottom;
        }
        else
        {
          w1=sw-in.right;
          h1=h0+(aux.height*d0h)
            /
            d1h;
        }
        component[i].setSize (aux.width,h1-h0);
        component[i].setLocation ((w0+w1-aux.width)/2,h0);
      }
      else if (location[i].equals (Group.H))
      {
        if (type==Group.HORIZONTAL)
        {
          w1=w0+(aux.width*d0w)
            /
            d1w;
          h1=sh-in.bottom;
        }
        else
        {
          w1=sw-in.right;
          h1=h0+(aux.height*d2h)
            /
            d3h;
        }
        component[i].setSize (w1-w0,aux.height);
        component[i].setLocation (w0,(h0+h1-aux.height)/2);
      }
      else
      {
        if (type==Group.HORIZONTAL)
        {
          w1=w0+(aux.width*d2w)
            /
            d3w;
          h1=sh-in.bottom;
        }
        else
        {
          w1=sw-in.right;
          h1=h0+(aux.height*d2h)
            /
            d3h;
        }
        component[i].setSize (aux.width,aux.height);
        component[i].setLocation
        (
          (w0+w1-aux.width-location[i].x*(w0-w1+aux.width))/2,
          (h0+h1-aux.height+location[i].y*(h0-h1+aux.height))/2
        );
      }
      if (type==Group.HORIZONTAL) w0=w1;
      else h0=h1;
    }
  }
  
  public void addLayoutComponent (String s,Component comp)
  {
    addLayoutComponent (comp,Group.ALL);
  }

  public void addLayoutComponent (Component comp,Object obj)
  {
    Point loc=(Point)obj;
    if (component==null)
    {
      component=new Component[1];
      location=new Point[1];
      component[0]=comp;
      location[0]=loc;
    }
    else
    {
      Component o[]=new Component[component.length+1];
      Point l[]=new Point[component.length+1];
      int i;
      for (i=0;i<component.length;i++)
      {
        o[i]=component[i];
        l[i]=location[i];
      }
      o[i]=comp;
      l[i]=loc;
      component=o;
      location=l;
    }
  }
  
  public void removeLayoutComponent (Component comp)
  {
    if (component==null) return;
    if (component.length==1)
    {
      if (component[0].equals (comp))
      {
        component=null;
        location=null;
      }
      else return;
    }
    int i,j;
    for (i=0;i<component.length;i++)
      if (component[i].equals (comp)) break;
    if (i==component.length) return;
    Component c[]=new Component[component.length-1];
    Point l[]=new Point[component.length-1];
    for (j=0;j<c.length;j++)
    {
      if (j<i)
      {
        c[j]=component[j];
        l[j]=location[j];
      }
      else
      {
        c[j]=component[j+1];
        l[j]=location[j+1];
      }
    }
  }
  
  private Dimension allLayoutSize (int t,Container parent)
  {
    if (component==null) return new Dimension (0,0);
    int i,w=0,h=0;

    Dimension aux;
    for (i=0;i<component.length;i++)
    {
      switch (t)
      {
        case MINIMUM:
          aux=component[i].getMinimumSize ();
          break;
        case PREFERRED:
        default:
          aux=component[i].getPreferredSize ();
          break;
        case MAXIMUM:
          aux=component[i].getMaximumSize ();
      }
      if (type==Group.HORIZONTAL)
      {
        w+=aux.width;
        if (aux.height>h) h=aux.height;
      }
      else
      {
        h+=aux.height;
        if (aux.width>w) w=aux.width;
      }
    }
    Insets in=parent.getInsets ();
    return new Dimension (w+in.left+in.right,h+in.top+in.bottom);
  }

  public Dimension preferredLayoutSize (Container parent)
  {
    return allLayoutSize (PREFERRED,parent);
  }

  public Dimension minimumLayoutSize (Container parent)
  {
    return allLayoutSize (MINIMUM,parent);
  }

  public Dimension maximumLayoutSize (Container parent)
  {
    return allLayoutSize (MAXIMUM,parent);
  }

  public static void main (String arg[])
  {
    Frame f=new Frame ("Prueba de Layout");
    f.setLayout (new ApplicationLayout (Group.HORIZONTAL));
    Choice c=new Choice ();
    c.addItem ("1");
    c.addItem ("2");
    f.add (new Button ("boton"),Group.ALL);
    f.add (new Label ("etiqueta"),Group.S);
    f.add (c,Group.C);
    f.pack ();
    f.setVisible (true);
  }
}
