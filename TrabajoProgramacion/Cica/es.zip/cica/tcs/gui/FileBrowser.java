package es.cica.tcs.gui;

import java.io.*;
import java.awt.*;
import java.awt.event.*;

public class FileBrowser implements ActionListener
{
  FileDialog fileDialog;
  Button button;
  TextField textField;
  String directory,file;
  boolean dispatch=false;
  
  public FileBrowser (String t,Button b,TextField f)
  {
    b.addActionListener (this);
    button=b;
    textField=f;
    file=f.getText ();
    directory=new String ("");
    fileDialog=new FileDialog (new Frame (),t);
  }
  
  public void actionPerformed (ActionEvent e)
  {
    if (dispatch) return;
    dispatch=true;
    button.dispatchEvent (e);
    if (directory!=null)
    {
      fileDialog.setDirectory (directory);
      fileDialog.setFile (file);
    }
    fileDialog.setVisible (true);
    directory=fileDialog.getDirectory ();
    if (fileDialog.getFile ()!=null)
    {
      file=fileDialog.getFile ();
    }
    textField.setText (directory+file);
    button.dispatchEvent (e);
    dispatch=false;
  }
  
  public static void main (String arg[])
  {
    Frame f=new Frame ("Prueba de FileBrowser");
    f.setLayout (new FlowLayout ());
    Button b=new Button ("Explorar...");
    TextField tf=new TextField (20);
    f.add (tf);
    f.add (b);
    f.pack ();
    f.setVisible (true);
    FileBrowser fb=new FileBrowser ("Fichero",b,tf);
  }
}
