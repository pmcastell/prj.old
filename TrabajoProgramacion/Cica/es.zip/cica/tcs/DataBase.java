package es.cica.tcs;

import java.io.*;
import es.cica.tcs.util.*;
import iaik.asn1.structures.*;
import iaik.asn1.CodingException;
import es.cica.tcs.RegDirectorio;
import es.cica.tcs.DBInfo;
import iaik.security.rsa.RSAPublicKey;

public class DataBase
{
  private final long NULL=0,SEEK_SIZE_BLOCK=0,SEEK_GARBAGE=4,SEEK_INDEX=12;
  private long garbage=NULL,index=NULL;
  private int sizeBlock=64-8,searchIndex;
  private RandomAccessFile file;
  private String fileName;
  private byte fill[];


  protected void finalize()
  {
     close();
  }
  public void close()
  {
     try {
        file.close();
     } catch (Exception ex) {
     }
  }

  public void open(String f,int sb) throws IOException
  {
    fileName=f;
    sizeBlock=sb-8;
    fill=new byte[sizeBlock];
    for (int i=0;i<sizeBlock;i++) fill[i]=0;
    file=new RandomAccessFile (fileName,"rw");
    if (file.length ()==0)
    {
      file.writeInt (sizeBlock);
      file.writeLong (garbage);
      file.writeLong (index);
    }
    else throw new IOException ("No se puede cambiar el tama�o del bloque.");
  }

  public void open(String f) throws IOException
  {
    fileName=f;
    fill=new byte[sizeBlock];
    for (int i=0;i<sizeBlock;i++) fill[i]=0;
    file=new RandomAccessFile (fileName,"rw");
    if (file.length ()==0)
    {
      file.writeInt (sizeBlock);
      file.writeLong (garbage);
      file.writeLong (index);
    }
    else
    {
      sizeBlock=file.readInt ();
      garbage=file.readLong ();
      index=file.readLong ();
    }
  }

  private byte[] internalData (byte d[])
  {
    int i;
    byte r[]=new byte [((d.length+4)/sizeBlock+1)*sizeBlock];
    for (i=0;i<4;i++) r[3-i]=(byte)(((d.length)>>(i*8))&0xff);
    for (i=0;i<d.length;i++) r[i+4]=d[i];
    return r;
  }

  private synchronized long writeBlock (byte d[],int i) throws IOException
  {
    long pos;

    if (garbage==NULL)
    {
      pos=file.length ();
      file.seek (pos);
      file.writeLong (NULL);
      file.write (d,i,sizeBlock);
    }
    else
    {
      pos=garbage;
      file.seek (garbage);
      garbage=file.readLong ();
      file.seek (SEEK_GARBAGE);
      file.writeLong (garbage);
      file.seek (pos);
      file.writeLong (NULL);
      file.write (d,i,sizeBlock);
    }
    return pos;
  }

  private synchronized long write (byte d[]) throws IOException
  {
    byte id[]=internalData (d);

    long p1=NULL,p2,r=NULL;
    for (int i=0;i<id.length;i+=sizeBlock)
    {
      p2=writeBlock (id,i);
      if (p1!=NULL)
      {
        file.seek (p1);
        file.writeLong (p2);
      }
      else r=p2;
      p1=p2;
    }
    return r;
  }

  private synchronized void reWrite (long r,byte d[]) throws IOException
  {
    byte id[]=internalData (d);

    file.seek (r);
    long p=file.readLong ();
    file.seek (r);
    file.writeLong (NULL);
    file.write (id,0,sizeBlock);
    if (p!=NULL)
    {
      file.seek (p);
      delete ();
      p=NULL;
    }
    for (int i=sizeBlock;i<id.length;i+=sizeBlock)
    {
      p=writeBlock (id,i);
      file.seek (r);
      file.writeLong (p);
      r=p;
    }
  }

  private synchronized void reWrite (byte d[]) throws IOException
  {
    byte id[]=internalData (d);
    long s;

    s=file.readLong ();
    for (int i=0;i<id.length;i+=sizeBlock)
    {
      file.write (id,i,sizeBlock);
      if (s==NULL) break;
      file.seek (s);
      s=file.readLong ();
    }
  }

  private synchronized byte[] read () throws IOException
  {
    long s;
    int i,j,l;
    byte r[],a[]=new byte[sizeBlock];

    s=file.readLong ();
    l=file.readInt ();
    r=new byte[l];
    file.read (a,0,sizeBlock-4);
    for (i=0,j=0;i<l && j<sizeBlock-4;i++,j++) r[i]=a[j];
    for (;s!=NULL;)
    {
      file.seek (s);
      s=file.readLong ();
      file.read (a,0,sizeBlock);
      for (j=0;i<l && j<sizeBlock;i++,j++)
        r[i]=a[j];
    }
    return r;
  }

  public synchronized void modify (byte k[],byte d[]) throws IOException
  {
    delete (k);
    insert (k,d);
  }

  public synchronized void delete (byte k[]) throws IOException
  {
    if (delete (index,k))
    {
      file.seek (SEEK_INDEX);
      index=NULL;
      file.writeLong (index);
    }
  }

  private synchronized boolean delete (long cml,byte k[]) throws IOException
  {
    if (cml==NULL) return false;
    file.seek (cml);
    CMem cm=new CMem (read ());
    int i,j;
    for (i=0;i<cm.key.length;i++)
    {
      j=coincide (cm.key[i],k);
      if (j!=-1)
      {
        if (j==cm.key[i].length-1)
        {
          if (j==k.length-1)
          { 
            if (cm.key.length==1)
            {
              file.seek (cml);
              delete ();
              return true;
            }
            else
            {
              CMem cma=new CMem ();
              cma.key=new byte[cm.key.length-1][];
              cma.data=new byte[cm.key.length-1][];
              cma.secondKey=new long[cm.key.length-1];
              int jj;
              for (jj=0,j=0;j<cm.key.length;j++)
              {
                if (j!=i)
                {
                  cma.key[jj]=cm.key[j];
                  cma.data[jj]=cm.data[j];
                  cma.secondKey[jj]=cm.secondKey[j];
                  jj++;
                }
              }
              reWrite (cml,cma.toByteArray ());
              return false;
            }
          }
          if (delete (cm.secondKey[i],subByteArray (k,j+1)))
          {
            cm.secondKey[i]=NULL;
            file.seek (cml);
            reWrite (cm.toByteArray ());
            return false;
          }
        }
        return false;
      }
    }
    return false;
  }

  private synchronized void delete () throws IOException
  {
    long l=file.getFilePointer (),s,t;

    for (s=SEEK_GARBAGE,t=garbage;t!=NULL;)
    {
      s=t;
      file.seek (s);
      t=file.readLong ();
    }
    if (s==SEEK_GARBAGE) garbage=l;
    file.seek (s);
    file.writeLong (l);
  }


  public synchronized long insert (byte k[],byte d[]) throws IOException
  {
    long i=insert (index,k,d);
    if (i==NULL) return i;
    if (index!=i)
    {
      index=i;
      file.seek(SEEK_INDEX);
      file.writeLong(i);
    }
    return i;
  }

  private synchronized long insert (long cml,byte k[],byte d[]) throws IOException
  {
    int i;
    CMem cma=new CMem (),cm;
    if (cml==NULL)
    {
      cma.data=new byte[1][];
      cma.key=new byte[1][];
      cma.secondKey=new long[1];
      cma.data[0]=(byte[])d.clone ();
      cma.key[0]=(byte[])k.clone ();
      cma.secondKey[0]=NULL;
      return write (cma.toByteArray ());
    }
    else
    {
      file.seek (cml);
      cm=new CMem (read ());
      int j;
      for (i=0;i<cm.key.length;i++)
      {
        j=coincide (cm.key[i],k);
        if (j!=-1)
        {
          if (j==cm.key[i].length-1)
          {
            if (j==k.length-1)
            {
              if (cm.data[i]!=null) return NULL;
              cm.data[i]=(byte[])d.clone ();
              file.seek (cml);
              delete ();
              return write (cm.toByteArray ());
            }
            long l=insert (cm.secondKey[i],subByteArray (k,j+1),d);
            if (l==NULL) return NULL;
            if (cm.secondKey[i]!=l)
            {
              cm.secondKey[i]=l;
              file.seek (cml);
              reWrite (cm.toByteArray ());
            }
            return NULL;
          }
          if (j==k.length-1)
          {
            cma.key=new byte[1][];
            cma.data=new byte[1][];
            cma.secondKey=new long[1];
            cma.key[0]=subByteArray (cm.key[i],j+1);
            cma.data[0]=cm.data[i];
            cma.secondKey[0]=cm.secondKey[i];
            cm.data[i]=(byte[])d.clone ();
          }
          else
          {
            cma.key=new byte[2][];
            cma.data=new byte[2][];
            cma.secondKey=new long[2];
            cma.key[0]=subByteArray (cm.key[i],j+1);
            cma.secondKey[0]=cm.secondKey[i];
            cma.data[0]=cm.data[i];
            cma.key[1]=subByteArray (k,j+1);
            cma.data[1]=(byte[])d.clone ();
            cma.secondKey[1]=NULL;
            cm.data[i]=null;
          }
          cm.key[i]=subByteArray (j,k);
          cm.secondKey[i]=write (cma.toByteArray ());
          file.seek (cml);
          delete ();
          return write (cm.toByteArray ());
        }
      }
    }
    byte nk[][]=new byte[cm.key.length+1][];
    byte nd[][]=new byte[cm.key.length+1][];
    long nsk[]=new long[cm.key.length+1];
    for (i=0;i<cm.key.length;i++)
    {
      nk[i]=cm.key[i];
      nd[i]=cm.data[i];
      nsk[i]=cm.secondKey[i];
    }
    nk[i]=(byte[])k.clone ();
    nd[i]=(byte[])d.clone ();
    nsk[i]=NULL;
    cm.key=nk;
    cm.data=nd;
    cm.secondKey=nsk;
    file.seek (cml);
    delete ();
    return write (cm.toByteArray ());
  }

  public static byte[] concat (byte b1[],byte b2[])
  {
    if (b1==null && b2==null) return null;
    if (b1==null) return (byte[])b2.clone ();
    if (b2==null) return (byte[])b1.clone ();
    byte r[]=new byte[b1.length+b2.length];
    System.arraycopy (b1,0,r,0,b1.length);
    System.arraycopy (b2,0,r,b1.length,b2.length);
    return r;
  }

  public synchronized void compact () throws IOException
  {
    if (garbage==NULL) return;
    DataBase db=new DataBase();
    db.open(fileName+".comp",sizeBlock+8);
    compact (db,index,null);
    file.close ();
    File f=new File (fileName);
    f.delete ();
    File nf=new File (fileName+".comp");
    nf.renameTo (f);
    file=new RandomAccessFile (fileName,"rw");
    sizeBlock=file.readInt ();
    garbage=file.readLong ();
    index=file.readLong ();
  }

  private synchronized void compact (DataBase db,long cml,byte k[]) throws IOException
  {
    if (cml==NULL) return;
    file.seek (cml);
    CMem cm=new CMem (read ());
    int i;
    byte c[];
    for (i=0;i<cm.key.length;i++)
    {
      c=concat (k,cm.key[i]);
      compact (db,cm.secondKey[i],c);
      if (cm.data[i]!=null)
        db.insert (c,cm.data[i]);
    }
  }


  public byte[][] _search (int ind) throws IOException
  {
    searchIndex=0;
    return _search (index,ind,null);
  }

  private byte[][] _search (long cml,int ind,byte k[]) throws IOException
  {
    if (cml==NULL) return null;
    file.seek (cml);
    CMem cm=new CMem (read ());
    int i,j;
    for (i=0;i<cm.key.length;i++)
    {
      if (cm.data[i]!=null)
      {
        if (ind==searchIndex)
        {
          byte r[][]=new byte[2][];
          r[0]=concat (k,cm.key[i]);
          r[1]=cm.data[i];
          return r;
        }
        searchIndex++;
      }
      byte aux[][]=_search (cm.secondKey[i],ind,concat (k,cm.key[i]));
      if (aux!=null) return aux;
      if (ind<searchIndex) return null;
    }
    return null;
  }

  public byte[] _search (byte k[]) throws IOException
  {
    return _search (index,k);
  }

  private byte[] _search (long cml,byte k[]) throws IOException
  {
    if (cml==NULL) return null;
    file.seek (cml);
    CMem cm=new CMem (read ());
    int i,j;
    for (i=0;i<cm.key.length;i++)
    {
      j=coincide (cm.key[i],k);
      if (j!=-1)
      {
        if (j==cm.key[i].length-1)
        {
          if (j==k.length-1)
            return cm.data[i];
          return _search (cm.secondKey[i],subByteArray (k,j+1));
        }
        return null;
      }
    }
    return null;
  }

  public static int coincide (byte a[],byte b[])
  {
    int r=-1;
    int l=a.length;
    if (l>b.length) l=b.length;
    for (int i=0;i<l && a[i]==b[i];i++)
      r=i;
    return r;
  }

  public static byte[] subByteArray (byte b[],int i)
  {
    byte r[]=new byte[b.length-i];
    int j=i;
    for (;i<b.length;i++) r[i-j]=b[i];
    return r;
  }

  public static byte[] subByteArray (int i,byte b[])
  {
    byte r[]=new byte[i+1];
    for (;i>=0;i--) r[i]=b[i];
    return r;
  }

  public static Object toObject (byte obj[])
  {
    try
    {
      Object r;
      ByteArrayInputStream b=new ByteArrayInputStream (obj);
      ObjectInputStream i=new ObjectInputStream (b);
      r=i.readObject ();
      i.close ();
      b.close ();
      return r;
   }
   catch (Exception e)
   {
     return null;
   }
  }

  public static byte[] toByteArray (Object obj)
  {
    try
    {
      byte r[];
      ByteArrayOutputStream b=new ByteArrayOutputStream ();
      ObjectOutputStream o=new ObjectOutputStream (b);
      o.writeObject (obj);
      o.flush ();
      r=b.toByteArray ();
      o.close ();
      b.close ();
      return r;
   }
   catch (IOException e)
   {
     return null;
   }
  }

  public static String dbInfoToString(DBInfo db) {
     String s="";
     if (db!=null) {
        s+="Password: ";
        if (db.password!=null) {
           for(int i=0; i<db.password.length; i++) {
              s+=(char) db.password[i];
           }
        }
        s+=".\n PublicKey: ";
        if (db.publicKey!=null) {
           s+=db.publicKey.toString();
        }
        s+=".\n PrivateKey: ";
        if (db.privateKey!=null) {
           s+=db.privateKey.toString();
        }
     }
     return s;
  }
  public static void printUserInfo(UserInfo ui)
  {
     if (ui.time!=null) {
        System.out.print("Time: ");
        for(int i=0;i<ui.time.length;i++) {
           System.out.print(Integer.toString(ui.time[i]));
           if (i<ui.time.length-1) {
              System.out.print(",");
           }
        }
        System.out.println(".");
     } else {
        System.out.print("Time: null\n");
     }
     if (ui.url!=null) {
        System.out.print("Urls: ");
        for(int i=0; i<ui.url.length; i++) {
           System.out.print(ui.url[i]);
           if (i<ui.url.length-1) {
              System.out.print(",");
           }
        }
        System.out.println();

     } else {
        System.out.print("Urls: null\n");
     }
     if (ui.publicKey!=null) {
        System.out.print("PublicRSAKey: "+ui.publicKey.toString()+"\n");
     } else {
        System.out.print("PublicRSAKey: null\n");
     }
  }

  /**
  * Este main fusiona las antiguas bases de datos
  * bd.dat y directorio.dat en la nueva base de dats
  */
  public static void main(String arg[]) throws IOException
  {
     DataBase db=new DataBase(), directorio=new DataBase(),
              salida=new DataBase();

     db.open("db.dat");
     directorio.open("directorio.dat");
     salida.open("prueba.dat");
     byte dbb[], directoriob[][], pruebab[][];
     int i=0;
     Name nombre=new Name(), nombre2;
     RegDirectorio regdir;
     UserInfo ui;
     DBInfo dbinfo;
     // Este while mezcla ambas bases de datos tirando del directorio
     while (true) {
        regdir=new RegDirectorio();
        directoriob=directorio._search(i++);
        if (directoriob==null) {
           break;
        }
        try {
           nombre= new Name(directoriob[0]);
        } catch (CodingException ex) {
        }

        System.out.println(nombre.toString());
        ui=(UserInfo) toObject(directoriob[1]);
        regdir.setName(nombre);
        regdir.setTime(ui.time);
        regdir.setUrl(ui.url);
        regdir.setPublicRSAKey(ui.publicKey);
        dbb=db._search(nombre.getEncoded());
        if (dbb!=null) {
        //   nombre2=(Name) toObject(dbb[0]);
           dbinfo=(DBInfo) toObject(dbb);
           if (dbinfo!=null) {
              regdir.setPassword(dbinfo.password);
              regdir.setPublicKey(dbinfo.publicKey);
              regdir.setPrivateKey(dbinfo.privateKey);
           }
        }
        salida.insert(nombre.getEncoded(), toByteArray(regdir));
     }
     i=0;
     String s;
     System.out.println("---------------------------------------");
     System.out.println("Base de Datos Salida:");
     System.out.println("---------------------------------------");
     while(true) {
        pruebab=salida._search(i++);
        if (pruebab==null) {
           break;
        }
        regdir=(RegDirectorio) toObject(pruebab[1]);
        System.out.println("\nRegistro "+i+"-----------------------------------");
        regdir.print();
     }
     System.out.println("---------------------------------------");
     System.out.println("Base de datos db:");
     System.out.println("---------------------------------------");
     i=0;
     while (true) {
        pruebab=db._search(i++);
        if (pruebab==null) {
           break;
        }

        dbinfo=(DBInfo) toObject(pruebab[1]);
        System.out.println("\nRegistro "+i+":");
        try {
           System.out.println("Nombre: "+new Name(pruebab[0]));
        } catch (Exception ex) {
        }
        System.out.println(dbInfoToString(dbinfo));
     }
     System.out.println("---------------------------------------");
     System.out.println("Base de datos directorio:");
     System.out.println("---------------------------------------");
     i=0;
     while (true) {
        pruebab=directorio._search(i++);
        if (pruebab==null) {
           break;
        }

        ui=(UserInfo) toObject(pruebab[1]);
        System.out.println("\nRegistro "+i+":");
        try {
           System.out.println("Nombre: "+new Name(pruebab[0]));
        } catch (Exception ex) {
        }
        printUserInfo(ui);

     }
     new DataBase().open("pruebecita.dat");
  }

 /* public static void main(String arg[]) throws IOException
  {
     DataBase pr=new DataBase();
     Name p=new Name();
     db.open("prr.dat");
     p.*/



/*  public static void main (String arg[]) throws IOException
  {
    DataBase db=new DataBase();
    db.open("leche.dat");
    db.insert("Francisco Javier Criado Navarro".getBytes(), "El listo".getBytes());
    db.insert("Francisco Javier Criado Navarro".getBytes(), "El tont�n".getBytes());
    db.insert("Francisco Javier Criado Navarro".getBytes(), "El Iluso".getBytes());
    db.insert("Francisco Javier Criado Navarro".getBytes(), "Hay que tonto es".getBytes());
    db.modify("Francisco Javier Criado Navarro".getBytes(), "Hay que tonto es".getBytes());
    byte[][] tontin;
    int i=0;
    while (true) {
       tontin=db._search(i++);
       if (tontin==null) {
          break;
       }
       System.out.println(new String(tontin[0])+"-->"+new String(tontin[1]));
    }

    db.insert ("comen".getBytes (),"6".getBytes ());
    db.insert ("comeis".getBytes (),"5".getBytes ());
    db.insert ("comemos".getBytes (),"4".getBytes ());
    db.insert ("come".getBytes (),"3".getBytes ());
    db.insert ("comes".getBytes (),"2".getBytes ());
    db.insert ("como".getBytes (),"1".getBytes ());
    byte b[][];
    i=0;
    String nombre;
    String datos;
    while (true) {
       b=db._search(i++);
       if (b==null) {
          break;
       }
        nombre=new String(b[0]);
        datos=new String(b[1]);
        System.out.println(nombre);
        System.out.println(datos);
    }


    db.delete ("comes".getBytes ());
    db.delete ("comemos".getBytes ());
    db.close();
    db.compact ();
//    System.out.println (new String (db.search ("comeis".getBytes ())));
//    if (db.search ("comes".getBytes ())!=null)
//      System.out.println (new String (db.search ("comes".getBytes ())));
  }*/
}
