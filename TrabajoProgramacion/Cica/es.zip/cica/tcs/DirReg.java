package es.cica.tcs;

import java.io.*;

import iaik.asn1.structures.Name;
import iaik.x509.*;
import iaik.pkcs.pkcs8.*;

public class DirReg implements Serializable
{
  public Name name;
  public byte password[];
  public PublicKeyInfo publicKey;
  public EncryptedPrivateKeyInfo privateKey;
}
