package es.cica.tcs;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.StringTokenizer;
import java.security.Provider;
import java.security.Security;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.*;
import java.security.spec.*;

import iaik.security.ssl.*;
import iaik.security.provider.IAIK;
import iaik.asn1.*;
import iaik.asn1.structures.*;
import iaik.pkcs.*;
import iaik.pkcs.pkcs8.*;
import iaik.security.cipher.*;
import iaik.security.rsa.*;
import iaik.x509.*;
import iaik.x509.X509Certificate;
import iaik.utils.Util;

import es.cica.tcs.util.*;
import es.cica.tcs.gui.*;

public class TCFrame
{
  private final int RUN=0,RECONFIG=1,STOP=2,EXIT=-1;
  private int
    tccPort=4433,
    irPort=4434,
    controlPort=4435,
    connectPort=4435,
    timeOut=5*60*1000,
    soTimeOut=20*1000,
    secretLength=32,
    log=0;
  private Name caName[];
  private String caURL[],password[],controlPassword,connectPassword="",connectHost="localhost";
  private EncryptedPrivateKeyInfo caPrivateKey[];
  private CicaP12 connectPKCS12,controlPKCS12;
  private int passwordIndex;
  private PrivateKeyInfo privateKey[],controlPrivateKey;
  private String userFile,logFile,htmlError;
  private ApplicationFrame applicationFrame;
  private TextField
    passwordField,
    connectPasswordField,
    connectHostField,
    connectPortField,
    tccPortField,
    irPortField,
    controlPortField,
    timeField,
    soTimeField,
    secretField,
    logField,
    logFileField,
    userFileField,
    htmlField;
  private Choice urlChoice;
  private Button
    logFileButton,
    userFileButton,
    htmlButton,
    buttonAccept,
    buttonCancel,
    buttonStop,
    buttonRun;

  public String getPasswordUrl ()
  {
    return caURL[passwordIndex];
  }

  public void windowInit ()
  {
    int i;
    passwordField=new TextField (40);
    passwordField.setEchoChar ('*');
    tccPortField=new TextField (""+tccPort,8);
    irPortField=new TextField (""+irPort,8);
    timeField=new TextField (""+timeOut,8);
    soTimeField=new TextField (""+soTimeOut,8);
    secretField=new TextField (""+secretLength,4);
    logField=new TextField (""+log,6);
    connectHostField=new TextField (connectHost,14);
    connectPasswordField=new TextField (40);
    connectPasswordField.setEchoChar ('*');
    controlPortField=new TextField (""+controlPort,6);
    connectPortField=new TextField (""+connectPort,6);
    buttonRun=new Button ("Reconfigurar");
    buttonStop=new Button ("Parar");

    userFileField=new TextField (""+userFile,40);
    userFileButton=new Button ("Explorar...");
    new FileBrowser ("Fichero de Usuarios",userFileButton,userFileField);
    logFileField=new TextField (""+logFile,40);
    logFileButton=new Button ("Explorar...");
    new FileBrowser ("Fichero de Log",logFileButton,logFileField);
    htmlField=new TextField (""+htmlError,40);
    htmlButton=new Button ("Explorar...");
    new FileBrowser ("Pagina de Error",htmlButton,htmlField);

    urlChoice=new Choice ();
    for (i=0;i<caURL.length;i++) urlChoice.add (caURL[i]+"  ");
    if (controlPKCS12!=null) urlChoice.add ("TCSC");
    buttonAccept=new Button ("Arrancar");
    buttonCancel=new Button ("Salir");

    Group c=new Group (Group.VERTICAL);
    Group c0=new Group (Group.HORIZONTAL);
    Group c1=new Group (Group.HORIZONTAL);
    Group c2=new Group (Group.HORIZONTAL);
    Group c3=new Group (Group.HORIZONTAL);
    Group c4=new Group (Group.VERTICAL);
    Group c5=new Group (Group.VERTICAL);
    Group c6=new Group (Group.VERTICAL);
    Group c7=new Group (Group.VERTICAL);
    Group c8=new Group (Group.VERTICAL);
    Group c9=new Group (Group.VERTICAL);
    Group c10=new Group (Group.VERTICAL);
    Group c11=new Group (Group.VERTICAL);
    Group c12=new Group (Group.HORIZONTAL);
    Group c13=new Group (Group.HORIZONTAL);
    Group c14=new Group (Group.HORIZONTAL);
    Group c15=new Group (Group.HORIZONTAL);
    Group c16=new Group (Group.HORIZONTAL);
    Group c17=new Group (Group.HORIZONTAL);

    c12.add (new Label ("Servicio"),Group.W);
    c12.add (urlChoice,Group.H);
    c12.add (new Label ("PassFrase",Label.RIGHT),Group.W);
    c5.add (passwordField,Group.H);
    c13.add (new Label ("TCS"),Group.W);
    c13.add (connectHostField,Group.H);
    c13.add (connectPortField,Group.H);
    c13.add (buttonRun,Group.C);
    c13.add (buttonStop,Group.C);
    c13.add (new Label ("PassFrase",Label.RIGHT),Group.W);
    c5.add (connectPasswordField,Group.H);
    c2.add (buttonAccept,Group.C);
    c2.add (buttonCancel,Group.C);
    c15.add (new Label ("Fichero de Usuarios"),Group.W);
    c16.add (new Label ("Fichero de Log"),Group.W);
    c14.add (new Label ("Pagina de Error"),Group.W);
    c11.add (userFileField,Group.H);
    c11.add (logFileField,Group.H);
    c11.add (htmlField,Group.H);
    c15.add (userFileButton,Group.E);
    c16.add (logFileButton,Group.E);
    c14.add (htmlButton,Group.E);
    c6.add (new Label ("TCC Port"),Group.W);
    c7.add (tccPortField,Group.H);
    c6.add (new Label ("IR Port"),Group.W);
    c7.add (irPortField,Group.H);
    c6.add (new Label ("TCSC Port"),Group.W);
    c7.add (controlPortField,Group.H);
    c8.add (new Label ("Nivel de Log"),Group.W);
    c9.add (logField,Group.H);
    c8.add (new Label ("TCC/IR Timeout"),Group.W);
    c9.add (timeField,Group.H);
    c8.add (new Label ("Socket Timeout"),Group.W);
    c9.add (soTimeField,Group.H);
    c17.add (new Label ("RNSize"),Group.W);
    c17.add (secretField,Group.H);

    c10.add (c15);
    c10.add (c16);
    c10.add (c14);
    c3.add (c10);
    c3.add (c11);
    c4.add (c12);
    c4.add (c13);
    c0.add (c4);
    c0.add (c5);

    c.add (c0);
    c.add (c3);
    c2.add (c1,Group.E);
    c.add (c2);
    c1.add (c17,Group.N);
    c1.add (c8);
    c1.add (c9);
    c1.add (c6);
    c1.add (c7);
    applicationFrame=new ApplicationFrame ("Control del TCS",c);
    applicationFrame.center ();
  }

  public void config (InputStream fin)
    throws
      IOException,
      PKCSException,
      CodingException,
      InvalidKeyException,
      NumberFormatException,
      GeneralSecurityException,
      NoSuchAlgorithmException,
      Exception
  {
    BufferedReader br=new BufferedReader (new InputStreamReader (fin));
    String line;
    StringTokenizer st;
    String var;
    while ((line=br.readLine ())!=null)
    {
      if (line.startsWith ("#")) continue;
      st=new StringTokenizer (line," \t\r");
      if (!st.hasMoreTokens ()) continue;
      var=st.nextToken ();
      if (var.equals ("END")) break;
      if (var.equals ("TCCPORT")) tccPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("IRPORT")) irPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("CONTROLPORT")) controlPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("CONNECTPORT")) connectPort=Integer.parseInt (st.nextToken ());
      else if (var.equals ("CONNECTHOST")) connectHost=st.nextToken ();
      else if (var.equals ("LOG")) log=Integer.parseInt (st.nextToken ());
      else if (var.equals ("LOGFILE")) logFile=st.nextToken ();
      else if (var.equals ("USERFILE")) userFile=st.nextToken ();
      else if (var.equals ("HTMLERROR"))
        htmlError=st.nextToken ();
      else if (var.equals ("TIMEOUT")) timeOut=Integer.parseInt (st.nextToken ());
      else if (var.equals ("SOTIMEOUT")) soTimeOut=Integer.parseInt (st.nextToken ());
      else if (var.equals ("SECRETLENGTH")) secretLength=Integer.parseInt (st.nextToken ());
      else if (var.equals ("ISSUER"))
        readIssuer (br,line.substring ("ISSUER".length ()));
      else if (var.equals ("TCSC"))
        readTcsc (br,var);
      else if (var.equals ("TCSCREMOTE"))
        readTcsc (br,var);
      else throw new Exception ("Error de formato. Linea erronea: "+line);
    }
    password=new String[caURL.length];
    for (int i=0;i<password.length;i++) password[i]=new String ("");
    privateKey=new PrivateKeyInfo[caPrivateKey.length];
  }

  public void readTcsc (BufferedReader f,String opt)
    throws PKCSException,CodingException,InvalidKeyException,IOException,NoSuchAlgorithmException,GeneralSecurityException,ArrayIndexOutOfBoundsException
  {
    StringBuffer k=new StringBuffer ("");
    String line;
    for (;;)
    {
     line=f.readLine ();
     k.append (line+"\n");
     if (line.startsWith (CicaP12.endLine)) break;
    }
    if (opt.equals ("TCSCREMOTE"))
      connectPKCS12=new CicaP12 (k.toString ().getBytes ());
    else if (opt.equals ("TCSC"))
    {
      controlPKCS12=new CicaP12 (k.toString ().getBytes ());
    }
  }


  public void readIssuer (BufferedReader f,String s)
    throws PKCSException,CodingException,InvalidKeyException,IOException,NoSuchAlgorithmException,GeneralSecurityException,ArrayIndexOutOfBoundsException
  {
    StringBuffer k=new StringBuffer ("");
    String line;
    for (;;)
    {
     line=f.readLine ();
     k.append (line+"\n");
     if (line.startsWith (CicaP12.endLine)) break;
    }
    Name auxName[];
    String auxURL[];
    EncryptedPrivateKeyInfo auxPrivateKey[];
    int i=0;
    if (caName==null)
    {
      auxName=new Name[1];
      auxURL=new String[1];
      auxPrivateKey=new EncryptedPrivateKeyInfo[1];
    }
    else
    {
      auxName=new Name[caName.length+1];
      auxURL=new String[caName.length+1];
      auxPrivateKey=new EncryptedPrivateKeyInfo[caName.length+1];
      for (;i<caName.length;i++)
      {
        auxName[i]=caName[i];
        auxURL[i]=caURL[i];
        auxPrivateKey[i]=caPrivateKey[i];
      }
    }
    caName=auxName;
    caURL=auxURL;
    caPrivateKey=auxPrivateKey;
    StringTokenizer st;
    st=new StringTokenizer (s," \t\r");
    caURL[i]=st.nextToken ();
    caName[i]=TCUtil.toName (s.substring (s.indexOf (caURL[i])+caURL[i].length ()));
    caPrivateKey[i]=new CicaP12 (k.toString ().getBytes ()).getEncryptedPrivateKey ();
  }

  private int windowGet () throws NoSuchAlgorithmException,GeneralSecurityException,NumberFormatException
  {
    AWTEvent event;
    Object o;
    boolean enable=true;
    int get=RUN;
    for (;;)
    {
      event=applicationFrame.eventWait ();
      if (event.getID ()==WindowEvent.WINDOW_CLOSING) return EXIT;
      o=event.getSource ();
      if (o.equals (buttonCancel)) return EXIT;
      else if
      (
        o.equals (userFileButton) ||
        o.equals (logFileButton) ||
        o.equals (htmlButton)
      )
      {
        enable=!enable;
        applicationFrame.setEnabled (enable);
      }
      else if (o.equals (buttonRun) || o.equals (buttonStop))
      {
        connectPort=Integer.parseInt (connectPortField.getText ());
        connectHost=connectHostField.getText ();
        connectPassword=connectPasswordField.getText ();
        get=o.equals (buttonRun) ? RECONFIG:STOP;
        break;
      }
      if
      (
        o.equals (userFileField) ||
        o.equals (logFileField) ||
        o.equals (htmlField) ||
        o.equals (buttonAccept) ||
        o.equals (tccPortField) ||
        o.equals (irPortField) ||
        o.equals (timeField) ||
        o.equals (soTimeField) ||
        o.equals (logField) ||
        o.equals (secretField)
      ) break;
      if (o.equals (passwordField))
      {
        passwordIndex=urlChoice.getSelectedIndex ();
        if (passwordIndex==password.length)
        {
          controlPassword=new String (passwordField.getText ());
          if (!controlPassword.equals (""))
          {
            controlPrivateKey=controlPKCS12.getEncryptedPrivateKey ().decrypt (controlPassword);
            urlChoice.remove (passwordIndex);
            urlChoice.insert ("TCSC *",passwordIndex);
            passwordIndex++;
          }
          else
          {
            controlPrivateKey=null;
            urlChoice.remove (passwordIndex);
            urlChoice.insert ("TCSC  ",passwordIndex);
          }
        }
        else
        {
          password[passwordIndex]=new String (passwordField.getText ());
          if (!password[passwordIndex].equals (""))
          {
            privateKey[passwordIndex]=caPrivateKey[passwordIndex].decrypt (password[passwordIndex]);
            urlChoice.remove (passwordIndex);
            urlChoice.insert (caURL[passwordIndex]+" *",passwordIndex);
            passwordIndex++;
          }
          else
          {
            privateKey[passwordIndex]=null;
            urlChoice.remove (passwordIndex);
            urlChoice.insert (caURL[passwordIndex]+"  ",passwordIndex);
          }
        }
        if (passwordIndex>=urlChoice.getItemCount ()) passwordIndex=0;
        urlChoice.select (passwordIndex);
        passwordField.setText ("");
      }
    }
    userFile=userFileField.getText ();
    logFile=logFileField.getText ();
    htmlError=htmlField.getText ();
    tccPort=Integer.parseInt (tccPortField.getText ());
    irPort=Integer.parseInt (irPortField.getText ());
    log=Integer.parseInt (logField.getText ());
    secretLength=Integer.parseInt (secretField.getText ());
    return get;
  }

  public void configureServer (int opt)
  {
    Group c=new Group (Group.VERTICAL);
    Label l=new Label ();
    l.setAlignment (Label.CENTER);
    c.add (l);
    Button b=new Button ("Aceptar");
    c.add (b,Group.C);
    ApplicationFrame af=new ApplicationFrame ("Se produjo un error",c);
    af.center ();
    try
    {
      PrintWriter writer;
      DataInputStream reader;
      SSLSocket socket;
      SSLClientContext context=new SSLClientContext ();
      if (connectPKCS12==null)
      {
        l.setText ("Error no esta definida la clave de conexion.");
        l.invalidate ();
        af.pack ();
        af.setVisible (true);
        for (;;) if (b.equals (af.eventWait ().getSource ())) break;
        af.setVisible (false);
        return;
      }
      connectPKCS12.decrypt (connectPassword);
      PrivateKeyInfo pki=connectPKCS12.getPrivateKey ();
      X509Certificate cert[]=connectPKCS12.getCertificateChain ();
      TCCTrustDecider trustDecider=new TCCTrustDecider (pki,cert,connectPKCS12.getCertificateIssuer ());
      context.setTrustDecider (trustDecider);
      String line;
      socket=new SSLSocket (connectHost,connectPort,context);
      reader=new DataInputStream (socket.getInputStream ());
      writer=new PrintWriter (socket.getOutputStream ());
      if (opt==STOP)
        writer.println ("STOP");
      else
        writer.println ("CONFIG\n"+serverCFG ());
      writer.flush ();
      writer.close ();
      reader.close ();
      socket.close ();
    }
    catch (UnknownHostException e)
    {
      l.setText ("Error maquina Remota desconocida.");
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (IOException e)
    {
      l.setText ("Error de Lectura/Escritura en la conexion Remota. Revise la maquina y el puerto de conexion.");
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (NoSuchAlgorithmException e)
    {
      l.setText ("Error descifrando la clave el algoritmo utilizado no esta disponible.");
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }    
    catch (GeneralSecurityException e)
    {
      l.setText ("Error descifrando la clave escriba el password correctamente.");
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (Exception e)
    {
      l.setText (e.toString ());
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }

  }

  public void runServer ()
  {
    Group c=new Group (Group.VERTICAL);
    Label l=new Label ();
    l.setAlignment (Label.CENTER);
    c.add (l);
    Button b=new Button ("Aceptar");
    c.add (b,Group.C);
    ApplicationFrame af=new ApplicationFrame ("Aviso",c);
    af.center ();
    int i;
    applicationFrame.setVisible (true);
    for (;;)
    {
      try
      {
        i=windowGet ();
        if (i==RUN)
        {
          Runtime r=Runtime.getRuntime ();
          Process p=r.exec ("java TCServer");
          OutputStream os=p.getOutputStream ();
          InputStream is=p.getInputStream ();
          os.write (serverCFG ().getBytes ());
          os.flush ();
          if (is.read ()=='+')
            l.setText ("Servidor lanzado.");
          else
            l.setText ("No pudo lanzarse el servidor.");
          l.invalidate ();
          af.pack ();
          applicationFrame.setEnabled (false);
          af.setVisible (true);
          for (;;) if (b.equals (af.eventWait ().getSource ())) break;
          af.setVisible (false);
        }
        else if (i==RECONFIG || i==STOP)
        {
          configureServer (i);
        }
        else if (i==EXIT)
          System.exit (0);
      }
      catch (NumberFormatException e)
      {
        l.setText ("Numero mal escrito. Escribalo bien.");
        l.invalidate ();
        af.pack ();
        applicationFrame.setEnabled (false);
        af.setVisible (true);
        for (;;) if (b.equals (af.eventWait ().getSource ())) break;
        af.setVisible (false);
      }
      catch (GeneralSecurityException e)
      {
        l.setText ("Error descifrando la Clave para "+getPasswordUrl ()+". Escriba el password correctamente.");
        l.invalidate ();
        af.pack ();
        applicationFrame.setEnabled (false);
        af.setVisible (true);
        for (;;) if (b.equals (af.eventWait ().getSource ())) break;
        af.setVisible (false);
      }
      catch (Exception e)
      {
        l.setText (e.toString ());
        l.invalidate ();
        af.pack ();
        applicationFrame.setEnabled (false);
        af.setVisible (true);
        for (;;) if (b.equals (af.eventWait ().getSource ())) break;
        af.setVisible (false);
      }
      applicationFrame.setEnabled (true);
    }
  }

  public String serverCFG () throws PKCSException,CodingException
  {
    StringBuffer sb=new StringBuffer ("");
    sb.append ("TCCPORT "+tccPort+"\n");
    sb.append ("IRPORT "+irPort+"\n");
    sb.append ("TIMEOUT "+timeOut+"\n");
    sb.append ("SOTIMEOUT "+soTimeOut+"\n");
    sb.append ("SECRETLENGTH "+secretLength+"\n");
    sb.append ("LOG "+log+"\n");
    sb.append ("LOGFILE "+logFile+"\n");
    sb.append ("HTMLERROR "+htmlError+"\n");
    sb.append ("USERFILE "+userFile+"\n");
    CicaP12 cp12;
    for (int i=0;i<caName.length;i++)
    {
      if (privateKey[i]!=null)
      {
        sb.append ("ISSUER "+caURL[i]+" ");
        sb.append (caName[i]+"\n");
        sb.append (CicaP12.startLine+"\n");
        cp12=new CicaP12 (privateKey[i]);
        sb.append (new String (Util.Base64Encode (cp12.toByteArray ()))+"\n");
        sb.append (CicaP12.endLine+"\n");
      }
    }
    if (controlPrivateKey!=null)
    {
      cp12=new CicaP12 (controlPrivateKey,controlPKCS12.getCertificateChain (),controlPKCS12.getCertificateIssuer ());
      sb.append ("TCSC\n");
      sb.append (CicaP12.startLine+"\n");
      sb.append (new String (Util.Base64Encode (cp12.toByteArray ())));
      sb.append ("\n"+CicaP12.endLine+"\n");
    }
    sb.append ("END\n");
    return sb.toString ();
  }

  public static void main (String arg[])
  {
    Group c=new Group (Group.VERTICAL);
    Label l=new Label ();
    l.setAlignment (Label.CENTER);
    c.add (l);
    Button b=new Button ("Aceptar");
    c.add (b,Group.C);
    ApplicationFrame af=new ApplicationFrame ("Se produjo un error",c);
    af.center ();
    String file;
    if (arg==null || arg.length==0)
      file="server.cfg";
    else
      file=arg[0];

    try
    {
      Provider providerIAIK=new IAIK ();
      Security.addProvider (providerIAIK);
      TCFrame tcf=new TCFrame ();
      FileInputStream f;
      f=new FileInputStream (file);
      tcf.config (f);
      tcf.windowInit ();
      tcf.runServer ();
    }
    catch (FileNotFoundException e)
    {
      l.setText ("Fichero "+file+" de configuracion no encontrado.");
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (IOException e)
    {
      l.setText ("Error de lectura del fichero de configuracion"+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (CodingException e)
    {
      l.setText ("Nombre Distinguido no valido en el fichero de configuracion "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (InvalidKeyException e)
    {
      l.setText ("Clave no valida en el fichero de configuracion "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (NoSuchAlgorithmException e)
    {
      l.setText ("Clave no valida en el fichero de configuracion "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }    
    catch (GeneralSecurityException e)
    {
      l.setText ("Clave no valida en el fichero de configuracion "+file);
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (NullPointerException e)
    {
      l.setText ("Error de formato en el fichero de configuracion.");
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (Exception e)
    {
      l.setText (e.toString ());
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    System.exit (0);
  }
}
