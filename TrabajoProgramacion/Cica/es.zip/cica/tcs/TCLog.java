package es.cica.tcs;

import java.io.*;
import java.text.*;
import java.util.*;

public class TCLog
{
  private PrintWriter file;

  public TCLog ()
  {
    file=new PrintWriter (System.out);
  }

  public TCLog (String f) throws IOException
  {
    file=new PrintWriter (new FileOutputStream (f,true));
  }

  public void setFile (PrintWriter f)
  {
    file=f;
  }

  public synchronized void println (Object obj)
  {
    println (obj.toString ());
  }

  public synchronized void println (String s)
  {
    SimpleDateFormat df=new SimpleDateFormat ("dd/MM/yyyy HH:mm:ss");
    df.setTimeZone (TimeZone.getTimeZone("GMT"));
    Date dmime=new Date ();
    file.println (df.format (dmime)+" "+s);
    file.flush ();
  }
}
