package es.cica.tcs;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.StringTokenizer;
import java.util.Random;
import java.security.KeyPairGenerator;
import java.security.KeyPair;
import java.security.Security;
import java.security.NoSuchAlgorithmException;
import java.security.GeneralSecurityException;
import java.security.NoSuchProviderException;
import java.security.InvalidKeyException;
import java.security.Provider;
import java.security.cert.*;
import java.security.spec.*;

import iaik.security.ssl.*;
import iaik.security.provider.IAIK;
import iaik.asn1.*;
import iaik.asn1.structures.*;
import iaik.pkcs.*;
import iaik.pkcs.pkcs8.*;
import iaik.security.cipher.*;
import iaik.security.pbe.*;
import iaik.security.rsa.*;
import iaik.x509.*;
import iaik.x509.X509Certificate;
import iaik.utils.Util;

import javax.crypto.*;
import javax.crypto.spec.*;

import es.cica.tcs.util.*;
import es.cica.tcs.gui.*;

public class TCDB
{
  private final int
    NONE=0,
    USERDELETE=1,
    USERNEW=2,
    USERMODIFY=3,
    USERCONSULT=4,
    USERSEARCH=5,
    LABEL=6,
    USERRESEARCH=7;
  private static final String buttonLabel[]=
  {
    "Nada",
    "Borrar",
    "Alta",
    "Modificar",
    "Consultar",
    "Buscar",
    "XXXXXXXXX"
  };
  private DataBaseInterface dbFile=new RegDirDataBase();
  private int
    secretLength=32,
    searchIndex=0,
    rsaLength=1024,
    controlPort[],
    time[],
    atcsPort[],
    airPort[];
  private String
    password,
    localUrl,
    userFile,
    cfgFile,
    atcsName[],
    atcsAlias[],
    aurlAlias[],
    aurl[];
  private Name nameSearch;
  private CicaP12 connectPKCS12;
  private TextField
    dbPasswordField,
    cfgField,
    tcsField,
    tcsPortField,
    urlField,
    timeField,
    dbField,
    passwordField,
    confirmField,
    rsaField,
    localField;
  private TextArea userField;
  private Button dbButton,cfgButton,acceptButton,cancelButton;
  private Checkbox saveKeyCheckbox;
  private Choice tcsChoice,urlChoice;
  private ApplicationFrame applicationFrame;
  private MenuItem 
    userNew,
    menuExit,
    userDelete,
    userModify,
    userConsult,
    userSearch;

  public void windowInit () throws PKCSException,NoSuchAlgorithmException,GeneralSecurityException,IOException
  {
    int i;

    dbField=new TextField (userFile,20);
    dbButton=new Button ("Explorar...");
    new FileBrowser ("Base de Datos de Usuarios",dbButton,dbField);
    dbPasswordField=new TextField (20);
    dbPasswordField.setEchoChar ('*');
    Group c=new Group (Group.VERTICAL);
    Group c0=new Group (Group.HORIZONTAL);
    Group c1=new Group (Group.HORIZONTAL);
    c0.add (new Label ("DB Password"),Group.W);
    c0.add (dbPasswordField,Group.H);
    c1.add (new Label ("DB Local"),Group.W);
    c1.add (dbButton,Group.C);
    c1.add (dbField,Group.H);
    c.add (c0);
    c.add (c1);
    applicationFrame=new ApplicationFrame ("Base de Datos del TCS",c);
    applicationFrame.center ();
    applicationFrame.setVisible (true);
    Object o;
    AWTEvent evt;
    for (;;)
    {
      evt=applicationFrame.eventWait ();
      if (evt.getID ()==WindowEvent.WINDOW_CLOSING) System.exit (0);
      o=evt.getSource ();
      if (o.equals (dbPasswordField))
      {
        applicationFrame.setVisible (false);
        password=dbPasswordField.getText ();
//        connectPKCS12.decrypt (password);
        dbFile.open(dbField.getText());
        break;
      }
    }
    cfgField=new TextField (cfgFile,20);
    cfgButton=new Button ("Explorar...");
    new FileBrowser ("Fichero de Configuracion",cfgButton,cfgField);
    tcsChoice=new Choice ();
    for (i=0;i<atcsAlias.length;i++) tcsChoice.add (atcsAlias[i]);
    tcsField=new TextField (atcsName[0],20);
    tcsPortField=new TextField (""+controlPort[0],6);
    urlChoice=new Choice ();
    time=new int[aurlAlias.length];
    for (i=0;i<aurlAlias.length;i++)
    {
      time[i]=0;
      urlChoice.add (aurlAlias[i]+"  ");
    }
    urlField=new TextField (aurl[0],20);
    timeField=new TextField (""+time[0],4);
    userField=new TextArea (4,40);
    passwordField=new TextField (20);
    passwordField.setEchoChar ('*');
    confirmField=new TextField (20);
    confirmField.setEchoChar ('*');
    rsaField=new TextField (""+rsaLength,6);
    localField=new TextField (localUrl,10);
    saveKeyCheckbox=new Checkbox ();
    acceptButton=new Button (buttonLabel[LABEL]);
    cancelButton=new Button ("Cancelar");

    c=new Group (Group.VERTICAL);
    c0=new Group (Group.HORIZONTAL);
    c1=new Group (Group.HORIZONTAL);
    Group c2=new Group (Group.HORIZONTAL);
    Group c3=new Group (Group.HORIZONTAL);
    Group c4=new Group (Group.HORIZONTAL);
    Group c5=new Group (Group.HORIZONTAL);

    c0.add (new Label ("TCS"),Group.W);
    c0.add (tcsChoice,Group.C);
    c0.add (tcsField,Group.H);
    c0.add (tcsPortField,Group.C);

    c1.add (new Label ("Configuracion"),Group.W);
    c1.add (cfgField,Group.H);
    c1.add (cfgButton,Group.E);
    c1.add (new Label ("RSA"),Group.C);
    c1.add (rsaField,Group.C);
    c1.add (new Label ("Guardar Passwords"),Group.E);
    c1.add (saveKeyCheckbox,Group.W);

    c2.add (new Label ("DN de usuario"),Group.W);
    c2.add (userField,Group.ALL);

    c3.add (new Label ("Servicio"),Group.W);
    c3.add (urlChoice,Group.E);
    c3.add (urlField,Group.H);
    c3.add (new Label ("Minutos"),Group.C);
    c3.add (timeField,Group.W);
    c3.add (new Label ("Prefijo URL local"),Group.C);
    c3.add (localField,Group.C);

    c4.add (new Label ("Password"),Group.W);
    c4.add (passwordField,Group.H);
    c4.add (new Label ("Confirmacion"),Group.W);
    c4.add (confirmField,Group.H);

    c5.add (acceptButton,Group.W);
    c5.add (cancelButton,Group.E);

    c.add (c0);
    c.add (c2);
    c.add (c3);
    c.add (c1);
    c.add (c4);
    c.add (c5);

    Group m=new Group (Group.MENU);
    userNew=new MenuItem ("Alta");
    userModify=new MenuItem ("Modificacion");
    userDelete=new MenuItem ("Baja");
    userConsult=new MenuItem ("Consulta");
    userSearch=new MenuItem ("Busqueda");
    menuExit=new MenuItem ("Salir");
    Group m1=new Group ("Accion",Group.MENU);
    m1.add (userNew);
    m1.add (userDelete);
    m1.add (userModify);
    m1.add (userConsult);
    m1.add (userSearch);
    m1.add (menuExit);
    m.add (m1);

    applicationFrame=new ApplicationFrame ("Base de Datos del TCS",c,m);
    applicationFrame.center ();
  }

  public void windowGet ()
    throws
      PKCSException,
      GeneralSecurityException,
      NoSuchAlgorithmException,
      NumberFormatException,
      IOException,
      CodingException,
      NoSuchProviderException,
      InvalidKeyException
  {
    applicationFrame.setVisible (true);
    acceptButton.setLabel (buttonLabel[NONE]);
    AWTEvent event;
    Object o;
    int index,opt=NONE;
    Name name;

    userField.setEnabled (false);
    urlField.setEnabled (false);
    timeField.setEnabled (false);
    passwordField.setEnabled (false);
    confirmField.setEnabled (false);
    rsaField.setEnabled (false);
    localField.setEnabled (false);
    acceptButton.setEnabled (false);
    cancelButton.setEnabled (false);
    urlChoice.setEnabled (false);

    for (;;)
    {
      event=applicationFrame.eventWait ();
      if (event.getID ()==WindowEvent.WINDOW_CLOSING) System.exit (0);
      o=event.getSource ();
      if (o.equals (menuExit)) System.exit (0);
      if (o.equals (urlChoice))
      {
        index=urlChoice.getSelectedIndex ();
        urlField.setText (aurl[index]);
        timeField.setText (""+time[index]);
      }
      else if (o.equals (timeField))
      {
        String s=timeField.getText ();
        index=urlChoice.getSelectedIndex ();
        if (s.equals ("") || s.equals ("0"))
        {
          time[index]=0;
          urlChoice.remove (index);
          urlChoice.insert (aurlAlias[index]+"  ",index);
        }
        else
        {
          time[index]=Integer.parseInt (s);
          urlChoice.remove (index);
          urlChoice.insert (aurlAlias[index]+" *",index);
        }
      }
      else if (o.equals (tcsChoice))
      {
        tcsField.setText (atcsName[tcsChoice.getSelectedIndex ()]);
        tcsPortField.setText (""+controlPort[tcsChoice.getSelectedIndex ()]);
      }
      else if (o.equals (dbPasswordField))
      {
        password=dbPasswordField.getText ();
        connectPKCS12.decrypt (password);
        dbPasswordField.setEnabled (false);
      }
      else if (o.equals (dbField))
      {
        dbFile.open(dbField.getText());
        dbField.setEnabled (false);
        dbButton.setEnabled (false);
      }
      else if (o.equals (userDelete))
      {
        opt=USERDELETE;
        acceptButton.setLabel (buttonLabel[opt]);
        acceptButton.invalidate ();
        userNew.setEnabled (false);
        userDelete.setEnabled (false);
        userModify.setEnabled (false);
        userConsult.setEnabled (false);
        userSearch.setEnabled (false);
        userField.setEnabled (true);
        acceptButton.setEnabled (true);
        cancelButton.setEnabled (true);
      }
      else if (o.equals (userSearch))
      {
        opt=USERSEARCH;
        acceptButton.setLabel (buttonLabel[opt]);
        acceptButton.invalidate ();
        userNew.setEnabled (false);
        userDelete.setEnabled (false);
        userModify.setEnabled (false);
        userConsult.setEnabled (false);
        userSearch.setEnabled (false);
        userField.setEnabled (true);
        acceptButton.setEnabled (true);
        cancelButton.setEnabled (true);
      }
      else if (o.equals (userNew))
      {
        opt=USERNEW;
        acceptButton.setLabel (buttonLabel[opt]);
        acceptButton.invalidate ();
        userNew.setEnabled (false);
        userDelete.setEnabled (false);
        userModify.setEnabled (false);
        userConsult.setEnabled (false);
        userSearch.setEnabled (false);
        userField.setText ("");
        userField.setEnabled (true);
        urlField.setEnabled (true);
        timeField.setEnabled (true);
        timeField.setText ("0");
        for (int i=0;i<aurlAlias.length;i++)
        {
          time[i]=0;
          urlChoice.remove (i);
          urlChoice.insert (aurlAlias[i]+"  ",i);
        }
        passwordField.setEnabled (true);
        confirmField.setEnabled (true);
        rsaField.setEnabled (true);
        localField.setEnabled (true);
        acceptButton.setEnabled (true);
        cancelButton.setEnabled (true);
        urlChoice.setEnabled (true);
      }
      else if (o.equals (userModify))
      {
        opt=USERMODIFY;
        acceptButton.setLabel (buttonLabel[opt]);
        acceptButton.invalidate ();
        userNew.setEnabled (false);
        userDelete.setEnabled (false);
        userModify.setEnabled (false);
        userConsult.setEnabled (false);
        userSearch.setEnabled (false);
        userField.setEnabled (true);
        urlField.setEnabled (true);
        timeField.setEnabled (true);
        passwordField.setEnabled (true);
        confirmField.setEnabled (true);
        rsaField.setEnabled (true);
        localField.setEnabled (true);
        acceptButton.setEnabled (true);
        cancelButton.setEnabled (true);
        urlChoice.setEnabled (true);
      }
      else if (o.equals (userConsult))
      {
        opt=USERCONSULT;
        acceptButton.setLabel (buttonLabel[opt]);
        acceptButton.invalidate ();
        userNew.setEnabled (false);
        userDelete.setEnabled (false);
        userModify.setEnabled (false);
        userConsult.setEnabled (false);
        userSearch.setEnabled (false);
        userField.setEnabled (true);
        acceptButton.setEnabled (true);
        cancelButton.setEnabled (true);
      }
      else if (o.equals (cancelButton))
      {
        opt=NONE;
        userField.setEnabled (false);
        urlField.setEnabled (false);
        timeField.setEnabled (false);
        passwordField.setEnabled (false);
        confirmField.setEnabled (false);
        rsaField.setEnabled (false);
        localField.setEnabled (false);
        acceptButton.setEnabled (false);
        cancelButton.setEnabled (false);
        urlChoice.setEnabled (false);
        userNew.setEnabled (true);
        userDelete.setEnabled (true);
        userModify.setEnabled (true);
        userConsult.setEnabled (true);
        userSearch.setEnabled (true);
      }
      else if (o.equals (acceptButton))
      {
        if (opt==USERSEARCH || opt==USERRESEARCH) {
          if (opt==USERSEARCH) {
            nameSearch=TCUtil.toName (userField.getText ());
          }
          opt=USERRESEARCH;
          for (;;) {
            RegDirectorio aux=dbFile.search (searchIndex);
            if (aux==null) {
              searchIndex=0;
              break;
            } else {
              name=aux.getName();
              searchIndex++;
              if (TCUtil.similar (name,nameSearch)) {
                userField.setText (name.toString ());
                break;
              }
            }
          }
        } else if (opt==USERMODIFY || opt==USERNEW) {
          name=TCUtil.toName (userField.getText ());
          RegDirectorio rd=dbFile.search(name);
          if (opt==USERMODIFY) {
            if (rd==null) {
               mensaje("Usuario no encontrador: "+userField.getText());
               continue;
            }
            dbFile.delete (name);
          }
          if (rd==null) {
             rd=new RegDirectorio();
             rd.setName(name);
          }   

          if (passwordField.getText ().equals (confirmField.getText ())) {
            applicationFrame.setEnabled (false);
            KeyPairGenerator generator=KeyPairGenerator.getInstance ("RSA","IAIK");
            generator.initialize (Integer.parseInt (rsaField.getText ()));
            KeyPair kp=generator.generateKeyPair ();
            rd.setPublicKey((PublicKeyInfo)kp.getPublic ());
            EncryptedPrivateKeyInfo epk=new EncryptedPrivateKeyInfo ((PrivateKeyInfo)kp.getPrivate ());
            epk.encrypt(passwordField.getText (),AlgorithmID.pbeWithSHAAnd40BitRC2_CBC,null);
            rd.setPrivateKey(epk);
            if (saveKeyCheckbox.getState ()) {
              Random random = new Random();
              byte[] salt = new byte[16];
              random.nextBytes(salt);
              PBEParameterSpec pbeParamSpec=new PBEParameterSpec (salt,1);
              PBEKeyBMP pbeKey=new PBEKeyBMP (password);
              Cipher pbeCipher=Cipher.getInstance ("PbeWithSHAAnd40BitRC2_CBC");
              pbeCipher.init (Cipher.ENCRYPT_MODE,pbeKey,pbeParamSpec);
              rd.setPassword(pbeCipher.doFinal (passwordField.getText ().getBytes ()));
            }
            dbFile.insert(rd);
            applicationFrame.setEnabled (true);
            rd.setTime(time);
            rd.setUrl(aurl);
            FileOutputStream f=new FileOutputStream (cfgField.getText ());
            for (int i=0;i<atcsName.length;i++) {
              f.write (("TCSERVER "+atcsName[i]+":"+atcsPort[i]+":"+airPort[i]+" "+atcsAlias[i]+"\n").getBytes ());
            }
            for (int i=0;i<aurl.length;i++) {
              if (time[i]!=0) {
                f.write (("URL "+aurl[i]+" "+aurlAlias[i]+"\n").getBytes ());
              }
            }
            f.write (("SECRETLENGTH "+(Integer.parseInt (rsaField.getText ())/32)+"\n").getBytes ());
            f.write (("LOCALURL "+localField.getText ()+"\n").getBytes ());
            int max=0x7fffffff;
            for (int i=0;i<time.length;i++)
              if (time[i]!=0 && time[i]<max) max=time[i];
            f.write (("TIME "+max+"\n").getBytes ());
            f.write (("USER "+name.toString ()+"\n").getBytes ());
            CicaP12 cp12=new CicaP12 (rd.getPrivateKey());
            f.write ((CicaP12.startLine+"\n").getBytes ());
            f.write (Util.Base64Encode (cp12.toByteArray ()));
            f.write (("\n"+CicaP12.endLine+"\n").getBytes ());
            f.write (("END\n").getBytes ());
            f.close ();
            opt=NONE;
            userField.setEnabled (false);
            urlField.setEnabled (false);
            timeField.setEnabled (false);
            passwordField.setEnabled (false);
            confirmField.setEnabled (false);
            rsaField.setEnabled (false);
            localField.setEnabled (false);
            acceptButton.setEnabled (false);
            cancelButton.setEnabled (false);
            urlChoice.setEnabled (false);
            userNew.setEnabled (true);
            userDelete.setEnabled (true);
            userModify.setEnabled (true);
            userConsult.setEnabled (true);
            userSearch.setEnabled (true);
          }
        }
        else if (opt==USERDELETE)
        {
          name=TCUtil.toName (userField.getText ());
          dbFile.delete (name);
          opt=NONE;
          userField.setEnabled (false);
          urlField.setEnabled (false);
          timeField.setEnabled (false);
          passwordField.setEnabled (false);
          confirmField.setEnabled (false);
          rsaField.setEnabled (false);
          localField.setEnabled (false);
          acceptButton.setEnabled (false);
          cancelButton.setEnabled (false);
          urlChoice.setEnabled (false);
          userNew.setEnabled (true);
          userDelete.setEnabled (true);
          userModify.setEnabled (true);
          userConsult.setEnabled (true);
          userSearch.setEnabled (true);
        }
        else if (opt==USERCONSULT)
        {
          String usrField=userField.getText();
          RegDirectorio rd=null;

          rd=dbFile.search(TCUtil.toName(userField.getText()));
          if (rd==null) {
             mensaje("Usuario no encontrado: "+userField.getText());
          }
          if (rd!=null) {
             userField.setText(rd.getName().toString());
             int [] timeAux=rd.getTime();
             String [] urlAux=rd.getUrl();
             for(int i=0; i<timeAux.length; i++) {
                for(int j=0; j<aurl.length; j++) {
                   if(aurl[j].equals(urlAux[i])) {
                     urlChoice.remove (i);
                     urlChoice.insert (aurlAlias[i]+" *",i);
                     if (i==urlChoice.getSelectedIndex ()) {
                        timeField.setText (""+timeAux[i]);
                     }
                     break;
                   }
                }
             }
          }
        }
      }
    }
  }

/*  public String tcsConsult (String host,int port,String param)
  {
    Group c=new Group (Group.VERTICAL);
    Label l=new Label ();
    l.setAlignment (Label.CENTER);
    c.add (l);
    Button b=new Button ("Aceptar");
    c.add (b,Group.C);
    ApplicationFrame af=new ApplicationFrame ("Se produjo un error",c);
    af.center ();
    StringBuffer rs=new StringBuffer ("");
    String line;
    try
    {
      PrintWriter writer;
      BufferedReader reader;
      SSLSocket socket;
      SSLClientContext context=new SSLClientContext ();
      if (connectPKCS12==null)
      {
        l.setText ("Error no esta definida la clave de conexion.");
        l.invalidate ();
        af.pack ();
        af.setVisible (true);
        for (;;) if (b.equals (af.eventWait ().getSource ())) break;
        af.setVisible (false);
        return null;
      }
      PrivateKeyInfo pki=connectPKCS12.getPrivateKey ();
      X509Certificate cert[]=connectPKCS12.getCertificateChain ();
      TCCTrustDecider trustDecider=new TCCTrustDecider (pki,cert,connectPKCS12.getCertificateIssuer ());
      context.setTrustDecider (trustDecider);
      socket=new SSLSocket (host,port,context);
      reader=new BufferedReader (new InputStreamReader (socket.getInputStream ()));
      writer=new PrintWriter (socket.getOutputStream ());
      writer.println (param);
      writer.flush ();
      for (;;)
      {
        line=reader.readLine ();
        if (line==null || line.startsWith ("-ERR")) break;
        else if (line==null || line.startsWith ("+OK")) break;
        rs.append (line+"\n");
      }
      writer.close ();
      reader.close ();
      socket.close ();
    }
    catch (UnknownHostException e)
    {
      l.setText ("Error maquina Remota desconocida.");
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (IOException e)
    {
      l.setText ("Error de Lectura/Escritura en la conexion Remota. Revise la maquina y el puerto de conexion.");
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    catch (Exception e)
    {
      l.setText (e.toString ());
      l.invalidate ();
      af.pack ();
      af.setVisible (true);
      for (;;) if (b.equals (af.eventWait ().getSource ())) break;
      af.setVisible (false);
    }
    return rs.toString ();
  }*/

  public void config (InputStream fin)
    throws
      IOException,
      PKCSException,
      CodingException,
      InvalidKeyException,
      NumberFormatException,
      GeneralSecurityException,
      NoSuchAlgorithmException,
      Exception
  {
    BufferedReader br=new BufferedReader (new InputStreamReader (fin));
    String line,var,alias;
    StringTokenizer st;
    while ((line=br.readLine ())!=null)
    {
      if (line.startsWith ("#")) continue;
      st=new StringTokenizer (line," \t\r");
      if (!st.hasMoreTokens ()) continue;
      var=st.nextToken ();
      if (var.equals ("END")) break;
      else if (var.equals ("DATABASE")) userFile=st.nextToken ();
      else if (var.equals ("CFGFILE")) cfgFile=st.nextToken ();
      else if (var.equals ("LOCALURL")) localUrl=st.nextToken ();
      else if (var.equals ("RSALENGTH")) rsaLength=Integer.parseInt (st.nextToken ());
      else if (var.equals ("TCSCREMOTE"))
        readTcsc (br);
      else if (var.equals ("TCSERVER"))
      {
        var=st.nextToken ();
        StringTokenizer sta=new StringTokenizer (var,":");
        if (st.hasMoreTokens ())
          alias=st.nextToken ();
        else
          alias=null;
        tcsAppend (sta.nextToken (),Integer.parseInt (sta.nextToken ()),Integer.parseInt (sta.nextToken ()),Integer.parseInt (sta.nextToken ()),alias);
      }
      else if (var.equals ("URL"))
      {
        var=st.nextToken ();
        if (st.hasMoreTokens ())
          alias=st.nextToken ();
        else
          alias=null;
        urlAppend (var,alias);
      }
      else throw new Exception ("Error de formato. Linea erronea: "+line);
    }
  }

  public void urlAppend (String name,String alias)
  {
    if (alias==null) alias=name;
    if (aurl==null)
    {
      aurl=new String[1];
      aurlAlias=new String[1];
      aurl[0]=new String (name);
      aurlAlias[0]=new String (alias);
    }
    else
    {
      String auxUrl[]=new String[aurl.length+1];
      String auxAlias[]=new String[aurl.length+1];
      int i;
      for (i=0;i<aurl.length;i++)
      {
        auxUrl[i]=aurl[i];
        auxAlias[i]=aurlAlias[i];
      }
      auxUrl[i]=new String (name);
      auxAlias[i]=new String (alias);
      aurl=auxUrl;
      aurlAlias=auxAlias;
    }
  }

  public void tcsAppend (String name,int tcsp,int irp,int tccp,String alias)
  {
    if (alias==null) alias=name;
    if (atcsName==null)
    {
      atcsName=new String[1];
      controlPort=new int[1];
      atcsAlias=new String[1];
      airPort=new int[1];
      atcsPort=new int[1];
      atcsName[0]=new String (name);
      atcsAlias[0]=new String (alias);
      controlPort[0]=tccp;
      airPort[0]=irp;
      atcsPort[0]=tcsp;
    }
    else
    {
      String auxName[]=new String[atcsName.length+1];
      int auxT[]=new int[atcsName.length+1];
      int auxI[]=new int[atcsName.length+1];
      int auxS[]=new int[atcsName.length+1];
      String auxAlias[]=new String[atcsName.length+1];
      int i;
      for (i=0;i<atcsName.length;i++)
      {
        auxName[i]=atcsName[i];
        auxT[i]=controlPort[i];
        auxAlias[i]=atcsAlias[i];
        auxI[i]=airPort[i];
        auxS[i]=atcsPort[i];
      }
      auxName[i]=new String (name);
      auxT[i]=tccp;
      auxI[i]=irp;
      auxS[i]=tcsp;
      auxAlias[i]=new String (alias);
      atcsName=auxName;
      controlPort=auxT;
      airPort=auxI;
      atcsPort=auxS;
      atcsAlias=auxAlias;
    }
  }

  public void readTcsc (BufferedReader f)
    throws PKCSException,CodingException,InvalidKeyException,IOException,NoSuchAlgorithmException,GeneralSecurityException,ArrayIndexOutOfBoundsException
  {
    StringBuffer k=new StringBuffer ("");
    String line;
    for (;;)
    {
     line=f.readLine ();
     k.append (line+"\n");
     if (line.startsWith (CicaP12.endLine)) break;
    }
    connectPKCS12=new CicaP12 (k.toString ().getBytes ());
  }
//  static void mensaje(String m, Label l, ApplicationFrame af, Button b) {
   static void mensaje(String m) {
    Group c=new Group (Group.VERTICAL);
    Label l=new Label ();
    l.setAlignment (Label.CENTER);
    c.add (l);
    Button b=new Button ("Aceptar");
    c.add (b,Group.C);
    ApplicationFrame af=new ApplicationFrame ("Se produjo un error",c);
    af.center ();

     l.setText (m);
     l.invalidate ();
     af.pack ();
     af.setVisible (true);
     for (;;) if (b.equals (af.eventWait ().getSource ())) break;
     af.setVisible (false);
  }


  public static void main (String arg[])
  {
    String file;
    if (arg==null || arg.length==0) {
      file="db.cfg";
    } else {
      file=arg[0];
    }
    try {
      Provider providerIAIK=new IAIK ();
      Security.addProvider (providerIAIK);
      TCDB tc=new TCDB ();
      FileInputStream f;
      f=new FileInputStream (file);
      tc.config (f);
      tc.windowInit ();
      tc.windowGet ();
    } catch (FileNotFoundException e) {
      mensaje("Fichero "+file+" de configuraci�n no encontrado.");
    } catch (IOException e) {
      mensaje("Error de lectura del fichero de configuracion"+file);
    } catch (CodingException e) {
      mensaje("Nombre Distinguido no valido en el fichero de configuracion "+file);
    } catch (InvalidKeyException e) {
      mensaje("Clave no valida en el fichero de configuracion "+file);
    } catch (NoSuchAlgorithmException e) {
      mensaje("Clave no valida en el fichero de configuracion "+file);
    } catch (GeneralSecurityException e) {
      mensaje("Clave no valida en el fichero de configuracion "+file);
    } catch (NullPointerException e) {
      mensaje("Error de formato en el fichero de configuracion.");
    } catch (Exception e) {
      mensaje(e.toString ());
    }
    System.exit (0);
  }

}
