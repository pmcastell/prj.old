package es.cica.tcs;

import java.io.*;
import java.util.*;
import java.security.cert.CertificateException;

import iaik.asn1.*;
import iaik.asn1.structures.Name;
import iaik.security.rsa.RSAPublicKey;
import iaik.utils.*;

import es.cica.tcs.util.TCUtil;

public class TCDump
{
  public DataBase userFile;

  public TCDump (String file) throws IOException
  {
    userFile=new DataBase (file);
  }

  public void read () throws IOException,CodingException,CertificateException
  {
    UserInfo ui;
    Name name;
    for (int si = 0;; si++) {
      byte aux[][] = userFile.search (si);
      if (aux == null) break;
      name = new Name (aux [0]);
      ui = (UserInfo)CMem.toObject (aux[1]);
      System.out.println ("SUBJECT " + name);
      if (ui == null) System.out.println ("# No hay mas datos (error!))");
      else {
        System.out.println ("-----BEGIN PUBLICKEY-----");
        System.out.println (new String (Util.Base64Encode (ui.publicKey.getEncoded())));
        System.out.println ("-----END PUBLICKEY-----");
        for (int i = 0; i < ui.url.length; i++) {
          System.out.println ("URL " + ui.url[i] + " TIME " + ui.time[i]);
        }
      }
    }
    System.out.println ("END");
  }

  public static void main (String arg[])
  {
    TCDump tcd;
    try
    {
      if (arg.length == 0) tcd=new TCDump ("directorio.dat");
      else tcd=new TCDump (arg[0]);
      tcd.read ();
    }
    catch (Exception e)
    {
      System.out.println (e);
    }
  }
}
