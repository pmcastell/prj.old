
//Title:       Your Product Name
//Version:     
//Copyright:   Copyright (c) 1998
//Author:      Your Name
//Company:     Your Company
//Description: Your description
package es.cica.tcs;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import com.sun.java.swing.*;
import javax.swing.*;

//import com.sun.java.swing.UIManager;
public class Applet1 extends JApplet {
 boolean isStandalone = false;
 javax.swing.JButton jButton1 = new javax.swing.JButton();
//Get a parameter value
 
 public String getParameter(String key, String def) {
  return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
 }

 //Construct the applet
 
 public Applet1() {
 }
//Initialize the applet
 
 public void init() {
  try {
  jbInit();
  }
  catch (Exception e) {
  e.printStackTrace();
  }
 }
 //static { 
 //  try { 
 //    //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.metal.MetalLookAndFeel());
 //    //UIManager.setLookAndFeel(new com.sun.java.swing.plaf.motif.MotifLookAndFeel());
 //    UIManager.setLookAndFeel(new com.sun.java.swing.plaf.windows.WindowsLookAndFeel());
 //  }
 //  catch (Exception e) {}
 //}
//Component initialization
 
 private void jbInit() throws Exception {
  jButton1.setText("jButton1");
  jButton1.setBounds(new Rectangle(34, 22, 110, 30));
  jButton1.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(ActionEvent e) {
    jButton1_actionPerformed(e);
   }
  });
  this.getContentPane().setLayout(null);
  this.getContentPane().add(jButton1, null);
  this.setSize(400,300);
 }
//Start the applet
 
 public void start() {
 }
//Stop the applet
 
 public void stop() {
 }
//Destroy the applet
 
 public void destroy() {
 }
//Get Applet information
 
 public String getAppletInfo() {
  return "Applet Information";
 }
//Get parameter info
 
 public String[][] getParameterInfo() {
  return null;
 }
//Main method
 
 public static void main(String[] args) {
  Applet1 applet = new Applet1();
  applet.isStandalone = true;
  JFrame frame = new JFrame();
  frame.setTitle("Applet Frame");
  frame.getContentPane().add(applet, BorderLayout.CENTER);
  applet.init();
  applet.start();
  frame.setSize(400,320);
  Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
  frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
  frame.setVisible(true);
 }

 void jButton1_actionPerformed(ActionEvent e) {

 }
}

