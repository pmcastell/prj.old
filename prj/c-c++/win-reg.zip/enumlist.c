#include <windows.h>
#include <stdlib.h>
#include <string.h>

LRESULT CALLBACK WndProc (HWND hWnd, UINT uMsg, WPARAM wParam , LPARAM lParam) ;  

VOID FillList(HWND hWnd ) ;

int APIENTRY WinMain(HANDLE hInstance, HANDLE hPrevInstance, 
LPSTR lpszCmdLine, int nCmdShow)
   {
   char szClassName[] = "RegListbox" ;
   HWND hWnd ;
   MSG msg ;
   WNDCLASS wndclass ;

   // Define window class
   wndclass.style = CS_HREDRAW | CS_VREDRAW ;
   wndclass.lpfnWndProc = WndProc ;
   wndclass.cbClsExtra = 0 ;
   wndclass.cbWndExtra = 0 ;
   wndclass.hInstance = hInstance ;
   wndclass.hIcon = LoadIcon (NULL, IDI_APPLICATION) ;
   wndclass.hCursor = LoadCursor (NULL, IDC_ARROW) ;
   wndclass.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1) ;
   wndclass.lpszMenuName = NULL ;
   wndclass.lpszClassName = szClassName ;
   RegisterClass (&wndclass) ;
   // Create and display window
   hWnd = CreateWindow (szClassName, "Enumerating a Registry Key",
         WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
         CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL) ;
   ShowWindow (hWnd, nCmdShow) ;
   UpdateWindow (hWnd) ;
   // Message processing loop
   while (GetMessage (&msg, NULL, 0, 0))
      {
      TranslateMessage (&msg) ;
      DispatchMessage (&msg) ;
      }
   return msg.wParam ;
   }

// Message handler
LRESULT CALLBACK WndProc (HWND hWnd, UINT uMsg, WPARAM wParam , LPARAM lParam)
   {
   static HWND hWndLB ;
   RECT lpRect ;

   switch (uMsg)
      {
      case WM_CREATE:
         GetClientRect( hWnd, &lpRect ) ;
         // Create listbox
         hWndLB = CreateWindow("listbox", NULL,
               WS_CHILD | WS_VISIBLE | LBS_DISABLENOSCROLL | 
               LBS_SORT | LBS_STANDARD,
               (lpRect.right-lpRect.left)/3,
               (lpRect.bottom-lpRect.top)/5, 
               (lpRect.right-lpRect.left)/3,
               (lpRect.bottom-lpRect.top)/50*35,
               hWnd, (HMENU) 1, (HANDLE) GetWindowLong(hWnd, GWL_HINSTANCE), NULL) ;
         FillList(hWndLB) ;
         return 0 ;

      case WM_SETFOCUS:
         SetFocus (hWndLB) ;
            return 0 ;

      case WM_DESTROY:
         PostQuitMessage (0) ;
         return 0 ;
      }
   return DefWindowProc (hWnd, uMsg, wParam, lParam) ;
   }

