#include <windows.h>
#include <string.h>

int APIENTRY WinMain(HANDLE hInstance, HANDLE hPrevInstance, 
                     LPSTR lpszCmdLine, int nCmdShow)
   {
   int ch = '.', CharPos ;
   HKEY hKey ;
   LONG cbBuffer ;
   char lpAppID[50], lpPgmName[MAX_PATH], lpAppIDKey[MAX_PATH] ;
   char lpCmdEx[MAX_PATH], lpExten[10], *lpStrPtr, *lpRevStr ;
        
   // Test for no command line
   if (strlen(lpszCmdLine) == 0)
      {  
      MessageBox(NULL, "Syntax: OPENKYX1 <filename>", "OPENKYX1 Error", MB_OK) ;
      exit (0) ;
      }
   // reverse string to exclude "." character if part of path
   lpRevStr = _strrev(_strdup(lpszCmdLine)) ;
   // extract extension from reversed filename
   if (lpStrPtr = strchr(lpRevStr, ch))
      strcpy(lpExten, lpszCmdLine + (strlen(lpszCmdLine) - (lpStrPtr - lpRevStr)-1)) ;
   else
      {
      printf("The filename does not include a file extension.") ;
      exit (0) ;
      }
   // Determine if file extension is registered
   if (RegOpenKeyEx(HKEY_CLASSES_ROOT, lpExten, 0, KEY_READ, &hKey) 
          == ERROR_SUCCESS )
      {
      // Retrieve application identifier
      cbBuffer = sizeof(lpAppID) ;
      RegQueryValue(hKey, NULL, (LPTSTR)lpAppID, &cbBuffer) ;
      RegCloseKey(hKey) ;
      // Form subkey path
      strcpy(lpAppIDKey, lpAppID) ;
      strcat(lpAppIDKey, "\\shell\\open\\command") ;
      // Retrieve name of associated program
      if (RegOpenKeyEx(HKEY_CLASSES_ROOT, (LPCTSTR)lpAppIDKey, 0,
                       KEY_READ, &hKey) == ERROR_SUCCESS)
         {
         cbBuffer = sizeof(lpPgmName) ;
         RegQueryValue( hKey, NULL, (LPTSTR)lpPgmName, &cbBuffer ) ;
         RegCloseKey(hKey) ;
         // Replace first parameter to program 
         // todo: deal with %*
         CharPos = strcspn(lpPgmName,"%1") ;
         if (CharPos > 0)
            {
            strncpy(lpCmdEx, lpPgmName, CharPos - 1) ;
            strcat(lpCmdEx, " ") ;
            strcat(lpCmdEx, lpszCmdLine) ;
            }
         else
            strcpy( lpCmdEx, lpPgmName ) ;
         // Execute Program
         if (WinExec(lpCmdEx, SW_SHOWNORMAL ) < 32 )
            MessageBox(NULL, "Unable to launch associated program...",                                                
               lpPgmName,MB_OK) ; 
      }
      else
         MessageBox(NULL, 
                    "The file type is not associated with a particular program!", 
                    lpszCmdLine, MB_OK) ;
   }
   else
      {
      char szBuffer[50] ;
      sprintf(szBuffer, "Unregistered file extension: %s", lpExten) ;
      MessageBox(NULL, szBuffer, lpszCmdLine, MB_OK) ;
      }
   return 0 ;
   }

