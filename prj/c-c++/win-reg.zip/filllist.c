#include <windows.h>

VOID FillList(HWND hWnd)
   {
   HKEY hKey ;                         
   HANDLE hHeap ;
   DWORD dwIndex, dwBufSize, nSubkeys, nSubkeyNameLen ;
   LPTSTR lpBuffer ;
   // Open sound event labels key
   if (RegOpenKey(HKEY_CURRENT_USER,"AppEvents\\EventLabels", 
                  &hKey ) == ERROR_SUCCESS )
      {
      // Determine number of keys to enumerate
      RegQueryInfoKey(hKey, NULL, NULL, NULL, &nSubkeys, 
                      &nSubkeyNameLen, NULL, NULL, NULL,
                      NULL, NULL, NULL ) ;
      // Allocate memory
      hHeap = GetProcessHeap() ;
      lpBuffer = HeapAlloc(hHeap, 0, ++nSubkeyNameLen) ;
      
      // Retrieve Registry values
      for (dwIndex = 0 ; dwIndex < nSubkeys; dwIndex++)
         {
         dwBufSize = nSubkeyNameLen ;
         RegEnumKeyEx(hKey, dwIndex, lpBuffer, &dwBufSize, 
                      NULL, NULL, NULL, NULL) ;
         // Add sound event to list box
         SendMessage(hWnd, LB_ADDSTRING, 0, (LPARAM)(LPCTSTR) lpBuffer);
         }
      RegCloseKey(hKey) ;
      HeapFree(hHeap, 0, lpBuffer) ;
      }
   return ;
   }

