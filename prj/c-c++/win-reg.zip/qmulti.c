#include <windows.h>

int APIENTRY WinMain(HANDLE hInstance, HANDLE hPrevInstance, 
                     LPSTR lpszCmdLine, int nCmdShow)
   {
   unsigned int iCtr ;
   HKEY hKey ;
   HANDLE hHeap ;
   DWORD num_vals = 2, dwTotsize ;
   LPTSTR lpValueBuf ;
   VALENT pValueData[2] ;

   // Define value entries to query
   pValueData[0].ve_valuename = "AppWorkspace" ;
   pValueData[1].ve_valuename = "Background" ;

   // Open Registry key   
   if (RegOpenKey(HKEY_CURRENT_USER,"Control Panel\\Colors", &hKey ) 
                  == ERROR_SUCCESS)
      {
      // Determine size of buffer
      RegQueryMultipleValues(hKey, pValueData, num_vals, NULL, 
                             &dwTotsize) ; 
      // Allocate memory
      hHeap = GetProcessHeap() ;
      lpValueBuf = HeapAlloc(hHeap, 0, dwTotsize) ;
      // Retrieve Registry values
      RegQueryMultipleValues(hKey,pValueData,num_vals,lpValueBuf,
                           &dwTotsize) ;
      for ( iCtr = 0; iCtr <= 1; iCtr++ )
         MessageBox(NULL, (LPCTSTR) pValueData[iCtr].ve_valueptr, 
                    pValueData[iCtr].ve_valuename, MB_OK) ; 
      
      RegCloseKey(hKey) ;
      HeapFree(hHeap, 0, lpValueBuf) ;
      }  
   return 0 ;
   }

