
The file NTIS.ZIP file contains the following files:

README.TXT          A description of the contents of NTIS.ZIP

NTIS.PPT            The PowerPoint 95 presentation delivered at
                    Windows NT Intranet Solutions in Makuhari on
                    November 12.

REGPERF.C           Source code for an initialization file/registry
                    benchmark.  To compile from the command line:
                         cl regperf.c advapi32.lib

REGPERF.EXE         Compiled version of the .INI file/registry 
                    benchmark.

OPENKY1.C           Source code for a sample registry access program.
                    To compile from the command line:
                          cl openky1.c advapi32.lib user32.lib

OPENKY1.EXE         Compiled version of the sample registry access
                    program.  When the user enters "OPENKY1 <filename>"
                    at the command line, where <filename> is the complete
                    path and filename of a data file, including its
                    file extension, the program will launch the 
                    executable file associated with that file type,
                    which will in turn open the file.  For example,
                    the command
                           openky1 c:\documents\myfile.doc
                    causes Word to be launched and to open MYFILE.DOC.

FILLLIST.C          Source code for a second sample registry access
ENUMLIST.C          program -- in this case one which enumerates 
                    subkeys in order to build a list box containing 
                    the names of sound events.  Enumlist.c contains
                    the basic window initialization and message 
                    processing code, while Filllist.c contains the
                    code for accessing the registry.  To compile from
                    the command line:
                           cl enumlist.c filllist.c user32.lib advapi32.lib

ENUMLIST.EXE        The compiled version of the second example.

QMULTI.C            Source code for a sample program illustrating the
                    RegQueryMultipleValues API.  The program requires
                    that the key HKEY_CURRENT_USER\Control Panel\Colors
                    be present, and that it have at least two value 
                    entries, named AppWorkSpace and Background.  If 
                    these are not present in your registry (they are
                    not created by default), replace them with two
                    value entries belonging to some other registry
                    key.  To compile from the command line:
                          cl qmulti.c advapi32.lib user32.lib

QMULTI.EXE          The compiled version of the RegQueryMultipleValues
                    example.

CFGBACK.OUT         ApiSpy32's output when spying on the Configuration
                    Backup utility.  ApiSpy32 is being used only to 
                    spy on calls to the registry API.

REGEDIT.SPY         RegSpy95's output when spying on the initialization
                    of the Windows Registry Editor (REGEDIT.EXE).



