#include <windows.h>
#include <time.h>

int main(int argc, char *argv[])
   {
   int nCtr = 0 ;
   HKEY hKey ;
   DWORD dwValueLen ;
   char szKey[256], szValue[256] ;
   char szValueName[256] ;
   char *lpFilename = "c:\\windows\\test.ini" ;
   char *lpRegKey = "Software\\MyCompany\\TestApp" ;
   char *lpSection = "test" ;
   time_t tStart, tEnd ;

   // start timer
   time(&tStart) ;
   // write INI file 1000 entries
   for (nCtr = 0; nCtr < 1250; nCtr++)
      {
      sprintf(szKey, "Key%ld", nCtr) ;
      sprintf(szValue,"Value number %ld", nCtr) ;
      if (!WritePrivateProfileString( lpSection, szKey, szValue, lpFilename)) 
         printf("Error writing key %s.\n", szKey) ;
      }
   // read each entry of INI file
   for (nCtr = 0; nCtr < 1250; nCtr++)
      {
      sprintf(szKey, "Key%ld", nCtr) ;
      if (!GetPrivateProfileString(lpSection, "Key0", "", szValue,
                              sizeof(szValue), lpFilename))
         printf("Error reading key %s.\n", szKey) ;
      }
   time(&tEnd) ;
   printf("%ld seconds required to read and write 1,250 INI file values.\n", 
          tEnd - tStart) ;
   // begin registry counter
   time(&tStart) ;
   // open registry key
   if (RegCreateKey(HKEY_LOCAL_MACHINE, lpRegKey, &hKey) != ERROR_SUCCESS)
      {
      printf("Unable to create or open registry key!") ;
      return 0 ;
      }
   // Write 1000 entries
   for (nCtr = 0; nCtr < 1250; nCtr++)
      {
      sprintf(szValueName, "Named Value %ld", nCtr) ;
      sprintf(szValue,"Value number %ld", nCtr) ;
      if (RegSetValueEx(hKey, szValueName, 0, REG_SZ, (LPBYTE) szValue, 
                        strlen(szValue)) != ERROR_SUCCESS)
        {
        printf("Unable to write value %s.", szValueName) ;
        return 0 ;
        }
      }
   // read 1000 entries
   for (nCtr = 0; nCtr < 1250; nCtr++)
      {
      dwValueLen = sizeof(szValue) ;
      sprintf(szValueName, "Named Value %ld", nCtr) ;
      if (RegQueryValueEx(hKey, szValueName, 0, NULL, szValue,
                         &dwValueLen) != ERROR_SUCCESS)
         printf("Unable to read value %s.", szValueName) ;
      }      
   RegCloseKey(hKey) ;
   time(&tEnd) ;
   printf("%ld seconds required to retrieve 1,250 registry values.\n", 
          tEnd - tStart) ;

   return 0 ;
   }

