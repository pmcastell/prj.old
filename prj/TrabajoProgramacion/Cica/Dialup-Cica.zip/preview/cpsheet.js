//TAGS FOR COMMUNICATOR PREVIEW SCREENS

//tags.BODY.fontFamily="PrimaSans BT, Helvetica,Arial";
//tags.BODY.fontSize="12px";
//tags.BODY.textAlign="left";
//tags.BODY.color="black";
//tags.BODY.marginTop="0";
//tags.BODY.marginBottom="0";
//tags.BODY.marginLeft="72";
//tags.BODY.borderWidths(0, 0, 0, 0);
//tags.BODY.paddings(0, 0, 0, 0);

document.tags.P.fontFamily="PrimaSans BT, Helvetica,Arial";
document.tags.P.fontSize="12px";
document.tags.P.lineHeight="1.2";
document.tags.P.margins(14,40,0,330);


//Titles of Communicator Preview screens

document.classes.title.all.fontSize="23px";
document.classes.title.all.fontFamily="PrimaSans BT, Helvetica,Arial";
document.classes.title.all.margins(34,0,0,43);


//Tables (for forms inputs, etc.)

document.tags.TABLE.marginTop="14";
document.tags.TABLE.fontFamily="PrimaSans BT, Helvetica,Arial";
document.tags.TABLE.fontSize="12px";
//tags.P.lineHeight="1.2";
//tags.P.margins(14,40,0,330);

document.tags.TD.fontFamily="PrimaSans BT, Helvetica,Arial";
document.tags.TD.fontSize="11px";
//tags.TD.lineHeight="1.2"

document.classes.intro.TD.fontSize="12px";

//the entries below are exceptions to the standard definition

document.ids.nospace.marginTop="0";
document.ids.minspace.marginTop="6";
document.ids.nomargins.margins(14,8,8,8);
document.ids.buttontext.fontSize="11px";

document.ids.leftmargin.margins(0,0,16,40);
document.ids.smallleftmargin.margins(14,40,0,266);
document.ids.mediumleftmargin.margins(14,40,0,292);
document.ids.largeleftmargin.margins(14,40,0,340);
document.ids.xlargeleftmargin.margins(14,40,0,360);
document.ids.bulletsmallleftmargin.marginLeft="266"

document.ids.titleminspace.marginTop="26";

//Lists

document.tags.UL.listStyleType="disc";
document.tags.UL.fontFamily="PrimaSans BT, Helvetica,Arial";
document.tags.UL.fontSize="12px";
//tags.UL.lineHeight="1.2";
document.tags.UL.margins(-6,40,0,255)
document.tags.LI.fontSize="10";


//Communicator Preview tag

document.classes.previewtag.all.fontSize="12px";
document.classes.previewtag.all.paddingLeft="5";
document.classes.previewtag.all.color="white";
//classes.previewtag.all.fontWeight="900";



//-------------------------------------

document.classes.netscape.all.fontSize="12px";
document.classes.netscape.all.color="#000033";
//classes.netscape.all.margins(14,0,-330,0);

document.classes.component.all.fontFamily="PrimaSans BT, Helvetica,Arial";
document.classes.component.all.fontSize="16px";
document.classes.component.all.color="#006666";
//classes.component.all.margins(14,0,-330,0);

//classes.text.all.fontFamily="PrimaSans BT, Helvetica,Arial";
//classes.text.all.fontSize="12px";
//classes.text.all.color="#000033";
//classes.text.all.margins(0,0,0,0);

document.classes.plus.all.fontSize="14px";
document.classes.plus.all.color="#FFFFFF";
document.classes.plus.all.fontWeight="900";

document.classes.other.all.fontSize="12px";
document.classes.other.all.fontWeight="900";

document.ids.momarginbottom.marginBottom="0";
