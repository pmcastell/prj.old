//TAGS FOR TOUR

tags.BODY.fontFamily="PrimaSans BT, Helvetica,Arial";
tags.BODY.fontSize="12";
tags.TD.fontFamily="PrimaSans BT, Helvetica,Arial";
//tags.BODY.textAlign="left";
//tags.BODY.color="black";
//tags.BODY.marginTop="0";
//tags.BODY.marginBottom="0";
//tags.BODY.marginLeft="72";
//tags.BODY.borderWidths(0, 0, 0, 0);
//tags.BODY.paddings(0, 0, 0, 0);
tags.P.lineHeight="1.2";

tags.H2.fontSize="16";
tags.H2.marginTop="1em";
tags.H3.fontSize="12";
tags.H3.marginTop=".6em";

