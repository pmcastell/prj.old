//TAGS FOR INTERNET PREVIEW SCREENS

//tags.BODY.fontFamily="PrimaSans BT, Helvetica,Arial";
//tags.BODY.fontSize="12px";
//tags.BODY.textAlign="left";
//tags.BODY.color="black";
//tags.BODY.marginTop="0";
//tags.BODY.marginBottom="0";
//tags.BODY.marginLeft="72";
//tags.BODY.borderWidths(0, 0, 0, 0);
//tags.BODY.paddings(0, 0, 0, 0);

document.tags.P.fontFamily="PrimaSans BT, Helvetica,Arial";
document.tags.P.fontSize="12px";
document.tags.P.lineHeight="1.2";
document.tags.P.margins(14,40,0,255);


//Titles of Internet Preview screens

document.classes.title.all.fontSize="23px";
document.classes.title.all.fontFamily="PrimaSans BT, Helvetica,Arial";
document.classes.title.all.margins(34,0,0,43);


//Tables (for forms inputs, etc.)

document.tags.TABLE.marginTop="14";

document.tags.TD.fontFamily="PrimaSans BT, Helvetica,Arial";
document.tags.TD.fontSize="11px";
document.tags.TD.lineHeight="1.2"



//the entries below are exceptions to the standard definition

document.ids.nospace.marginTop="0";
document.ids.nospace1.marginTop="-9";
document.ids.minspace.marginTop="6";
document.ids.nomargins.margins(14,8,8,8);
document.ids.buttontext.fontSize="11px";

document.ids.mediumleftmargin.margins(14,40,0,300);
document.ids.largeleftmargin.margins(14,40,0,312);
document.ids.bulletslargeleftmargin.marginLeft="312"


//Lists

document.tags.UL.listStyleType="disc";
document.tags.UL.fontFamily="PrimaSans BT, Helvetica,Arial";
document.tags.UL.fontSize="12px";
//tags.UL.lineHeight="1.2";
document.tags.UL.margins(-6,40,0,255)
document.tags.LI.fontSize="10";



//Internet Preview tag

document.classes.previewtag.all.fontSize="12px";
document.classes.previewtag.all.paddingLeft="5";
document.classes.previewtag.all.color="white";
