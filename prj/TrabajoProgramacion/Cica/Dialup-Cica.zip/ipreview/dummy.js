<!--  to hide script contents from old browsers



function go(msg)
{
	return(checkData());
}



function checkData()
{
	return(true);
}



function loadData()
{
	if (parent && parent.controls && parent.controls.generateControls)	{
		parent.controls.generateControls();
		}
}



function saveData()
{
}



// end hiding contents from old browsers  -->
