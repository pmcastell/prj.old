<!--  to hide script contents from old browsers



function go()
{
	if (parent.parent.globals.document.vars.editMode.value == "yes")
		return true;
	else
		return(checkData());
}



function checkData()
{
	if (document.forms[0].accountName.value == "")	{
		alert("Debe introducir un nombre de inicio de sesi�n.");
		parent.parent.globals.setFocus(document.forms[0].accountName);
		return(false);
		}
      if (document.forms[0].accountPassword.value=="") {
            alert("Debe introducir la contrase�a de infovia.");
            parent.parent.globals.setFocus(document.forms[0].accountPassword);
            return(false); 
      }

	if (document.forms[0].accountPassword.value != document.forms[0].accountPasswordCheck.value)	{
		if (document.forms[0].accountPassword.value == "")	{
			parent.parent.globals.setFocus(document.forms[0].accountPassword);
			}
		else	{
			parent.parent.globals.setFocus(document.forms[0].accountPasswordCheck);
			}
		alert("La contrase�a que ha introducido en 'Vuelva a escribir la contrase�a' no coincide con la contrase�a escrita en 'Contrase�a'. Vuelva a escribir la contrase�a.");
		return(false);
		}
	return true;
}



function loadData()
{
	// make sure all data objects/element exists and valid; otherwise, reload.  SUCKS!
	if (((document.forms[0].accountName == "undefined") || (document.forms[0].accountName == "[object InputArray]")) ||
		((document.forms[0].accountPassword == "undefined") || (document.forms[0].accountPassword == "[object InputArray]")) ||
		((document.forms[0].accountPasswordCheck == "undefined") || (document.forms[0].accountPasswordCheck == "[object InputArray]")))
	{
		parent.controls.reloadDocument();
		return;
	}

	document.forms[0].accountName.value = parent.parent.globals.document.vars.accountName.value;
	document.forms[0].accountPassword.value = parent.parent.globals.document.vars.accountPassword.value;
	document.forms[0].accountPasswordCheck.value = parent.parent.globals.document.vars.accountPasswordCheck.value;
	parent.parent.globals.setFocus(document.forms[0].accountName);

	var theFile = parent.parent.globals.getAcctSetupFilename(self);
	var ttyFlag = parent.parent.globals.GetNameValuePair(theFile,"Existing Acct Mode","AskTTY");
	ttyFlag = ttyFlag.toLowerCase();
	if (ttyFlag != "no")	{
		// make sure all data objects/element exists and valid; otherwise, reload.  SUCKS!
		if ((document.forms[0].ttyWindow == "undefined") || (document.forms[0].ttyWindow == "[object InputArray]"))
		{
			parent.controls.reloadDocument();
			return;
			}
		document.forms[0].ttyWindow.checked = parent.parent.globals.document.vars.ttyWindow.checked;
		}
	if (parent.controls.generateControls)	parent.controls.generateControls();
}



function saveData()
{
	// make sure all form element are valid objects, otherwise just skip & return!
	if (((document.forms[0].accountName == "undefined") || (document.forms[0].accountName == "[object InputArray]")) ||
		((document.forms[0].accountPassword == "undefined") || (document.forms[0].accountPassword == "[object InputArray]")) ||
		((document.forms[0].accountPasswordCheck == "undefined") || (document.forms[0].accountPasswordCheck == "[object InputArray]")))
	{
		parent.controls.reloadDocument();
		return;
	}

	parent.parent.globals.document.vars.accountName.value = document.forms[0].accountName.value;
	parent.parent.globals.document.vars.accountPassword.value = document.forms[0].accountPassword.value;
	parent.parent.globals.document.vars.accountPasswordCheck.value = document.forms[0].accountPasswordCheck.value;

	var theFile = parent.parent.globals.getAcctSetupFilename(self);
	var ttyFlag = parent.parent.globals.GetNameValuePair(theFile,"Existing Acct Mode","AskTTY");
	ttyFlag = ttyFlag.toLowerCase();
	if (ttyFlag != "no")	{
		// make sure all form element are valid objects, otherwise just skip & return!
		if ((document.forms[0].ttyWindow == "undefined") || (document.forms[0].ttyWindow == "[object InputArray]")) {
			parent.controls.reloadDocument();
			return;
			}
		parent.parent.globals.document.vars.ttyWindow.checked = document.forms[0].ttyWindow.checked;
		}
	else	{
		parent.parent.globals.document.vars.ttyWindow.checked = 0;
		}
}



function generateTTYsupport()
{
	var theFile = parent.parent.globals.getAcctSetupFilename(self);
	ttyFlag = parent.parent.globals.GetNameValuePair(theFile,"Existing Acct Mode","AskTTY");
	ttyFlag = ttyFlag.toLowerCase();
	if (ttyFlag != "no")	{
		document.writeln("<INPUT NAME='ttyWindow' TYPE='checkbox'><P CLASS='tty'>Deseo una ventana de terminal (TTY) para poder iniciar la sesi�n manualmente cuando me conecte.</P>");
		}
}


// end hiding contents from old browsers  -->
