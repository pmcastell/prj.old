<!--  to hide script contents from old browsers



function go(msg)
{
	netscape.security.PrivilegeManager.enablePrivilege("AccountSetup");

	if (parent.parent.globals.document.vars.editMode.value != "yes")	{
		// if RegServer specified in ACCTSET.INI, use it
	
		var theFile = parent.parent.globals.getAcctSetupFilename(self);
		var intlFlag = parent.parent.globals.GetNameValuePair(theFile,"Mode Selection","IntlMode");
		intlFlag = intlFlag.toLowerCase();
	
		var theRegFile = parent.parent.globals.GetNameValuePair(theFile,"New Acct Mode","RegServer");
		
		if (theRegFile != null && theRegFile != "")	{
			parent.parent.globals.document.vars.regServer.value = theRegFile;
			}
		else	{
			// otherwise, if multiple .IAS files exist, get list selection and determine appropriate .IAS file
	
			var pathName = parent.parent.globals.getConfigFolder(self);
			var theList = parent.parent.globals.document.setupPlugin.GetFolderContents(pathName,".IAS");
			if (theList != null)	{
				if (theList.length >1)	{
					if (document.forms[0].regServerList.selectedIndex<0)	{
						alert("Seleccione un servidor de cuentas de Internet.");
						return(false);
						}
					for (var x=0; x<theList.length; x++)	{
						var file = parent.parent.globals.getConfigFolder(self) + theList[x];
						var name = parent.parent.globals.document.setupPlugin.GetNameValuePair(file,"Dial-In Configuration","SiteName");
	
						if (name == document.forms[0].regServerList.options[document.forms[0].regServerList.selectedIndex].text)	{
							parent.parent.globals.document.vars.regServer.value = theList[x];
							break;
							}
						}
					if (parent.parent.globals.document.vars.regServer.value == "")	{
						alert("Problema interno al buscar el archivo del servidor de registro adecuado.");
						return(false);
						}
					}
				else if (theList.length==1)	{
					parent.parent.globals.document.vars.regServer.value = theList[0];
					}
				else	{
					alert("Problema interno al buscar el archivo del servidor de registro.");
					return(false);
					}
				}
			else	{
				alert("Problema interno al buscar el archivo del servidor de registro adecuado.");
				return(false);
				}
			}
		return(true);
		}
	else	{
		return(false);
		}
}



function checkData()
{
	return(true);
}



function loadData()
{
	if (parent.controls.generateControls)	parent.controls.generateControls();
}



function saveData()
{
}



function generateRegServerList()
{
	netscape.security.PrivilegeManager.enablePrivilege("AccountSetup");

	// if RegServer is not specified in ACCTSET.INI and multiple .IAS files exist, build list

	var theFile = parent.parent.globals.getAcctSetupFilename(self);
	var theRegFile = parent.parent.globals.GetNameValuePair(theFile,"New Acct Mode","RegServer");
	
	if (theRegFile == null || theRegFile == "")	{
		var pathName = parent.parent.globals.getConfigFolder(self);
		var theList = parent.parent.globals.document.setupPlugin.GetFolderContents(pathName,".IAS");
		if (theList != null)	{
			if (theList.length >1)	{
				document.writeln("<TABLE CELLPADDING=2 CELLSPACING=0 ID='minspace'><TR><TD ALIGN=LEFT VALIGN=TOP HEIGHT=25><spacer type=vertical size=2><B>Seleccione un servidor de cuentas de Internet:</B></TD><TD ALIGN=LEFT VALIGN=TOP><FORM><SELECT NAME='regServerList'>");
				for (var x=0; x<theList.length; x++)	{
					var file = parent.parent.globals.getConfigFolder(self) + theList[x];
					var name = parent.parent.globals.document.setupPlugin.GetNameValuePair(file,"Dial-In Configuration","SiteName");
					var selected=(x==0) ? " SELECTED":"";
					document.writeln("<OPTION VALUE='" + name + "'" + selected + ">" + name);
					}
				document.writeln("</SELECT></FORM></TD></TR></TABLE>");
				}
			}
		}
}



// end hiding contents from old browsers  -->
