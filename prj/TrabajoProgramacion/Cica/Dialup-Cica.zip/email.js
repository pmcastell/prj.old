<!--  to hide script contents from old browsers



function go(msg)
{
	if (parent.parent.globals.document.vars.editMode.value == "yes")
		return true;
	else
		return(checkData());
}



function checkData()
{
	if (document.forms[0].emailPassword.value != document.forms[0].emailPasswordCheck.value)	{
		if (document.forms[0].emailPassword.value == "")	{
			parent.parent.globals.setFocus(document.forms[0].emailPassword);
			}
		else	{
			parent.parent.globals.setFocus(document.forms[0].emailPasswordCheck);
			}
		alert("La contrase�a que ha introducido en 'Vuelva a escribir la contrase�a' no coincide con la contrase�a escrita en 'Contrase�a'. Vuelva a escribir la contrase�a.");
		return(false);
		}
	return(true);
}



function loadData()
{
	// make sure all data objects/element exists and valid; otherwise, reload.  SUCKS!
	if (((document.forms[0].emailName == "undefined") || (document.forms[0].emailName == "[object InputArray]")) ||
		((document.forms[0].emailPassword == "undefined") || (document.forms[0].emailPassword == "[object InputArray]")) ||
		((document.forms[0].emailPasswordCheck == "undefined") || (document.forms[0].emailPasswordCheck == "[object InputArray]")))
	{
		parent.controls.reloadDocument();
		return;
	}

	document.forms[0].emailName.value = parent.parent.globals.document.vars.emailName.value;
	document.forms[0].emailPassword.value = parent.parent.globals.document.vars.emailPassword.value;
	document.forms[0].emailPasswordCheck.value = parent.parent.globals.document.vars.emailPasswordCheck.value;
	if (document.forms[0].emailName.value == "" && document.forms[0].emailPassword.value == "" && document.forms[0].emailPasswordCheck.value == "")	{
		document.forms[0].emailName.value = parent.parent.globals.document.vars.accountName.value;
//		document.forms[0].emailPassword.value = parent.parent.globals.document.vars.accountPassword.value;
//		document.forms[0].emailPasswordCheck.value = parent.parent.globals.document.vars.accountPasswordCheck.value;
		}
	parent.parent.globals.setFocus(document.forms[0].emailName);
	if (parent.controls.generateControls)	parent.controls.generateControls();
}



function saveData()
{
	// make sure all form element are valid objects, otherwise just skip & return!
	if (((document.forms[0].emailName == "undefined") || (document.forms[0].emailName == "[object InputArray]")) ||
		((document.forms[0].emailPassword == "undefined") || (document.forms[0].emailPassword == "[object InputArray]")) ||
		((document.forms[0].emailPasswordCheck == "undefined") || (document.forms[0].emailPasswordCheck == "[object InputArray]")))
	{
		parent.controls.reloadDocument();
		return(true);
	}

	parent.parent.globals.document.vars.emailName.value = document.forms[0].emailName.value;
	parent.parent.globals.document.vars.emailPassword.value = document.forms[0].emailPassword.value;
	parent.parent.globals.document.vars.emailPasswordCheck.value = document.forms[0].emailPasswordCheck.value;
	return(true);
}



// end hiding contents from old browsers  -->
