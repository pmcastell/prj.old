#include <stdio.h>
#include <alloc.h>
#include <string.h>
#include <dos.h>
#include "extend.h"
#include "ipxlib.h"


/*CLIPPER SOMBRA()
{
   int x1, y1, x2, y2, i, j;
   unsigned char far *pantalla;

   x1= _parni(1);
   y1= _parni(2);
   x2= _parni(3);
   y2= _parni(4);
   /*pantalla=MK_FP(((biosequip() & 0x30) == 0x30)*0x800+0xb000,0);*/
   pantalla=MK_FP(0xb800,0);
   for (i=x1;i<=x2;i++) {
      for (j=y1;j<=y2;j++) {
	 pantalla[i*160+2*j+1]%=8;
      }
   }
   _ret();
}*/

/*CLIPPER _CH_COLOR()
{
   unsigned char far *pantalla;
   unsigned int i,tinta,papel;
   unsigned char *atributo;

   tinta= _parni(1);
   papel= _parni(2);
   *atributo= (papel << 4) +  tinta;
   pantalla=MK_FP(0xb800,0);
   for (i=1;i<4000;i+=2) {
      pantalla[i]= atributo[0];
   }
   _ret();
}*/

CLIPPER IMPR_PANT()
{
   geninterrupt(0x5);
   _ret();
}

CLIPPER INTR()
{
   geninterrupt(_parni(1));
   _ret();
}

/* funcion scrroll llamada _scrl(dir,x1,y1,x2,y2,Num_lin,Atrib_relleno)*/
CLIPPER _SCRL()
{
   int dir,x1,y1,x2,y2,par6,par7;

   dir= _parni(1); /* direccion del scroll */
   x1= _parni(2);
   y1= _parni(3);
   x2= _parni(4);
   y2= _parni(5);
   par6=_parni(6);
   par7=_parni(7);
   if (dir) {
      _AH=0x06;  /* servicio de INT 10h (arriba)*/
   } else {
      _AH=0x07; /* servicio de INT 10h (abajo) */
   }
   _AL= par6; /* n�mero de l�neas a "scrollear"*/
   _BH= par7; /* atributo color relleno */
   _CH= x1; /* coordenada esquina sup.izda. fila */
   _CL= y1; /*  "          "        "   "   col. */
   _DH= x2; /*  "          "      inf.dcha. fila */
   _DL= y2; /*  "          "       "    "   col. */
   geninterrupt(0x10);
   _ret();
}

CLIPPER REEMPLAZAC()
/* llamada reemplazac(cadena,caracter,indice)*/
{
    _parc(1)[_parni(3)+1]=*_parc(2);
   _ret();
}
CLIPPER SONIDO()
{
   sound(_parni(1));
   _ret();
}
CLIPPER RETARDO()
{
   delay(_parni(1));
   _ret();
}
CLIPPER SUPERSONIC()
{
   unsigned int i, min, max;

   min=26000;
   max=29500;
   for(i=min;i<=max;i++) {
      sound(i-(max << 4));
      delay(0.5);
      sound( i << 2);
      sound(max-i);
      delay(0.5);
   }
   nosound();
}
CLIPPER TIRO()
{
   unsigned int i;

   for(i=4000;i>=20;i-=4) {
      sound(i);
   }
   nosound();
}
CLIPPER AMETRALLAD()
{
   int j;

   for(j=1;j<=20;j++) {
      TIRO();
   }
}
CLIPPER LASER()
{
   unsigned int j,min,base;
   unsigned long max,i;

   base=4400;
   min=2200;
   max=3600;
   /*incremento=1; incrementos decimales necesitaria floating point*/
   i=min;
   while ( i<max) {
      sound(base+(int)(i) % base);
      sound(base-(int)(i) % base);
      i++;
   }
   nosound();
}

CLIPPER SOMBREA()
{
   int i,j;
   char *c;

   j=_parni(2);
   c=_parc(1);
   for (i=1;i<j;i+=2)
      c[i]%=8;

   _ret();
}

CLIPPER _CH_COLOR()
/* llamada cambia_color(pant,atributo,lon)*/
{
    int i,lon;
    char *pant,*atributo;

    pant=_parc(1);
    atributo=_parc(2);
    lon=_parni(3);
    for (i=1;i<=lon;i+=2,pant++) {
       *++pant=*atributo;
    }
    _ret();
}

/**************************************************************

  Chatter
  Copyright (c) 1992 Kurt Duncan - All Rights Reserved

  An interactive communications program based on the NOVELLtm
  IPX/SPX transport mechanism.

  Command line:
    CHATTER [<ident>] [<options>]

  Options:
    -r<rows on display>
       sets number of rows of display (25, 43, 50)
       defaults to 25

    -m
       indicates a monochrome monitor

    -s<hex_socket_number>
       indicates the IPX socket number to be used
       defaults to 5000h

    -b<number_of_buffers>
       indicates the number of ECB/IPX_header buffers
         that will be allocated for receiving network traffic
       defaults to 16

**************************************************************/




#define PROCESSOR_NAME       "CHATTER V1.10"


/*****************************************************************
  The following codes are arbitrary values which we will use
  to classify the various messages we are going to deal with.
  The code is stored as the first data byte in each IPX message.
*****************************************************************/

#define JOIN_CODE            0x00
#define LEAVE_CODE           0x01
#define PROBE_CODE           0x02
#define RESPOND_CODE         0x03
#define MESSAGE_CODE         0x0F


/******************************************************************
  Stuff for dealing with color attributes... and which
  automatically chose monochrome attributes if Color_Display == 0
******************************************************************/

#define COLOR_TEST(cv, mv)   (Color_Display ? cv : mv)
#define WHITE_ON_BLACK       0x0F
#define GREY_ON_BLACK        0x07
#define BLACK_ON_WHITE       0x70
#define WHITE_ON_RED         0x4F
#define YELLOW_ON_BLACK      0x0E
#define GREEN_ON_BLACK       0x0A
#define CYAN_ON_BLACK        0x0B
#define CYAN_ON_BLUE         0x1B
#define YELLOW_ON_GREEN      0x2E

#define PROCESSOR_LINE_COLOR COLOR_TEST (WHITE_ON_RED,    BLACK_ON_WHITE)
#define TEXT_COLOR           COLOR_TEST (GREEN_ON_BLACK,  GREY_ON_BLACK)
#define JOIN_COLOR           COLOR_TEST (WHITE_ON_RED,    BLACK_ON_WHITE)
#define IDENT_COLOR          COLOR_TEST (CYAN_ON_BLACK,   GREY_ON_BLACK)
#define MESSAGE_COLOR        COLOR_TEST (YELLOW_ON_BLACK, WHITE_ON_BLACK)
#define INPUT_COLOR          COLOR_TEST (CYAN_ON_BLUE,    BLACK_ON_WHITE)
#define TRACE_COLOR          COLOR_TEST (YELLOW_ON_GREEN, BLACK_ON_WHITE)


/****************************************
  Macros which think they are functions
****************************************/

#define Screen_Write(p)     Screen_Write_Attr (p, Screen_Attribute)
#define Screen_Append(p)    Screen_Append_Attr (p, Screen_Attribute)
#define Setup_Send(c, m)    Setup_Send_Specific (c, m, &Broadcast)

#define MK_FP(seg, off) (void far *) ((((unsigned long) seg) << 16) | (off))


/*********************************************************
  Functions which are described further down in the code
*********************************************************/

void Show_Node_Address   (unsigned char *Node, unsigned char *Msg);
void Clear_Buffer        (void);
void Screen_Clear        (void);
void Screen_ClearLast    (void);
void Screen_Scroll       (void);
void Screen_Write_Attr   (char *Inst, char Attr);
int  Initialization      (char *argv);
void Termination         (void);
void Setup_Send_Specific (char Code, char *Inmsg, struct IPX_address *Addr);
void Execute_Command     (char *CString);
void Poll                (void);
void Poll_Key            (void);
void Poll_Net            (void);


/***********************************************************
  Various Data Structures are defined and/or declared here
***********************************************************/

struct Character_Cell {  /* A definition of a screen position in video  */
    char Character;      /* memory.  Such memory is assumed to begin at */
    char Attribute;      /* address B800:0000.                          */
    };


IPX_ECB     Send_ECB;    /* An ECB packet for sending data        */
IPX_header  Send_IPXH;   /* An IPX header packet for sending data */
unsigned int       Buffers;     /* The number of buffers we will support */
IPX_ECB    *ECBPointer;  /* Pointer to first ECB buffer           */
IPX_header *IPXHPointer; /* Pointer to first IPX header buffer    */
struct IPX_address Broadcast;   /* An address structure which we will    */
                                /*   initialize, such that we can use it */
                                /*   to send broadcasts later on.        */

char         Buffer[80];        /* Input buffer - holds user input   */
unsigned int Bufsub;            /* Current number of chars in buffer */

unsigned int Socket_Number;     /* IPX socket number we communicate on   */
unsigned int Color_Display;     /* zero if monochrome, nonzero otherwise */
char         Ident[9];          /* user's identifier, from command line  */

struct Character_Cell far *Screen; /* Pointer to video memory              */
char         Screen_Attribute;     /* Default attribute for erasing screen */
unsigned int Screen_Rows;          /* Number of rows on screen             */
unsigned int Append_Suboff;        /* Last screen position written to      */

unsigned int Trace;             /* Trace flag; nonzero indicates trace on */
unsigned int All_Done;          /* nonzero indicates user wants to quit   */



/******************************************************************
  The following routine takes the Node portion of an IPXH_address
  structure, and converts the six byte field to an ASCII string
  that can be displayed.  An example of the output would look
  similar to:

        00.00.1B.2C.19.37
******************************************************************/

void Show_Node_Address (unsigned char *Node, unsigned char *Msg) {
    int  inx, outx, lcv;
    char ch, cl;

    inx = 0;
    outx = 0;
    for (lcv = 0; lcv < 6; lcv++) {
        ch = (Node[inx] >> 4) | 0x30;
        if (ch > '9') ch += 7;
        cl = (Node[inx++] & 0x0F) | 0x30;
        if (cl > '9') cl += 7;
        Msg[outx++] = ch;
        Msg[outx++] = cl;
        if (lcv < 5) Msg[outx++] = '.';
        }
    Msg[outx] = 0x00;
    return;
    }


/****************************************************************
  The following routine sets all of the bytes of the internally
  maintained input buffer to binary zero.
****************************************************************/

void Clear_Buffer (void) {
    int sub;

    Bufsub = 0;
    for (sub = 0; sub < 80; sub++)
        Buffer[sub] = 0;
    return;
    }


/*****************************************************************
  Using direct memory access, we set the entire screen to blanks
  (hex 0x20), with an attribute value as specified by 
  Screen_Attribute.
*****************************************************************/

void Screen_Clear (void) {
    int sub;
    
    for (sub = 0; sub < (Screen_Rows * 80); sub++) {
        Screen[sub].Character = 0x20;
        Screen[sub].Attribute = Screen_Attribute;
        }
    return;
    }


/************************************************************
  Sets the last line of the display to all blanks, with the
  attribute specified by INPUT_COLOR.
************************************************************/

void Screen_ClearLast (void) {
    unsigned int sub, cnt;

    sub = (Screen_Rows - 1) * 80;
    for (cnt = 0; cnt < 80; cnt++) {
        Screen[sub].Character = 0x20;
        Screen[sub++].Attribute = INPUT_COLOR;
        }
    return;
    }


/************************************************************
  Scrolls the display area of the screen (basically, all of
  the screen except for the last row) up by one line.  The
  last line of the display area is set to blanks, with the
  attribute specified by Screen_Attribute.
************************************************************/

void Screen_Scroll (void) {
    unsigned int sub, suboff;

    suboff = 80;
    for (sub = 0; sub < (Screen_Rows - 2) * 80; sub++) {
        Screen[sub].Character = Screen[suboff].Character;
        Screen[sub].Attribute = Screen[suboff].Attribute;
        suboff++;
        }
    suboff = (Screen_Rows - 2) * 80;
    for (sub = 0; sub < 80; sub++) {
        Screen[suboff].Character = 0x20;
        Screen[suboff++].Attribute = Screen_Attribute;
        }
    return;
    }


/****************************************************************
  Scrolls the display area, and writes the given string to the
  last line of the display area, using the specified attribute.
  We keep track of the last screen position written to, in case
  the calling routine decides to call Screen_Append_Attr.

  The Screen_Write macro calls this function, with the
  Screen_Attribute value as the second parameter.
****************************************************************/

void Screen_Write_Attr (char *Inst, char Attr) {
    unsigned int sub, limit, suboff;

    Screen_Scroll ();
    limit = strlen (Inst) + 1;
    if (limit > 80) limit = 80;
    suboff = (Screen_Rows - 2) * 80;
    for (sub = 0; sub < limit; sub++) {
        Screen[suboff].Character = Inst[sub];
        Screen[suboff++].Attribute = Attr;
        }
    Append_Suboff = suboff;
    return;
    }


/***************************************************************
  Writes the specified output to the display area, starting at
  the position which follows the last position written to by
  either Screen_Write_Attr or Screen_Append_Attr, using the
  attribute specified.  We keep track of the last screen
  position written to, in case the calling routine decides to
  call us again.

  The Screen_Append macro calls this function, with the
  Screen_Attribute value as the second parameter.
***************************************************************/

void Screen_Append_Attr (char *Inst, char Attr) {
    unsigned int sub, limit, suboff;

    limit = strlen (Inst);
    suboff = Append_Suboff;
    for (sub = 0; sub < limit; sub++) {
        Screen[suboff].Character = Inst[sub];
        Screen[suboff++].Attribute = Attr;
        }
    Append_Suboff = suboff;
    return;
    }


/*****************************************************************
  We do a lot of stuff here.  See embedded comments for details.
  This code happends once, when the program first executes.  The
  code has been placed here, so that the main function can stay
  relatively clean.  Basically, we do all setup, and return a
  zero value (false) if something went wrong.  Otherwise, we
  return a nonzero value (true) to indicate to main that all is
  okay.
*****************************************************************/

int Initialization (char *argv) {
    union REGS   regs;
    unsigned int sub, scsub;
    char         tempst[80];
    void far *fp;

  /* Check whether IPX is loaded */

    if (!(IPX_Is_Loaded ())) {
        printf ("IPX is not loaded!\n");
        return (0);
        }

  /* Set default values                            */
  /* Default socked is 5000 hex,                   */
  /* Default display mode is color,                */
  /* trace is cleared,                             */
  /* buffers is set to 16,                         */
  /* base screen address is set to B800:0000,      */
  /* screen rows is set to 25,                     */
  /* screen attribute is set to dim white on black */

    Socket_Number = 0x5000;
    strcpy (Ident, "<anon>  ");
    Color_Display = 1;
    Trace = 0;
    Buffers = 16;
    Screen = MK_FP (0xB800, 0x0000);
    Screen_Rows = 25;
    Screen_Attribute = 0x0007;

  /* Read command line parameters                                  */
  /* The first parameter without a leading hyphen is considered to */
  /* be an ident code.  The next such parameter causes an error.   */
  /* All parameters which start with a hyphen are considered       */
  /* switches, and are compared against the valid switches.        */

     if (strlen (argv) > 20) {
	 printf ("Parameter %u is too long\n", sub);
	 return (0);
	 }
     strcpy (tempst, argv);
     if (tempst[0] != '-') {
	 if (strlen (tempst) > 8) {
	     printf ("Ident code \"%s\" at parameter %u is too long - \n"
		     "  limit is eight characters\n", tempst, sub);
	     return (0);
	     }
	 if (strcmp (Ident, "<anon>  ") != 0) {
	     printf ("Unrecognized text \"%s\" at parameter %u\n",
		     tempst, sub);
	     return (0);
	     }
	 else {
	     strcpy (Ident, tempst);
	     while (strlen (Ident) < 8)
		 strcat (Ident, " ");
	     }
	 }
     else {
	 char t2[19];
	 int  ti;

	 strcpy (t2, &tempst[2]);
	 switch (tempst[1]) {
	     case 'r':
	     case 'R':
		 ti = sscanf (t2, "%u", &Screen_Rows);
		 if ((ti == 0) || (Screen_Rows > 50)) {
		     printf ("Invalid number of rows given - "
			     "Option \"%s\" at parameter %u\n",
			     tempst, sub);
		     return (0);
		     }
		 break;
	     case 'm':
	     case 'M':
		 if (t2[0] != 0x00)
		     printf ("Extraneous text \"%s\" on -m option "
			     "at parameter %u ignored\n",
			     t2, sub);
		 Color_Display = 0;
		 break;
	     case 's':
	     case 'S':
		 ti = sscanf (t2, "%X", &Socket_Number);
		 if (ti == 0) {
		     printf ("Invalid Socket Number given - "
			     "Option \"%s\" at parameter %u\n",
			     tempst, sub);
		     return (0);
		     }
		 break;
	     case 'b':
	     case 'B':
		 ti = sscanf (t2, "%u", &Buffers);
		 if (ti == 0) {
		     printf ("Invalid Buffer count given - "
			     "Option \"%s\" at parameter %u\n",
			     tempst, sub);
		     return (0);
		     }
		 break;
	     default:
		 printf ("Unrecognized option \"%s\" at parameter %u\n",
			 tempst, sub);
		 return (0);
	     }
	 }


  /* Allocate buffer space for listen ECB's and IPX headers,  */
  /* then initialize the relevant ECB fields.  Finally, set   */
  /* up all the buffers for listening.                        */
  /* We use multiple buffers because it is certain that we    */
  /* will, sooner or later, encounter a condition where we    */
  /* cannot fully process an input message before another one */
  /* is received.  Thus, we chain several buffers to our      */
  /* socket, and let IPX use them up one by one.  As we       */
  /* process them, we set them back up for listening.  If we  */
  /* are lucky, we will never get more traffic than we can    */
  /* handle.                                                  */
  
    /*(void *)
    ECBPointer = (IPX_ECB *) _xalloc(Buffers * sizeof (IPX_ECB));
    if (ECBPointer == NULL) {
        printf ("Unable to allocate memory for ECB buffers\n");
	return(0);
	}

    (void *)
    IPXHPointer = (IPX_header *) _xalloc (Buffers * sizeof (IPX_header));
    if (IPXHPointer == NULL) {
	_xfree (ECBPointer);
        printf ("Unable to allocate memory for IPX header buffers\n");
        return (0);
	}*/
    
    for (sub = 0; sub < Buffers; sub++) {
        ECBPointer[sub].In_Use = 01;
        ECBPointer[sub].ESR_Address.segment = 0;
        ECBPointer[sub].ESR_Address.offset = 0;
        ECBPointer[sub].Socket_Number = IPX_Flipword (Socket_Number);
        ECBPointer[sub].Fragment_Count = 1;
        fp = &IPXHPointer[sub];
        ECBPointer[sub].Fragment_Desc[0].Address.segment = FP_SEG (fp);
        ECBPointer[sub].Fragment_Desc[0].Address.offset = FP_OFF (fp);
        ECBPointer[sub].Fragment_Desc[0].Size = 576;
        }

    IPX_Open_Socket (Socket_Number);
    for (sub = 0; sub < Buffers; sub++)
        IPX_Listen_For_Packet (&ECBPointer[sub]);

  /* Hide the DOS cursor */
    regs.h.ah = 0x03;
    int86 (0x10, &regs, &regs);
    regs.h.ch |= 0x20;
    regs.h.ah = 0x01;
    int86 (0x10, &regs, &regs);

  /* Clear the screen, and set the buffer cursor (a simulated cursor) */
    Screen_Clear ();
    Screen_ClearLast ();
    Clear_Buffer ();
    scsub = (Screen_Rows - 1) * 80;
    Screen[scsub].Character = '_';
    Screen[scsub].Attribute = INPUT_COLOR;

  /* Display initial messages */
    Screen_Write_Attr (PROCESSOR_NAME, PROCESSOR_LINE_COLOR);
    sprintf (tempst, "Ident:   %s", Ident);
    Screen_Write_Attr (tempst, TEXT_COLOR);
    sprintf (tempst, "Socket:  %xh", Socket_Number);
    Screen_Write_Attr (tempst, TEXT_COLOR);
    sprintf (tempst, "Buffers: %u", Buffers);
    Screen_Write_Attr (tempst, TEXT_COLOR);
    Screen_Write_Attr ("Enter \\HELP for a list of commands",
                       TEXT_COLOR);
    
  /* Set up our Broadcast structure address fields for      */
  /* sending output to all nodes on the network.            */
  /* Send broadcast messages, type JOIN_CODE and PROBE_CODE */

    Broadcast.Network = 0;
    strcpy (Broadcast.Node.ch, "\xFF\xFF\xFF\xFF\xFF\xFF");
    Broadcast.Socket = IPX_Flipword (Socket_Number);

    Setup_Send (JOIN_CODE, "");
    Setup_Send (PROBE_CODE, "");
    return (1);
    }


/*************************************************************
  Termination is fairly simple:

    Cancel all ECB packets.  The IPXLIB routines will ignore
      such requests for all packets that might not currently
      be on the listen queue.
    Free the memory previously occupied by the ECB and IPX
      header buffers.
    Send one final message, LEAVE_CODE, to indicate to the
      other users on the network that you are going away.
    Close the IPX socket.
    Clear the screen.
    Restore the DOS cursor.
*************************************************************/

void Termination (void) {
    union REGS regs;
    int sub;

    for (sub = 0; sub < Buffers; sub++)
        IPX_Cancel_Event (&ECBPointer[sub]);
    /*_xfree (IPXHPointer);
    _xfree (ECBPointer);*/

    Setup_Send (LEAVE_CODE, "");
    IPX_Close_Socket (Socket_Number);
    Screen_Clear ();

    regs.h.ah = 0x03;
    int86 (0x10, &regs, &regs);
    regs.h.ch &= 0xDF;
    regs.h.ah = 0x01;
    int86 (0x10, &regs, &regs);

    return;
    }


/********************************************************************
  The following routine sets up the ECB and IPX header packets for
  sending the specified message.  The caller provides a message
  code (JOIN_CODE, LEAVE_CODE, etc), a message, and an IPX address
  structure which indicates the node to which the message is to be
  sent.  The first thing we do is set up the IPX header, which is
  followed by the actual data.  The data sent is formatted as such:
    Byte +00: message code             1 byte
    Byte +01: Ident, from command line 8 bytes
    Byte +09: message                  zero to 500 bytes
  The next thing we do is we call the IPX_Get_Local_Target function
  to determine what the immediate address in the ECB should be (in
  case we need to cross through a router), and then we set up the
  ECB packet.
  If Trace is set, we send a message to the local display.
  Finally, we send the message itself, and wait until we are sure
  the message actually got sent (not necessarily received, though).

  The Setup_Send macro calls this function, providing the
  broadcast address structure as the third parameter.
********************************************************************/

void Setup_Send_Specific (char Code, 
                          char *Inmsg,
                          struct IPX_address *Addr) {
    void far *fp;
    char tmsg[80], cmsg[20], nmsg[30];

    if (strlen (Inmsg) > 500) return;

    Send_IPXH.Packet_Type = 0;
    Send_IPXH.Destination.Network = Addr->Network;
    memcpy (Send_IPXH.Destination.Node.ch, Addr->Node.ch, 6);
    Send_IPXH.Destination.Socket = Addr->Socket;
    Send_IPXH.Data[0] = Code;
    memcpy (&Send_IPXH.Data[1], Ident, 8);
    strcpy (&Send_IPXH.Data[9], Inmsg);

    IPX_Get_Local_Target (&Send_IPXH.Destination, 
                          &Send_ECB.Immediate_Address);
    Send_ECB.ESR_Address.segment = 0;
    Send_ECB.ESR_Address.offset = 0;
    Send_ECB.Socket_Number = IPX_Flipword (Socket_Number);
    Send_ECB.Fragment_Count = 1;
    fp = &Send_IPXH;
    Send_ECB.Fragment_Desc[0].Address.segment = FP_SEG (fp);
    Send_ECB.Fragment_Desc[0].Address.offset = FP_OFF (fp);
    Send_ECB.Fragment_Desc[0].Size = 30 + 8 + strlen (Inmsg) + 1;

    if (Trace) {
        switch (Send_IPXH.Data[0]) {
            case JOIN_CODE:
                strcpy (cmsg, "JOIN   ");
                break;
            case LEAVE_CODE:
                strcpy (cmsg, "LEAVE  ");
                break;
            case PROBE_CODE:
                strcpy (cmsg, "PROBE  ");
                break;
            case RESPOND_CODE:
                strcpy (cmsg, "RESPOND");
                break;
            case MESSAGE_CODE:
                strcpy (cmsg, "MESSAGE");
                break;
            default:
                sprintf (cmsg, "UNKNOWN");
                break;
            }
        Show_Node_Address (Send_IPXH.Destination.Node.ch, nmsg);
        sprintf (tmsg, " - Sending %s packet  to  Network %u Node ",
                 cmsg, Send_IPXH.Destination.Network);
        strcat (tmsg, nmsg);
        Screen_Write_Attr (tmsg, TRACE_COLOR);
        }

    IPX_Send_Packet (&Send_ECB);
    while (Send_ECB.In_Use == 0xFF)
        IPX_Relinquish_Control ();

    return;
    }


/**********************************************************************
  This function executes the command which is passed as the argument.
  Valid commands include \EXIT, \HELP, \TRACE, and \WHO.  These
  commands will be keyed by the user, or invoked as a result of a
  special keystroke such as ESC, F1, etc.

  The \EXIT command sets All_Done to non-zero (true), which will
    eventually cause CHATTER to terminate.
  The \HELP command causes a list of valid commands to be sent to the
    display area.
  The \TRACE command toggles the Trace identifier between zero and
    nonzero states, with zero indicating Trace-is-off.
  The \PROBE command broadcasts a PROBE message.  The message is
    transparent to the user, but causes all receiving stations to
    transmit a RESPOND message to the originating station.
**********************************************************************/

void Execute_Command (char *CString) {
    char         temp[10];
    unsigned int sub;

    memcpy (temp, CString, 9);
    temp[9] = 0x00;
    sub = 0;
    while (sub < strlen (CString)) {
        if (temp[sub] == 32) {
            temp[sub] = 0x00;
            sub = 9;
            }
        if (temp[sub] >= 'a')
            temp[sub] -= 32;
        sub++;
        }
    if (strcmp (temp, "\\EXIT") == 0) {
        All_Done = 1;
        return;
        }
    if (strcmp (temp, "\\HELP") == 0) {
        Screen_Write_Attr ("List of commands:", TEXT_COLOR);
        Screen_Write_Attr ("  \\EXIT  or ESC: Terminate CHATTER",
                           TEXT_COLOR);
        Screen_Write_Attr ("  \\HELP  or F1:  This Display", TEXT_COLOR);
        Screen_Write_Attr ("  \\TRACE or F2:  Toggles Trace Mode", 
                           TEXT_COLOR);
        Screen_Write_Attr ("  \\WHO   or F3:  List of Conferencees",
                           TEXT_COLOR);
        return;
        }
    if (strcmp (temp, "\\TRACE") == 0) {
        if (Trace) {
            Trace = 0;
            Screen_Write_Attr ("TRACE is now off", TEXT_COLOR);
            }
        else {
            Trace = 1;
            Screen_Write_Attr ("TRACE is now on", TEXT_COLOR);
            }
        return;
        }
    if (strcmp (temp, "\\WHO") == 0) {
        Setup_Send (PROBE_CODE, "");
        return;
	}
    }



/******************************************************************
  This function checks all of the listen buffers to see if any of
  them have a message.  If so, the message is processed, and the
  buffer is returned to the listen chain via the IPXLIB call
  IPX_Listen_For_Packet.  As soon as we find a message that has
  been received, assuming trace is set, we compose and display
  a message indicating the type of message, and the source.
  Most message result in some kind of message being sent to the
  display area, except for the PROBE message.  If we receive a
  PROBE message, we compose a RESPOND message and send it back to
  whichever station sent the original PROBE message.
******************************************************************/

void Poll_Net (void) {
    int  dsize;
    char msg[9], tmsg[80], cmsg[20], nmsg[30];
    int  sub;
    
    for (sub = 0; sub < Buffers; sub++) {
        if ((ECBPointer[sub].In_Use == 0) &&
          (ECBPointer[sub].Completion_Code == 0)) {
            if (Trace) {
                switch (IPXHPointer[sub].Data[0]) {
                    case JOIN_CODE:
                        strcpy (cmsg, "JOIN   ");
                        break;
                    case LEAVE_CODE:
                        strcpy (cmsg, "LEAVE  ");
                        break;
                    case PROBE_CODE:
                        strcpy (cmsg, "PROBE  ");
                        break;
                    case RESPOND_CODE:
                        strcpy (cmsg, "RESPOND");
                        break;
                    case MESSAGE_CODE:
                        strcpy (cmsg, "MESSAGE");
                        break;
                    default:
                        sprintf (cmsg, "UNKNOWN");
                        break;
                    }
                Show_Node_Address (IPXHPointer[sub].Source.Node.ch, nmsg);
                sprintf (tmsg, " - Reading %s packet from Network %u Node ",
                         cmsg, IPXHPointer[sub].Source.Network);
                strcat (tmsg, nmsg);
                Screen_Write_Attr (tmsg, TRACE_COLOR);
                }
            dsize = IPX_Flipword (IPXHPointer[sub].Length) - 30;
            IPXHPointer[sub].Data[dsize] = 0x00;
            switch (IPXHPointer[sub].Data[0]) {
                case JOIN_CODE:
                    memcpy (msg, &IPXHPointer[sub].Data[1], 8);
                    msg[8] = 0x00;
                    Screen_Write_Attr (msg, IDENT_COLOR);
                    Screen_Append (" ");
                    Screen_Append_Attr ("<< Joining Conference >>", 
                                        JOIN_COLOR);
                    break;
                case LEAVE_CODE:
                    memcpy (msg, &IPXHPointer[sub].Data[1], 8);
                    msg[8] = 0x00;
                    Screen_Write_Attr (msg, IDENT_COLOR);
                    Screen_Append (" ");
                    Screen_Append_Attr ("<< Leaving Conference >>", 
                                        JOIN_COLOR);
                    break;
                case PROBE_CODE:
                    Setup_Send_Specific (RESPOND_CODE, "", 
                                         &IPXHPointer[sub].Source);
                    break;
                case RESPOND_CODE:
                    memcpy (msg, &IPXHPointer[sub].Data[1], 8);
                    msg[8] = 0x00;
                    Screen_Write_Attr (msg, IDENT_COLOR);
                    Screen_Append (" ");
                    Screen_Append_Attr ("<< Responding to probe >>", 
                                        JOIN_COLOR);
                    break;
                case MESSAGE_CODE:
                    memcpy (msg, &IPXHPointer[sub].Data[1], 8);
                    msg[8] = 0x00;
                    Screen_Write_Attr (msg, IDENT_COLOR);
                    Screen_Append (" ");
                    if (strlen (&IPXHPointer[sub].Data[9]) > 70)
                        IPXHPointer[sub].Data[79] = 0x00;
                    Screen_Append_Attr (&IPXHPointer[sub].Data[9], 
                                        MESSAGE_COLOR);
                    break;
                }
            IPX_Listen_For_Packet (&ECBPointer[sub]);
            }
        }
    return;
    }


/**********************************************************************
  This function uses DOS interrupt 21h to read keystrokes.  If there
  are no keystrokes waiting for us, we just return.  Otherwise, we
  look at what we got, and take action accordingly.

  If we get a backspace (hex 08), we erase the most recent input
    character from the input area, and back up the Bufsub counter.
  If we get a carraige return (hex 0D), we set up the entire input
    buffer as a network message and broadcast it, unless the first
    input character is a backslash, in which case we try to interpret
    the input buffer as a valid command (via Execute_Command).
  If we get a two-byte sequence, we evaluate the second byte.  If we
    have an F1, F2, or F3, we call Execute_Command.  Otherwise, we
    ignore the keystroke.
  If we have an ESC key (hex 1B) we call Execute_Command.
  If we have a control character, we ignore it.
  Anything that gets through the previous checks is considered valid,
    and is copied to the input buffer.
**********************************************************************/

void Poll_Key (void) {
    union REGS regs;
    int scsub;

    regs.h.ah = 0x0B;                  /* look for buffered characters */
    int86 (0x21, &regs, &regs);
    if (regs.h.al == 0x00) return;     /* return if there aren't any   */

    regs.h.ah = 0x08;                  /* otherwise, go get the next one */
    int86 (0x21, &regs, &regs);

    if (regs.h.al == 0x08) {
        if (Bufsub == 0) return;
        scsub = (Screen_Rows - 1) * 80 + Bufsub;
        Screen[scsub].Character = 0x20;
        Screen[scsub].Attribute = INPUT_COLOR;
        Screen[scsub - 1].Character = '_';
        Screen[scsub - 1].Attribute = INPUT_COLOR;
        Bufsub--;
        return;
        }

    if (regs.h.al == 0x0D) {
        if (Buffer[0] == '\\') {
            Execute_Command (Buffer);
            Screen_ClearLast ();
            Clear_Buffer ();
            scsub = (Screen_Rows - 1) * 80;
            Screen[scsub].Character = '_';
            Screen[scsub].Attribute = INPUT_COLOR;
            return;
            }
        Buffer [Bufsub] = 0x00;
        Setup_Send (MESSAGE_CODE, Buffer);
        Screen_ClearLast ();
        Clear_Buffer ();
        scsub = (Screen_Rows - 1) * 80;
        Screen[scsub].Character = '_';
        Screen[scsub].Attribute = INPUT_COLOR;
        return;
        }

    if (regs.h.al == 0x00) {
        regs.h.ah = 0x08;
        int86 (0x21, &regs, &regs);
        switch (regs.h.al) {
            case 59:
                Execute_Command ("\\HELP");
                return;
            case 60:
                Execute_Command ("\\TRACE");
                return;
            case 61:
                Execute_Command ("\\WHO");
                return;
            }
        return;
        }

    if (regs.h.al == 0x1B) {
        Execute_Command ("\\EXIT");
        return;
        }

    if (regs.h.al < 0x20) return;

    Buffer [Bufsub] = regs.h.al;
    scsub = (Screen_Rows - 1) * 80 + Bufsub;
    Screen[scsub].Character = regs.h.al;
    Screen[scsub].Attribute = INPUT_COLOR;
    if (Bufsub < 78) {
        Bufsub++;
        }
    Screen[scsub + 1].Character = '_';
    Screen[scsub + 1].Attribute = INPUT_COLOR;
    return;
    }


/**********************************************************************
  This routine is a simple way to control the invocation of the other
  various poll routines.  It really does nothing, in and of itself,
  other than calling the Relinquish IPX function, so that IPX can get
  some CPU time.
**********************************************************************/

void poll (void) {
    union REGS regs;

    Poll_Key ();
    Poll_Net ();
    IPX_Relinquish_Control ();
    return;
    }
/*******************************************************************

  IPXLIB.C V1.00
  Copyright (c) 1992 by Kurt Duncan - All Rights Reserved

  Library of functions based on the Novell IPX transport mechanism

*******************************************************************/


#include <dos.h>
#include "ipxlib.h"


/***********************************************************************
  IPX_Is_Loaded
***********************************************************************/

unsigned int IPX_Is_Loaded (void) {
    union  REGS regs;

    regs.x.ax = 0x7A00;
    int86 (0x2F, &regs, &regs);
    if (regs.h.al != 0xFF) return (0);
    return (1);
    }


/***********************************************************************
  IPX_Open_Socket
***********************************************************************/

unsigned int IPX_Open_Socket (unsigned int Socket_Number) {
    union REGS regs;

    regs.x.bx = 0x00;    /* IPX function 00h */
    regs.h.al = 0x00;    /* Longevity code 00h (close at end of pgm) */
    regs.x.dx = IPX_Flipword (Socket_Number);
    int86 (0x7A, &regs, &regs);
    return (regs.h.al);
    }


/***********************************************************************
  IPX_Close_Socket
***********************************************************************/

void IPX_Close_Socket (unsigned int Socket_Number) {
    union REGS regs;

    regs.x.bx = 0x01;    /* IPX function 01h */
    regs.x.dx = IPX_Flipword (Socket_Number);
    int86 (0x7A, &regs, &regs);
    return;
    }


/***********************************************************************
  IPX_Get_Local_Target
***********************************************************************/

unsigned int IPX_Get_Local_Target (struct IPX_address far *Destination,
                                   struct IPX_node    far *Target) {
    union  REGS regs;
    struct SREGS sregs;

    segread (&sregs);
    regs.x.bx = 0x02;
    sregs.es  = FP_SEG (Destination);
    regs.x.si = FP_OFF (Destination);
    regs.x.di = FP_OFF (Target);
    int86x (0x7A, &regs, &regs, &sregs);
    return (regs.x.cx);
    }


/***********************************************************************
  IPX_Send_Packet
***********************************************************************/

void IPX_Send_Packet (IPX_ECB far *ECB) {
    union  REGS regs;
    struct SREGS sregs;

    segread (&sregs);
    regs.x.bx = 0x03;
    sregs.es  = FP_SEG (ECB);
    regs.x.si = FP_OFF (ECB);
    int86x (0x7A, &regs, &regs, &sregs);
    return;
    }


/***********************************************************************
  IPX_Listen_For_Packet
***********************************************************************/

void IPX_Listen_For_Packet (IPX_ECB far *ECB) {
    union  REGS regs;
    struct SREGS sregs;

    segread (&sregs);
    regs.x.bx = 0x04;
    sregs.es  = FP_SEG (ECB);
    regs.x.si = FP_OFF (ECB);
    int86x (0x7A, &regs, &regs, &sregs);
    return;
    }


/***********************************************************************
  IPX_Cancel_Event
***********************************************************************/

void IPX_Cancel_Event (IPX_ECB far *ECB) {
    union  REGS regs;
    struct SREGS sregs;

    segread (&sregs);
    regs.x.bx = 0x06;
    sregs.es  = FP_SEG (ECB);
    regs.x.si = FP_OFF (ECB);
    int86x (0x7A, &regs, &regs, &sregs);
    return;
    }


/***********************************************************************
  IPX_Get_Internetwork_Address
***********************************************************************/

void IPX_Get_Internetwork_Address (struct IPX_address far *Address) {
    union  REGS regs;
    struct SREGS sregs;

    segread (&sregs);
    regs.x.bx = 0x09;
    sregs.es  = FP_SEG (Address);
    regs.x.si = FP_OFF (Address);
    int86x (0x7A, &regs, &regs, &sregs);
    return;
    }


/***********************************************************************
  IPX_Relinquish_Control
***********************************************************************/

void IPX_Relinquish_Control (void) {
    union REGS regs;

    regs.x.bx = 0x0A;
    int86 (0x7A, &regs, &regs);
    return;
    }


/***********************************************************************
  IPX_Flipword
***********************************************************************/

unsigned int IPX_Flipword (unsigned int Inword) {
    unsigned char c1, c2;

    c1 = Inword >> 8;
    c2 = Inword & 0xFF;
    return ( (unsigned int) (c2 << 8) | c1);
    }


/**********************************************************************
  This is where execution starts.  We print the processor name, then
  call the Initialization function.  If the function returns zero
  (false) indicating an error condition, we just quit.  Otherwise,
  we clear the All_Done flag, then call the poll routine until the
  All_Done flag is non-zero.  At that point, we call the Termination
  function, then we return to DOS.  (Actually, to the C startup code,
  but that is a different story).
**********************************************************************/
CLIPPER CONVERSAR() {
    char *nombre;
    ECBPointer= (IPX_ECB*) _parc(2);
    IPXHPointer= (IPX_header*) _parc(3);
    if (_parc(1)!=NULL) {
       nombre=_parc(1);
    }
    printf ("%s\n", PROCESSOR_NAME);
    if (Initialization (nombre) == 0x00) _ret();
    All_Done = 0;
    while (!(All_Done))
        poll ();
    Termination ();
    _ret();
    }

