#define cursor(x,y) gotoxy(y,x)
#define cursor_on() setcursor(6,7);
#define cursor_off() setcursor(0x20,0x20);
#define miprintf(x1, x2, c) _miprintf(x1,x2,c,strlen(c))
volatile int tinta_global=15;
volatile int papel_global=1;
volatile int ult_cursorx = 1;
volatile int ult_cursory = 1;
volatile int salva_tinta, salva_papel;


void _miprintf(byte x1, byte x2,char *cadena, int l)
{
   unsigned char far *pantalla;
   int atributo;
   x1--;
   x2--;
   atributo=papel_global*16+tinta_global;

   if (is_color()) {
      pantalla=MK_FP(0xb800,0);
   } else {
      pantalla=MK_FP(0xb000,0);
   }
   while ((*cadena) && (l--)) {
      pantalla[x1*160+2*x2]=*cadena;
      pantalla[x1*160+2*x2+1]=atributo;
      cadena++;
      x2++;
   }
}

void printchar(byte x1,byte x2, char c)
{
   char *p;
   p=&c;
   _miprintf(x1,x2,p,1);
}
void color(int tinta,int papel)
{
   textcolor(tinta);
   textbackground(papel);
   textattr(papel*16+tinta);
   tinta_global=tinta;
   papel_global=papel;
}
void salva_color(void)
{
   salva_tinta=tinta_global;
   salva_papel=papel_global;
}
unsigned char pulsada_tecla(byte c)
{
   if (kbhit()) {
      return(getch()==c);
   } else {
      return(0);
   }
}
void sombra(int x1,int y1,int x2,int y2)
{
   unsigned char far *pantalla;
   int i,j;

   x1--;
   x2--;
   y1--;
   y2--;
   if (is_color()) {
      pantalla=MK_FP(0xb800,0);
   } else {
      pantalla=MK_FP(0xb000,0);
   }
   for (i=x1;i<=x2;i++) {
      for (j=y1;j<=y2;j++) {
	 pantalla[i*160+2*j+1]=(pantalla[i*160+2*j+1]) % 8;
      }
   }
}
void restaura_color(void)
{
   color(salva_tinta, salva_papel);
}
void restaura_cursor(void)
{
   gotoxy(ult_cursorx,ult_cursory);
}
void restaura_conf_pant(void)
{
   restaura_color();
   restaura_cursor();
}
void mover_bloque(void *src, void *dest, unsigned lenght)
{
   char *s,*d;
   s=src;
   d=dest;
   while(lenght--) {
      *d++=*s++;
   }
}
void salva_cursor(void)
{
   ult_cursorx=wherex();
   ult_cursory=wherey();
}
void salva_conf_pant(void)
{
   salva_color();
   salva_cursor();
}
void ccuadro(x1,y1,x2,y2,tinta,papel)
{
   char  doble[] = "�������������������������������������������������������������������������������";
   char blanco[] = "                                                                               ";
   char buff_doble[80], buff_blanco[80];
   int i,ant_tinta,ant_papel;
   unsigned char far *_pantalla;

   if (is_color()) {
      _pantalla=MK_FP(0xb800,0);
   } else {
      _pantalla=MK_FP(0xb000,0);
   }
   salva_conf_pant();
   buff_doble[y2-y1]='\0';
   buff_blanco[y2-y1]='\0';
   mover_bloque(doble,buff_doble,y2-y1-1);
   buff_doble[y2-y1-1]=0;
   mover_bloque(blanco,buff_blanco,y2-y1-1);
   buff_blanco[y2-y1-1]=0;
   color(BLACK,papel);
   cursor(x1,y1);
   printchar(x1,y1,'�');
   miprintf(x1,y1+1,buff_doble);
   color(tinta,papel);
   printchar(x1,y2,'�');
   for(i=x1+1;i<x2;i++) {
      color(BLACK,papel);
      cursor(i,y1);
      printchar(i,y1,'�');
      color(tinta,papel);
      miprintf(i,y1+1,buff_blanco);
      printchar(i,y2,'�');
   }
   color(BLACK,papel);
   printchar(x2,y1,'�');
   color(tinta,papel);
   miprintf(x2,y1+1,buff_doble);
   _pantalla[(x2-1)*160+(y2-1)*2]='�';
   _pantalla[(x2-1)*160+(y2-1)*2+1]=papel*16+tinta;
   restaura_conf_pant();
}
void crecuadro(int x1,int y1,int x2,int y2,int tinta, int papel)
{
   ccuadro(x1,y1,x2,y2,tinta,papel);
   sombra(x2+1,y1+2,x2+1,y2);
   sombra(x1+1,y2+1,x2+1,y2+2);
}
void mayusculas(char *cadena)
{
   while (*cadena) {
      *cadena++=toupper(*cadena);
   }
}
int is_color()
{
   _AH=0x12;
   _BL=0x10;
   geninterrupt(0x10);
   return(_BH==0);
}
unsigned char isprinter(void)
{
  union  REGS    regs;

  regs.x.dx = 0x00;
  regs.h.ah = 0x2;
  int86(0x17,&regs,&regs);
  if (regs.h.ah!=0x90) {
     return(FALSE);
  } else {
     return(TRUE);
  }
}

byte imp_ok(void)
{
  char  tecla;
  tecla=32;
  if (!isprinter()) {
     salva_color();
     crecuadro(10,11,14,69,YELLOW,RED);
     color(YELLOW,RED);
     miprintf(11,13,"La Impresora no est� preparada compruebe que hay papel");
     miprintf(12,13,"    y que est� 'ON-LINE'. Pulse entonces una tecla.   ");
     miprintf(13,13,"                   [Esc]=> Salir");
     while ((!isprinter()) && (tecla!=27)) {
	tecla=getch();
	if (tecla==0) {
	   tecla=getch();
	}
     }
     restaura_color();
  }
  return(tecla);
}


void setcursor(int inicio, int fin)
{
   _AH = 0X1;
   _CH = inicio;
   _CL = fin;
   geninterrupt(0x10);
}