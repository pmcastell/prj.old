/* programa LISTALMA.C. (c) 1992 Francisco Javier Criado Navarro */
/*=> realiza NUM_LISTADOS para las Jefaturas Provincia-
les y Empresas de Control, con los resultados medios por almac�n de aqu�llos
que est�n en territorio de su provincia de competencia.
Para ello debe haber un fichero llamado LISTADO.LST, que contenga los an�li-
sis globales de la semana en curso, del cual se ir�n extrayendo los resulta-
dos parciales que afecten a las distintas entidades nombradas.
Este fichero es cargado en una tabla bidimensional, cuyo primer �ndice co --
rresponde a la factor�a y el segundo al almac�n.
Para hacer los distintos listados se dispone de una tabla de registros uno
de cuyos campos consiste en un array que contiene una lista de los almacenes
que van en el listado de esa entidad. Cada registro se corresponde con una
entidad y un listado.*/



#include <stdio.h>
#include <string.h>
#include <alloc.h>
#include <francisc.h>

#define NUM_FACTORIAS 33
#define NUM_ALMACENES 20
#define NUM_LISTADOS   3
#define MAX_ALMACENES 55
#define MARGEN "" /* margen izquierdo en listados */
#define isdigito(x) (((unsigned)(x)>47) && ((unsigned)(x)<58))
/* prototipos */
/*int incluida(unsigned char *cadena1,unsigned char *cadena2);???*/
int incluida(char *cadena1,char *cadena2);
void inicializa(void);
void procesafichero(void);
void cabecera(int n_listado);
void lista(void);
/******************************************/
#define salidafichero
#ifdef salidafichero
   FILE *salida;
#else
   #define salida stdprn
#endif

typedef struct informe {
       char *titulo;
       int almacenes[MAX_ALMACENES];
       /*int n_almacenes;*/
       }informe;

char *fich_listado[NUM_FACTORIAS][NUM_ALMACENES],*fecha;
char fichero_a_procesar[13];

informe listados[NUM_LISTADOS]={
	       {"\0332 LISTADO PARA LA EMPRESA DE CONTROL COMISMAR CONTROL, S.A.",
		{ 200, 300, 301, 302, 303, 500, 501, 502, 503,1100,1700,1901,
		 2301,2400}
	       },
	       {"\0332 LISTADO PARA LA EMPRESA DE CONTROL INTERVALORA-DESUR",
		{ 606, 900, 901, 905, 906, 908,1105,1200,1203,1204,1205,1300,
		 1301,1302,1303,1304,1305,1307,1400,1600,1602,1603,1800,2800,
		 2801,2802,2901,3000,3003,3004,3200}
	       },
	       {"\0332 LISTADO PARA LA EMPRESA DE CONTROL L.V.SALAMANCA INGENIEROS,S.A.",
		{ 600, 700, 702, 703, 704, 800, 907,1000,1201,1202,1306,1604,
		 1900,2000,2100,2300,2500,2600,2700,2900,3001,3002}
	       },
};
int margen_izquierdo;
static char t[7][100]=
   {"������������������������������������������������������������������������ͻ"
   ,"�Al- �N�  �     �     Humedad      �    Impurezas     �   Rendimiento    �"
   ,"�ma- �de  �     ��������������������������������������������������������͹"
   ,"�cene�Acts�Dias �Acta �Labo.� Dif. �Acta �Labo.� Dif. �Acta �Labo.� Dif. �"
   ,"������������������������������������������������������������������������͹"
   ,"�    �    �     �     �     �      �     �     �      �     �     �      �"
   ,"������������������������������������������������������������������������ͼ"
};



#include "..\mios\inc.c"
void inicializa(void)
{
   int i,j;

   for (i=0;i<=NUM_FACTORIAS;i++) {
      for (j=0;j<=NUM_ALMACENES;j++) {
	 fich_listado[i][j]=NULL;
      endfor
   endfor
endfunc

void inserta_espacios(int n,char *c)
{
   char *p;
   int i;


   p=(char *) malloc(n+1+strlen(c));
   for(i=0;i<n;i++) {
      p[i]=' ';
   }
   p[n]='\0';
   strcat(p,c);
   strcpy(c,p);
   free(p);
}

   

void abrir_fichero(FILE **fichero,char *nombre,char *tipo)
{
   (*fichero)=fopen(nombre,tipo);
   if ((*fichero) == NULL) {
      printf("Error: no se encuentra el fichero %s",nombre);
      exit(0);
   endif
}

void procesafichero(void)
{
   FILE *fich_entrada;
   char linea[256],cod_alma[5];
   int cont,facto,alma,factoalma,i;

   abrir_fichero(&fich_entrada,fichero_a_procesar,"r");

   while (fgets(linea,256,fich_entrada) != NULL &&
	  strstr(linea,"DESDE:") == NULL);
   fecha=(char *) malloc(sizeof(linea));
   strcpy(fecha,linea);
   while (fgets(linea,256,fich_entrada)!= NULL &&
	   !(margen_izquierdo=incluida("�",linea)));
   margen_izquierdo-=2;
   for(i=0;i<=6;i++) {
      inserta_espacios(margen_izquierdo,t[i]);
   }
   fclose(fich_entrada);
   abrir_fichero(&fich_entrada,fichero_a_procesar,"r");
   while (fgets(linea,256,fich_entrada) != NULL) {
      for (cont=0;cont<4;cont++) {
	cod_alma[cont]=linea[2+margen_izquierdo+cont];
      endfor
      cod_alma[4]='\0';
      if ( (factoalma= atoi(cod_alma) ) > 99) {
	 facto= factoalma/100;
	 alma = factoalma - facto*100;
	 fich_listado[facto][alma] = malloc(strlen(linea)+1);
	 strcpy(fich_listado[facto][alma],linea);
	 {
	 int h;
	 h=strlen(linea);
	 fich_listado[facto][alma][h-1]='\0';
	 }
      endif
   endwhile
   fclose(fich_entrada);
endfunc

void cabecera(int n_listado)
{
   
   fprintf(salida,"\033M\017\015\012\015\012");
   fprintf(salida,"%s CORRECCION DE PARAMETROS (DATOS DEL CENTRO DE ANALISIS DE ALGODON - INSTITUTO TECNOLOGICO DEL TABACO DE SEVILLA) \015\n",MARGEN);
   fprintf(salida,"\022%s%s  \n",MARGEN,listados[n_listado].titulo);
   fprintf(salida,"%s%s  \n",MARGEN,fecha);
   fprintf(salida,"%s %s\n",MARGEN,t[0]);
   fprintf(salida,"%s %s\n",MARGEN,t[1]);
   fprintf(salida,"%s %s\n",MARGEN,t[2]);
   fprintf(salida,"%s %s\n",MARGEN,t[3]);
   fprintf(salida,"%s %s\n",MARGEN,t[4]);
   fprintf(salida,"%s %s\n",MARGEN,t[5]);

   printf("%s\n",listados[n_listado].titulo);
   printf("                               CORRECCION DE PARAMETROS (DATOS DEL INSTITUTO TECNOLOGICO DEL TABACO DE SEVILLA) \n");
   printf("%s\n",t[0]);
   printf("%s\n",t[1]);
   printf("%s\n",t[2]);
   printf("%s\n",t[3]);
   printf("%s\n",t[4]);
   printf("%s\n",t[5]);
endfunc


void lista(void)
{
   int i,j,k;
   int facto,ulfacto,alma;

   if (i=incluida(".",fichero_a_procesar)) {
      fichero_a_procesar[i]='a';
      fichero_a_procesar[i+1]='l';
      fichero_a_procesar[i+2]='m';
      fichero_a_procesar[i+3]='\0';
   }
      
#ifdef salidafichero
   abrir_fichero(&salida,fichero_a_procesar,"w");
#endif
   for (i=0;i<NUM_LISTADOS;i++) {
      cabecera(i);
      ulfacto=listados[i].almacenes[0]/100;
      j=0;
      while (listados[i].almacenes[j] != 0) {
	 alma=listados[i].almacenes[j];
	 facto=alma/100;
	 alma-=facto*100;
	 if (fich_listado[facto][alma] != NULL) {
	    if (ulfacto != facto) {
	       fprintf(salida,"%s %s\n",MARGEN,t[5]);
	       printf("  %s\n",t[5]);
	    endif
	    fprintf(salida,"%s%s\n",MARGEN,fich_listado[facto][alma]);
	    printf("%s\n",fich_listado[facto][alma]);
            ulfacto=facto;
	 endif
	 j++;
      endwhile
      fprintf(salida,"%s %s\014\n",MARGEN,t[6]);
      printf(" %s\014\n",t[6]);
   endfor
#ifdef salidafichero
   fclose(salida);
#endif
endfunc





void main(int argv,char *argc[])
{
   if (argv<1) {
      printf("\nError. Falta par�metro");
   } else {
      strcpy(fichero_a_procesar,argc[1]);
   }
   minombre("Listalma");
   inicializa();
   procesafichero();
   lista();
   minombre("Listalma");
endfunc