#define PARACLIPPER
#include <stdio.h>
#ifndef PARACLIPPER
   #include <stdlib.h>
#endif
#include <dir.h>
#include <io.h>
#include <mem.h>
#include <conio.h>
#include <ctype.h>
#include <dos.h>
#include <fcntl.h>
#include <string.h>
#include "extend.h"
#include "leetext.h"
#include "leet_fun.c"



   word far *pantalla;
   reg_pantalla *buf_pant;
   byte *lbuffer;

/*   byte buffer[TAM_BLOQUE];
   reg_pantalla _buf_pant;*/

   unsigned long pbuffer;
   unsigned long fbuffer;
   unsigned long ppant;
   unsigned long fpant;
   unsigned long tamano;
   int bytes_leidos;
   int handle_fichero;
   unsigned char tecla;
   int columna;
   int tinta, papel;
   word palabra;
   unsigned long contador;
   byte blanco[LONGITUD_LINEA*2];
   vectint interrupciones[256];
   vectint salva_interrupcion;
   struct ffblk dirinfo;
   string cadena_buscada;
   byte print;
   int err;
   unsigned long desp_ayuda;
   unsigned long s_ppant,s_pbuffer;
   unsigned char fin_fichero;
   int primera_columna,
   ultima_columna,
   primera_linea,
   ultima_linea;
   string fichero_a_leer, f,dir;

void reloj_activa(void)
{
}
void reloj_desactiva(void)
{
}
void reloj_init(int x, int y)
{
   x=y;
   y=x;
}



void leerbloque(unsigned long num)
{
   seek(handle_fichero,pbuffer);
   _read(handle_fichero, lbuffer,num);
   fbuffer=tell(handle_fichero)-1;
}

int num_lineas(void)
{
   return(ultima_linea-primera_linea+1);
}

int num_columnas(void)
{
   return(ultima_columna-primera_columna+1);
}
void limpia_pant(void)
{
   int cont;
   for (cont=primera_linea;cont<=ultima_linea;cont++) {
      movmem(blanco,&(buf_pant->pant[cont][1]),(LONGITUD_LINEA-1)*2);
   }
}

void mostrar(void)
{
   int  x, y;
   for (x=primera_linea; x<=ultima_linea;x++)  {
       movmem(&(buf_pant->pant[x][columna]),pantalla + x*80+primera_columna,2*num_columnas());
   }
}

void titulos(void)
{
   int i,j;
   char aux[256];

   salva_color();
   color(MENS_TINTA,MENS_PAPEL);
   miprintf(1,1,"  Leetext (c) 1992-96 F.J.Criado �                                    ");
   /*miprintf("  Leetext (c) 1992 - F.J.Criado � Fecha: %s  � Hora:                     ",fecha());*/
   strcpy(aux,"�F1 = Ayuda�");
   strcat(aux,dir);
   strcat(aux,fichero_a_leer);
   j=strlen(aux);
   for (i=1; i<=66-strlen(dir)-strlen(fichero_a_leer);i++) {
      aux[j]=' ';
      j++;
   }
   aux[j]='\0';
   miprintf(25,1,aux);
/*   for (i=1;i<=66-strlen(dir)-strlen(fichero_a_leer);i++) {
      miprintf(wherey()+i,wherex()," ");
   }*/
}

void cambia_tinta(void)
{
   byte  co;
   int  cont;

   reloj_desactiva();
   tinta++;
   tinta%=16;
   titulos();
   co=papel*16+tinta;
   for (cont=0;cont<=LONGITUD_LINEA-1;cont++)  {
      blanco[2*cont]=32;
      blanco[2*cont+1]=co;
   }
   reloj_activa();
}

void cambia_papel(void)
{
   byte co;
   int cont;

   reloj_desactiva();
   papel++;
   papel%=8;
   titulos();
   co=papel*16+tinta;
   for (cont=0;cont<=LONGITUD_LINEA-1;cont++)  {
      blanco[2*cont]=32;
      blanco[2*cont+1]=co;
   }
   reloj_activa();
}


void bloque_sig(unsigned long cont)
{
   while ((cont>fbuffer) && (fbuffer<tamano)) {
      pbuffer=pbuffer+MEDIO_BLOQUE;
      leerbloque(TAM_BLOQUE);
  }
}

void actualiza_pos(void)
{
    byte caracter;
    int fil;
    int col;
    unsigned long cont;

   cont=ppant;
   fil=primera_linea;
   limpia_pant();
   while ((cont<=tamano) && (fil<=ultima_linea))  {
      col=1;
      caracter=lbuffer[cont-pbuffer];
      while ((cont<=tamano) && (caracter!=13) && (caracter!=10)
			  && (col<LONGITUD_LINEA))  {
	 buf_pant->pant[fil][col][0]=caracter;
	 cont++;
	 col++;
         bloque_sig(cont);
	 caracter=lbuffer[cont-pbuffer];
      }
      (buf_pant->longitudes)[fil]=col-1;
      if ((lbuffer[cont-pbuffer]==13) && (lbuffer[cont-pbuffer+1]==10)) {
	 cont+=2;
      } else if ((lbuffer[cont-pbuffer]==13) || (lbuffer[cont-pbuffer]==10)) {
	 cont++;
      }
      bloque_sig(cont);
      fil++;
   }
   if (fil<ultima_linea)  {
      fin_fichero=TRUE;
   }
   fpant=cont-1;
}

void actualiza_pant(void)
{
   actualiza_pos();
   mostrar();
}

void ctrlrepag(void)
{
   ppant=0;
   pbuffer=0;
   leerbloque(TAM_BLOQUE);
   actualiza_pant();
}

void bloque_ant(unsigned long cont)
{
   while ((cont<=pbuffer) && (pbuffer>=MEDIO_BLOQUE))  {
       pbuffer=pbuffer-MEDIO_BLOQUE;
       leerbloque(TAM_BLOQUE);
    }
}

void repag(void)
{
   int contador, i;

   if (ppant>0)  {
       contador=0;
       if ((lbuffer[ppant-pbuffer-1]==10) && (lbuffer[ppant-pbuffer-2]==13)) {
	  ppant-=2;
       } else if ((lbuffer[ppant-pbuffer-1]==10) ||
		 (lbuffer[ppant-pbuffer-1]==13)) {
	  ppant--;
       }
       while ((ppant>0) && (contador<num_lineas()-1))  {
	 ppant--;
	 bloque_ant(ppant);
	 i=1;
	 while ((ppant>0) && (lbuffer[ppant-pbuffer]!=10)
			 && (i<LONGITUD_LINEA))  {
	    ppant--;
	    i++;
            bloque_ant(ppant);
	 }
	 contador++;
       }
       if (ppant>0)  {
	  ppant++;
       }
       actualiza_pant();
    }
}

void ctrlavpag()
{
   int i;

   ppant=tamano;
   i=1;
   pbuffer=(ppant/MEDIO_BLOQUE)*MEDIO_BLOQUE;
   leerbloque(TAM_BLOQUE);
   if ((lbuffer[ppant-pbuffer]==10) && (lbuffer[ppant-pbuffer]==13)) {
      ppant-=2;
   } else if ((lbuffer[ppant-pbuffer]==10) || (lbuffer[ppant-pbuffer]==13) ||
	     (lbuffer[ppant-pbuffer]==26)) {
      ppant--;
   }
   while ((lbuffer[ppant-pbuffer]!=10) && (i<LONGITUD_LINEA))  {
      ppant--;
      i++;
   }
   if (lbuffer[ppant-pbuffer]==10) {
      ppant++;
   }
   repag();
}

void arriba(void)
{
   int i,r=0;
   unsigned long cont;

   if (ppant>2)  {
      if ((lbuffer[fpant-1-pbuffer]==13) &&
	  (lbuffer[fpant-pbuffer]==10)) {
	 fpant=fpant-buf_pant->longitudes[ultima_linea]-2;
      } else if ((lbuffer[fpant-pbuffer]==10) || (lbuffer[fpant-pbuffer]==13)) {
	 fpant=fpant-buf_pant->longitudes[ultima_linea]-1;
      } else {
	 fpant=fpant-buf_pant->longitudes[ultima_linea];
      }
      for (i=ultima_linea;i>=primera_linea+1;i--) {
	 movmem(&(buf_pant->pant[i-1]),&(buf_pant->pant[i]),sizeof(micadena)-2);
	 buf_pant->longitudes[i]=buf_pant->longitudes[i-1];
      }
      movmem(blanco,&(buf_pant->pant[primera_linea][1]),(LONGITUD_LINEA-1)*2);
      cont=ppant;
      if (lbuffer[cont-pbuffer-1]==10) {
	 cont--;
	 r++;
      }
      if (lbuffer[cont-pbuffer-1]==13) {
	 cont--;
	 r++;
      }
      bloque_ant(cont);
      i=1;
      while ((cont>0) && (lbuffer[cont-pbuffer-1]!=10) &&
	     (lbuffer[cont-pbuffer-1]!=13) && (i<LONGITUD_LINEA))  {
	 cont--;
	 i++;
         bloque_ant(cont);
      }
      for (i=1; i<= ppant-cont-r;i++)  {
	 buf_pant->pant[primera_linea][i][0]=lbuffer[cont-pbuffer+i-1];
      }
      buf_pant->longitudes[primera_linea]=ppant-cont-r;
      ppant=cont;
      mostrar();
   }
}

int avanza_linea()
{
   int i;
   unsigned long cont;
   cont=fpant;
   if ((lbuffer[cont-pbuffer]==13) || (lbuffer[cont-pbuffer]==10)) {
      cont++;
   }
   if (fpant<tamano)  {
      ppant+=buf_pant->longitudes[primera_linea];
      if ((lbuffer[ppant-pbuffer]==13) && (lbuffer[ppant-pbuffer+1]==10)) {
	ppant+=2;
      } else if ((lbuffer[ppant-pbuffer]==13) || (lbuffer[ppant-pbuffer]==10)) {
	ppant++;
      }
      for (i=primera_linea; i<=ultima_linea-1; i++)  {
	  movmem(&(buf_pant->pant[i+1]),&(buf_pant->pant[i]),sizeof(micadena)-2);
	  buf_pant->longitudes[i]=buf_pant->longitudes[i+1];
      }
      i=1;
      bloque_sig(cont);
      movmem(blanco,&(buf_pant->pant[ultima_linea][1]),(LONGITUD_LINEA-1)*2);
      while ((lbuffer[cont-pbuffer]!=13) && (lbuffer[cont-pbuffer]!=10)
	     && (cont<=tamano) && (i<LONGITUD_LINEA))  {
	 buf_pant->pant[ultima_linea][i][0]=lbuffer[cont-pbuffer];
	 i++;
	 cont++;
         bloque_sig(cont);
      }
      buf_pant->longitudes[ultima_linea]=i-1;
      if ((lbuffer[cont-pbuffer]==13)  && (lbuffer[cont-pbuffer+1]==10)) {
	 fpant=cont+1;
      } else if (cont<tamano) {
	 fpant=cont;
      } else {
	 fpant=tamano;
      }
      return(TRUE);
   } else {
      return(FALSE);
   }
}

int abajo(void)
{
   if (avanza_linea())  {
      mostrar();
      return(FALSE);
   } else {
      return(TRUE);
   }
}

void avpag(void)
{
   int i;

   if (fpant<tamano)  {
      ppant=fpant-buf_pant->longitudes[ultima_linea]-1;
      actualiza_pos();
      if (fpant>=tamano) {
	 ctrlavpag();
      }
      mostrar();
   }
}





void izquierda(word n)
{
  if (columna>n)  {
    columna=columna-n;
    mostrar();
  } else {
    if (columna>1)  {
       columna=1;
       mostrar();
    } else {
       sound(2180);
       delay(10);
       nosound();
    }
  }
}

void derecha(word n)
{
   if (columna<LONGITUD_LINEA-ultima_columna+primera_columna-n) {
      columna=columna+n;
      mostrar();
   } else {
      if (columna<LONGITUD_LINEA-ultima_columna+primera_columna)  {
	 columna=LONGITUD_LINEA-ultima_columna+primera_columna;
      } else {
	 sound(2180);
	 delay(10);
	 nosound();
      }
   }
}

void inicio(void)
{
   if (columna>1)  {
      columna=1;
      actualiza_pant();
   }
}

void fin()
{
   unsigned long  cont;

   cont=ppant-pbuffer;
   while ((lbuffer[cont]!=13) && (lbuffer[cont]!=10)) {
      cont++;
   }
   if (cont-(ppant-pbuffer)>75)  {
      columna=cont-(ppant-pbuffer)-75;
      actualiza_pant();
   }
}



void  seguir_buscando(void)
{
    int longitud, i;
    boolean noencontrado;
    unsigned long contador2;
    string p;

   reloj_desactiva();
   salva_color();
   color(MENS_TINTA+BLINK,MENS_PAPEL);
   longitud=strlen(cadena_buscada);
   miprintf(25,1,"Buscando: ");
   miprintf(25,11,cadena_buscada);
   for (i=1;i<=69-strlen(cadena_buscada);i++) {
      printchar(25,11+strlen(cadena_buscada),' ');
   }
   contador=ppant;
   noencontrado=TRUE;
   while ((contador<tamano) && (noencontrado) && (!pulsada_tecla(27)))  {
      if (contador>fbuffer)  {
	 pbuffer+=TAM_BLOQUE;
	 leerbloque(TAM_BLOQUE);
      }
      if (toupper(lbuffer[contador-pbuffer])==cadena_buscada[0]) {
	 contador2=contador+1;
	 noencontrado=FALSE;
	 while ((contador2<contador+longitud) && (!noencontrado)) {
	    if (contador2>fbuffer)  {
	       pbuffer=contador;
	       leerbloque(TAM_BLOQUE);
	    }
	    if (toupper(lbuffer[contador2-pbuffer])!=cadena_buscada[contador2-contador]) {
	       noencontrado=TRUE;
	    }
	    contador2=contador2+1;
	 }
      }
      contador++;
   }
   if (noencontrado)  {
      ppant=s_ppant;
      pbuffer=s_pbuffer;
      leerbloque(TAM_BLOQUE);
      miprintf(25,1,"             Texto no encontrado, pulse una tecla para continuar            ");
      while (!kbhit());
   } else {
      ppant=contador;
      while ((lbuffer[ppant-pbuffer]!=10) && (ppant-pbuffer>0)) {
	 ppant--;
      }
      ppant++;
   }
   restaura_color();
   titulos();
   actualiza_pant();
   reloj_activa();
}
int lee(int x,int y, char *mensaje, char *cadena, int lon)
{
   int i, max, cont;
   char tecla;

   cursor_off();
   lon--;
   gotoxy(x,y);
   miprintf(y,x,mensaje);
   color(BLACK,LIGHTGRAY);
   x=x+strlen(mensaje);
   gotoxy(x,y);
   for (i=0; i<=lon; i++) {
      printchar(y,x+i,' ');
   }
   gotoxy(x,y);
   if (strlen(cadena)>0) {
      miprintf(y,x,cadena);
      i=strlen(cadena);
      max=i-1;
   } else {
      i=0;
      max=0;
   }
   while ((tecla=getch()) != 13) {
      switch(tecla) {
         case 8: {                     /* retroceso */
            if (i>0) {
               i--;
	       if (i<=max+1) {
		  miprintf(y,x+i,&cadena[i+1]);
		  for (cont=i; cont<=max; cont++) {
		     cadena[cont]=cadena[cont+1];
		  }
		  max--;
	       }
               gotoxy(x+i,y);
	       printchar(y,x+i,' ');
	    }
	    break;
	 }
	 case 0: {
	    tecla= getch();
	    switch(tecla) {
	       case 75: {           /* izquierda */
		  if (i>0) {
		     i--;
		     gotoxy(x+i,y);
		  }
		  break;
	       }
	       case 77: {           /* derecha */
		  if (i<lon) {
		     i++;
		     gotoxy(x+i,y);
		  }
		  break;
	       }
	       case 71: {           /* inicio  */
		  i=0;
		  gotoxy(x+i,y);
		  break;
	       }
	       case 79: {           /* fin */
		  if (max<lon) {
		     i=max+1;
		  } else {
		     i=max;
		  }
                  gotoxy(x+i,y);
                  break;
               }
               case 83: {           /* suprimir */
		  if (i<=max) {
		     miprintf(y,x+i,&cadena[i+1]);
		     for (cont=i; cont<=max-1; cont++) {
			cadena[cont]=cadena[cont+1];
		     }
		     cadena[cont]='\0';
                     max--;
		     printchar(y,x+cont,' ');
		     gotoxy(x+i,y);
		  }
	       }
	    }
	    break;
	 }
         case 27: {
            return(0);
         }
         default: {
	    if (i<=lon) {
	       printchar(y,x+i,tecla);
	       gotoxy(x+i+1,y);
	       cadena[i]=tecla;
               if (i>max) {
                  max=i;
               }
               i++;
            } else {
               sound(100);
               delay(200);
               nosound();
            }
         }
      }
   }
   cadena[max+1]='\0';
   return(1);
}
void buscar(void)
{
   s_ppant=ppant;
   s_pbuffer=pbuffer;
   
   if (!lee(1,25,"Cadena a buscar: ",cadena_buscada,61))  {
      titulos();
      actualiza_pant();
      return;
   }
   mayusculas(cadena_buscada);
   seguir_buscando();
}

/*procedure buscar;
var  cadena2: string;
   {
      reloj.desactiva;
      if not lee(1,25,'Cadena a buscar:',cadena_buscada,61) then {
         titulos;
         reloj.activa;
         actualiza_pant;
         exit
      }
      a:=ppant;
      b:=fpant;
      c:=pbuffer;
      d:=fbuffer;

      cont:=ppant;

      while buffer[cont-pbuffer]!=13 && buffer[cont-pbuffer]!=10 do {
	 cadena2[cont-ppant+1]:=upcase(buffer[cont-pbuffer]);
         cont:=cont+1;
      }
      cont:=cont+2;
      cadena2[0]:=(cont-ppant-2);
      while (ppant<tamano-1) && (not incluida(cadena_buscada,cadena2)) do {
	 if (ppant>fbuffer) && (fbuffer<tamano-1) then {
	    pbuffer:=pbuffer+TAM_BLOQUE;
	    leerbloque(TAM_BLOQUE);
	 }
         ppant:=cont;
	 while buffer[cont-pbuffer]!=13 && buffer[cont-pbuffer]!=10 do {
	    cadena2[cont-ppant+1]:=upcase(buffer[cont-pbuffer]);
            cont:=cont+1;
	 }
         cont:=cont+2;
	 cadena2[0]:=(cont-ppant-2);
         writeln(a:10,b:10,c:10,d:10);
      }
      if ppant>tamano then {
         gotoxy(18,25);
         write('Texto no encontrado                                           ');
         repeat until keypressed;
         ppant:=a;
         fpant:=b;
         pbuffer:=c;
         fbuffer:=d;
	 leerbloque(TAM_BLOQUE);
         cont:=ppant;
      }
      titulos;
      actualiza_pant;
     reloj.activa;
   }*/




void ayuda()
{

   reloj_desactiva();
   salva_color();
   crecuadro(8,4,20,76,MENS_TINTA,MENS_PAPEL);
   color(MENS_TINTA,MENS_PAPEL);
   miprintf( 9,5," Teclas de Funci�n:���������������������������������������������������");
   miprintf(10,5," F1            -> Ayuda             � F2           -> Buscar texto");
   miprintf(11,5," F3            -> Seguir buscando   � F4/F5         -> Cambiar Colores");
   miprintf(12,5," Alt+I         -> Imprimir fichero  � Alt+P         -> Imprimir desde");
   miprintf(13,5,"                                    �       principio pantalla actual");
   miprintf(14,5," Teclas de Edici�n:���������������������������������������������������");
   miprintf(15,5," Flecha arriba -> L�nea arriba      � Flecha abajo -> L�nea abajo");
   miprintf(16,5," Flecha izda.  -> Car�cter izda.    � Flecha dcha. -> Car�cter dcha.");
   miprintf(17,5," RePag         -> P�gina anterior   � AvPag        -> P�gina siguiente");
   miprintf(18,5," Ctrl+Repag    -> Principio fichero � Ctrl+AvPag   -> Fin fichero");
   miprintf(19,5," Tab           -> Avanza linea      � Mayusc. + tab-> Retrocede linea");
   restaura_color();
   reloj_activa();
   while (!kbhit());
   actualiza_pant();

}


void imprime(micadena p,int longitud)
{
   int i;

   for (i=1;i<=longitud;i++)  {
      fputc(p[i][0],stdprn);
   }
   fputc('\015',stdprn); /*return*/
   fputc('\012',stdprn); /*nueva linea*/
}
void info(int c)
{
    gotoxy(1,24);
    color(MENS_TINTA+BLINK,MENS_PAPEL);
    if (c==BLINK)  {
       miprintf(24,1,"�������������������������� Imprimiendo el Listado �������������������������������");
    } else {
       miprintf(24,1,"����������������������������� Listado detenido ���������������������������������");
    }
    gotoxy(1,25);
    color(MENS_TINTA,MENS_PAPEL);
    miprintf(25,1,"��������������������� [Esc] => Interrumpir el Listado �������������������������");
}

boolean escape(void)
{
   boolean esc=FALSE;
   int xpos, ypos;

   if (kbhit())  {
       tecla=getch();
       if (tecla==27)  {
	  xpos=wherex();
	  ypos=wherey();
	  info(0);
	  crecuadro(11,11,13,69,YELLOW,RED);
	  gotoxy(13,12);
	  color(YELLOW,RED);
	  miprintf(12,13,"     �Desea realmente parar el Listado?(S/N)?         ");
	  while  (tecla!='S' && tecla!='N') {
	     tecla=toupper(getch());
	  }
	  if (tecla=='S')  {
	     esc=TRUE;
	  } else {
	     info(BLINK);
	     gotoxy(xpos,ypos);
	  }
       }
    }
    return(esc);
}



void imprimir(unsigned long desde)
{
   unsigned long pos_aux,pbuf_aux;
   unsigned long tama, posarch;
   int i;
   string lin;

   ultima_linea=22;
   reloj_desactiva();
   salva_color();
   pos_aux=ppant;
   pbuf_aux=pbuffer;
   pbuffer=desde;
   ppant=desde;
   leerbloque(TAM_BLOQUE);
   actualiza_pant();
   tecla=imp_ok();
   if (tecla!=27)  {
      info(BLINK);
      imprime(buf_pant->pant[1],buf_pant->longitudes[1]);
      while ( (ppant<=tamano) && (! escape())) {
	    ppant=ppant+buf_pant->longitudes[primera_linea]+2;
	 actualiza_pant();
	 imprime(buf_pant->pant[1],buf_pant->longitudes[1]);
      }
   }
   color(YELLOW,BLACK);
   ultima_linea=23;
   pbuffer=pbuf_aux;
   leerbloque(TAM_BLOQUE);
   restaura_color();
   titulos();
   ppant=pos_aux;
   actualiza_pant();
   tecla=' ';
   reloj_activa();
}

/*string comprueba_parametros(void)
{
   if paramstr(1)='' then {
      clrscr;
      writeln;
      writeln('  Programa leetext (c) 1992 F.J. Criado');
      writeln('  Modo de uso:');
      writeln('  leetext <[ruta-de-b�squeda] nombre-de-archivo>');
      halt;
   } else {
      findfirst(paramstr(1),readonly + archive,dirinfo);
       if doserror!=0 then {
         clrscr;
         writeln('Archivo no encontrado: ',paramstr(1));
         halt;
      } else {
         comprueba_parametros:=dirinfo.name;
      }
   }
}*/
void comprueba_parametros(char *f,struct ffblk *sf)
{
   findfirst(f,sf,FA_DIREC);
   strcpy(f,sf->ff_name);
}


/*void escribe_posicion(void)
{
   salva_color();
   color(MENS_TINTA,MENS_PAPEL);
   gotoxy(55,25);
   cprintf("%3d/%7ld/%7ld",columna,fpant+1,tamano+1);
   restaura_color();
}*/

void escribe_posicion(void)
{
   char aux[256];
   char aux2[256];

   salva_color();
   color(MENS_TINTA,MENS_PAPEL);
   gotoxy(55,25);
   itoa(columna,aux,10);
   ltoa(fpant+1,aux2,10);
   strcat(aux,"/");
   strcat(aux,aux2);
   ltoa(tamano+1,aux2,10);
   strcat(aux,"/");
   strcat(aux,aux2);
   miprintf(25,55,aux);
   restaura_color();
}


void extrae_dir(string p, string res)
{
   int ultima=-1,i=0;

   while (p[i]) {
      res[i]=p[i];
      if (res[i]=='\\') {
	 ultima=i;
      }
      i++;
   }
   res[ultima+1]='\0';
}


#ifdef PARACLIPPER
  CLIPPER LEETEXT()
  {
     string aux="";
     directvideo=0;

     buf_pant=_xalloc(sizeof(reg_pantalla));
     if (buf_pant==NULL) {
	printf("\nError: no hay memoria\n");
	_ret();
     }
     lbuffer=_xalloc(TAM_BLOQUE);
     if (lbuffer==NULL) {
	printf("\nError: no hay memoria\n");
	_ret();
     }
     strcpy(fichero_a_leer,_parc(1));
     comprueba_parametros(fichero_a_leer,&dirinfo);
     f[0]='\0';
     extrae_dir(_parc(1),dir);
     if (is_color()) {
	pantalla=MK_FP(0xB800,0x0);
     } else {
	pantalla=MK_FP(0xB000,0x0);
     }
     while ((fichero_a_leer[0]!='\0') && (strcmp(f,fichero_a_leer)!=0)) {
	nosound();
	reloj_init(1,61);
	reloj_activa();
	clrscr();
	titulos();

	primera_columna=0;
	ultima_columna=79;
	primera_linea=1;
	ultima_linea=23;


	highvideo();
	tinta=LIGHTGRAY-1;
	papel=BLACK-1;
	cambia_tinta();
	cambia_papel();
	strcat(aux,dir);
	strcat(aux,fichero_a_leer);
	handle_fichero=_open(aux,O_RDONLY);
	pbuffer=0;
	fbuffer=0;
	ppant  =0;
	fpant  =0;
	tamano =filelength(handle_fichero)-1;
	columna=1;
	strcpy(cadena_buscada,"");
	leerbloque(TAM_BLOQUE);
  /*      if (argc>1) {
	   if (strcmp(argv[2],"")!=0)  {
	      toupper
	   val(paramstr(2),desp_ayuda,err);
	   ppant:=desp_ayuda;
	}*/
	actualiza_pant();
	do {
	   escribe_posicion();
	   tecla=getch();
	   switch (tecla) {
	      case 0: {
			tecla=getch();
			switch (tecla) {
			   case 60: {	    /*F3*/
					buscar();
					break;
				     }
			   case 61: {	     /*Ctrl F3*/
				       fin_fichero=abajo();
				       s_ppant=ppant;
				       s_pbuffer=pbuffer;
				       seguir_buscando();
				       break;
				    }
			   case 72: {	    /*arriba*/
					arriba();
					break;
				    }
			   case 80: {	     /*abajo*/
				       fin_fichero=abajo();
				       break;
				    }
			   case 75: {	     /*izquierda*/
				       izquierda(1);
				       break;
				    }
			   case 77: {	     /*derecha*/
				       derecha(1);
				       break;
				     }
			   case 73: {		 /*ReP�g*/
				       repag();
				       break;
				    }
			   case 81: {	      /*AvP�g*/
				       avpag();
				       break;
				    }
			   case 71: {	     /*Inicio*/
				       inicio();
				       break;
				    }
			   case 79: {	      /*Fin*/
				       fin();
				       break;
				    }
			   case 132:{	       /*Ctrl Re.p�g.*/
				       ctrlrepag();
				       break;
				    }
			   case 118: {		/*Ctrl Av.P�g.*/
					ctrlavpag();
					break;
				      }
			   case 23: {
				       imprimir(0); /*imprimir todo el fichero*/
				       break;
				    }
			   case 25: {
				       imprimir(ppant); /*imprimir desde pos actual*/
				       break;
				    }
			   case 62: {
				       cambia_tinta();
				       actualiza_pant();
				       break;
				    }
			    case 63:{
				       cambia_papel();
				       actualiza_pant();
				       break;
				     }
			   case 59: {
				       ayuda();
				       break;
				    }
			   case 15: {  /* shift + tab */
				       izquierda(5);
				       break;
				    }
			} /*case*/
		     }
		     break;
		  case 9: {		  /* tab*/
			     derecha(5);
			     break;
			  }
	       } /*case*/
	} while(tecla!=27);
	clrscr();
	close(handle_fichero);
	reloj_desactiva();
	findnext(&dirinfo);
	strcpy(f,fichero_a_leer);
	strcpy(fichero_a_leer,dirinfo.ff_name);
     }
     _xfree(lbuffer);
     _xfree(buf_pant);
     _ret();
  }
#endif
#ifndef PARACLIPPER
   void main(int argc, char *argv[])
   {
      string aux="";
      directvideo=0;

      buf_pant=malloc(sizeof(reg_pantalla));
      if (buf_pant==NULL) {
	 printf("\nError: no hay memoria\n");
	 exit(-1);
      }
      lbuffer=malloc(TAM_BLOQUE);
      if (lbuffer==NULL) {
	 printf("\nError: no hay memoria\n");
	 exit(-1);
      }
      strcpy(fichero_a_leer,argv[1]);
      comprueba_parametros(fichero_a_leer,&dirinfo);
      f[0]='\0';
      extrae_dir(argv[1],dir);
      if (is_color()) {
	 pantalla=MK_FP(0xB800,0x0);
      } else {
	 pantalla=MK_FP(0xB000,0x0);
      }
      while ((fichero_a_leer[0]!='\0') && (strcmp(f,fichero_a_leer)!=0)) {
	 nosound();
	 reloj_init(1,61);
	 reloj_activa();
	 clrscr();
	 titulos();

	 primera_columna=0;
	 ultima_columna=79;
	 primera_linea=1;
	 ultima_linea=23;


	 highvideo();
	 tinta=LIGHTGRAY-1;
	 papel=BLACK-1;
	 cambia_tinta();
	 cambia_papel();
	 strcat(aux,dir);
	 strcat(aux,fichero_a_leer);
	 handle_fichero=_open(aux,O_RDONLY);
	 pbuffer=0;
	 fbuffer=0;
	 ppant  =0;
	 fpant  =0;
	 tamano =filelength(handle_fichero)-1;
	 columna=1;
	 strcpy(cadena_buscada,"");
	 leerbloque(TAM_BLOQUE);
   /*      if (argc>1) {
	    if (strcmp(argv[2],"")!=0)  {
	       toupper
	    val(paramstr(2),desp_ayuda,err);
	    ppant:=desp_ayuda;
	 }*/
	 actualiza_pant();
	 do {
	    escribe_posicion();
	    tecla=getch();
	    switch (tecla) {
	       case 0: {
			 tecla=getch();
			 switch (tecla) {
			    case 60: {	    /*F3*/
					 buscar();
					 break;
				      }
			    case 61: {	     /*Ctrl F3*/
					fin_fichero=abajo();
					s_ppant=ppant;
					s_pbuffer=pbuffer;
					seguir_buscando();
					break;
				     }
			    case 72: {	    /*arriba*/
					 arriba();
					 break;
				     }
			    case 80: {	     /*abajo*/
					fin_fichero=abajo();
					break;
				     }
			    case 75: {	     /*izquierda*/
					izquierda(1);
					break;
				     }
			    case 77: {	     /*derecha*/
					derecha(1);
					break;
				      }
			    case 73: {		 /*ReP�g*/
					repag();
					break;
				     }
			    case 81: {	      /*AvP�g*/
					avpag();
					break;
				     }
			    case 71: {	     /*Inicio*/
					inicio();
					break;
				     }
			    case 79: {	      /*Fin*/
					fin();
					break;
				     }
			    case 132:{	       /*Ctrl Re.p�g.*/
					ctrlrepag();
					break;
				     }
			    case 118: {		/*Ctrl Av.P�g.*/
					 ctrlavpag();
					 break;
				       }
			    case 23: {
					imprimir(0); /*imprimir todo el fichero*/
					break;
				     }
			    case 25: {
					imprimir(ppant); /*imprimir desde pos actual*/
					break;
				     }
			    case 62: {
					cambia_tinta();
					actualiza_pant();
					break;
				     }
			     case 63:{
					cambia_papel();
					actualiza_pant();
					break;
				      }
			    case 59: {
					ayuda();
					break;
				     }
			    case 15: {  /* shift + tab */
					izquierda(5);
					break;
				     }
			 } /*case*/
		      }
		      break;
		   case 9: {		  /* tab*/
			      derecha(5);
			      break;
			   }
		} /*case*/
	 } while(tecla!=27);
	 clrscr();
	 close(handle_fichero);
	 reloj_desactiva();
	 findnext(&dirinfo);
	 strcpy(f,fichero_a_leer);
	 strcpy(fichero_a_leer,dirinfo.ff_name);
      }
      free(buf_pant);
      free(lbuffer);
   }
#endif