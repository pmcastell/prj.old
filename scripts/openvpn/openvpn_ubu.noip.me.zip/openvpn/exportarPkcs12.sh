if [ "$1" = "" -o "$2" = "" ];
then
   echo uso: $0 '<fichero-certficiado> <fichero-salida-pkcs12(se añadirá extension pfx)>'
   exit 1
fi   
cat $1.crt > /tmp/__salida.pem
cat $1.key >> /tmp/__salida.pem
openssl pkcs12 -export -in /tmp/__salida.pem -out $2.pfx -name "Certificado de $1 para iesinclan"  
rm /tmp/__salida.pem

