vuelca() {
   DESDE=$1
   HASTA=$2
   FICHERO=$3
   OUT=0; 
   while read LINEA;  
   do 
      if [ "$OUT" = "1" -a "$(echo $LINEA | grep "${HASTA}" | grep -v grep)" != "" ];
      then
         echo $LINEA
         OUT=0
      elif [ "$OUT" = "1" ];
      then
         echo $LINEA
      elif [ "$(echo $LINEA | grep "${DESDE}" | grep -v grep)" != "" ];
      then
         echo $LINEA
         OUT=1
      fi
      
   done < $FICHERO
}

if [ -f plantilla.ovpn ];
then
   cat plantilla.ovpn > $1.ovpn
   echo '<key>' >> $1.ovpn
   cat $1.key >> $1.ovpn
   echo '</key>' >> $1.ovpn
   echo '<cert>' >> $1.ovpn
   vuelca "BEGIN CERTIFICATE" "END CERTIFICATE" $1.crt >> $1.ovpn
   echo '</cert>' >> $1.ovpn
fi

