#!/bin/bash
vuelca() {
   DESDE=$1
   HASTA=$2
   FICHERO=$3
   OUT=0; 
   while read LINEA;  
   do 
      ##ENCONTRADO="$(echo $LINEA | grep '$DESDE' | grep -v grep)"
      ## echo "(echo $LINEA | grep '$DESDE' | grep -v grep)"
      ##echo "ENCONTRADO: "$ENCONTRADO
      ##read pepe < /dev/tty
      
      if [ "$OUT" = "1" -a "$(echo $LINEA | grep "${HASTA}" | grep -v 2grep)" != "" ];
      then
         echo $LINEA
         OUT=0
      elif [ "$OUT" = "1" ];
      then
         echo $LINEA
      elif [ "$(echo $LINEA | grep "${DESDE}" | grep -v grep)" != "" ];
      then
         echo $LINEA
         OUT=1
      fi
      
   done < $FICHERO
}
vuelca "BEGIN CERTIFICATE" "END CERTIFICATE" insti.crt
#vuelca CERTIFICATE CERTIFICATE insti.crt


