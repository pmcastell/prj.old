#ficheros necesarios
#iesinclan-ca.crt iesinclan-ca.key (certificado self-signed)

#sudo gedit /usr/lib/ssl/openssl.cnf
#dir		= /home/usuario/openvpn
#private_key	= /home/usuario/openvpn/iesinclan-ca.key
#mkdir /home/usuario/openvpn/newcerts
#touch index.txt
#echo 01 > serial

#meter esto en nuevoCert.sh
vuelca() {
   DESDE=$1
   HASTA=$2
   FICHERO=$3
   OUT=0; 
   while read LINEA;  
   do 
      if [ "$OUT" = "1" -a "$(echo $LINEA | grep "${HASTA}" | grep -v grep)" != "" ];
      then
         echo $LINEA
         OUT=0
      elif [ "$OUT" = "1" ];
      then
         echo $LINEA
      elif [ "$(echo $LINEA | grep "${DESDE}" | grep -v grep)" != "" ];
      then
         echo $LINEA
         OUT=1
      fi
      
   done < $FICHERO
}

if [ "$1" = "" ];
then
   echo uso: $0 '<fichero-a-generar-de-certificado> [<certificado-ca-para-firmar-sin-la-extension-crt>]'
   exit
fi

openssl req -new -out $1.csr
openssl rsa -in privkey.pem -out $1.key
if [ "$2" != "" ];
then
   CA_CRT=$2
   openssl ca -cert $2.crt -keyfile $2.key -out $1.crt -in $1.csr
else
   ###openssl ca -cert iesinclan-ca.crt -keyfile iesinclan-ca.key -out $1.crt -in $1.csr
   ##openssl ca -cert iesinclan.tk-ca.crt -keyfile iesinclan.tk-ca.key -out $1.crt -in $1.csr
   openssl ca -cert ubu.noip.me-ca.crt -keyfile ubu.noip.me-ca.key -out $1.crt -in $1.csr
fi
if [ -f plantilla.ovpn ];
then
   cat plantilla.ovpn > $1.ovpn
   echo '<key>' >> $1.ovpn
   cat $1.key >> $1.ovpn
   echo '</key>' >> $1.ovpn
   echo '<cert>' >> $1.ovpn
   vuelca "BEGIN CERTIFICATE" "END CERTIFICATE" $1.crt >> $1.ovpn
   echo '</cert>' >> $1.ovpn
fi
   







